package com.example.buzz_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
