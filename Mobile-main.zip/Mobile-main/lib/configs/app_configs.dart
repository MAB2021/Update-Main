class AppConfig {
  static const String mapApiKey = "AIzaSyDTGHP6bB1tXEfWVd3rHjFBJ0WM9_5GyrU";
  static const String timezoneApiKey = 'B4Y2WLZX004D';
}

class AppURL {
  static const String baseUrl =
      "https://event-backend-5abff49d5ee6.herokuapp.com/api/v1/";
  static const String nodescaleBaseUrl =
      "https://event-scrap-app-65cb46a0c0c7.herokuapp.com/";
  static const String categories = "categories";
  static const String changePassword = "change-password";
  static const String forgotPassword = "forget-password";
  static const String login = "login";
  static const String otp = "otp";
  static const String getUser = "get-user";
  static const String user = "user";
  static const String updatePassword = "update-password";
  static const String updateProfile = "update-profile";
  static const String validate = "/validate";
  static const String events = "/events/";
  static const String keyword = "keyword";
  static const String addBookmark = "add-event";
  static const String removeEventBookmark = "remove-event/";
  static const String getEventBookmark = "user-bookmark-events";
  static const String getUserEvents = "user-events?type=all";
  static const String home = "home";
  static const String upcomingEvent = "upcoming-events";
  static const String rate = "rate";
  static const String getEvent = "get-event";
  static const String addEvent = "add-event";
  static const String updateEvent = "update-even";
  static const String getCustomEvent = "custom-events?host=nodescale";
  static const String privacyPolicy =
      "https://buzzmap.netlify.app/privacyPolicy";
  static timezoneURL(
          String timezoneApiKey, double longitude, double latitude) =>
      'http://vip.timezonedb.com/v2.1/get-time-zone?key=$timezoneApiKey&format=json&by=position&lat=$latitude&lng=$longitude';

  //Device Token
  static const String createDeviceToken = "add-token";
  static const String removeDeviceToken = "remove-token";
}

class AppConstants {
  static const String deviceTokenAdded = "deviceTokenAdded";
  static const String isUserFirstTime = "isUserFirstTime";
  static const String userObject = "userObject";
  static const String userToken = "userToken";
  static const String refreshToken = "refreshToken";
  static const int resendOtpTime = 120;
  static const int otpPINLength = 6;
  // static const double minimumOrder = 1000;
  static const String cloudinaryUrl = "doo6gjkla";
  static const String cloudinaryUploadPresetName = "brknsoqv";
  static const String calendarName = "BuzzMap";

  //!remove before pushing to prod
  static const String email = "email";
  static const String password = "password";
}
