import 'package:buzz_map/firebase_options.dart';
import 'package:buzz_map/modules/auth/forgot_password/di.dart';
import 'package:buzz_map/modules/auth/login/di.dart';
import 'package:buzz_map/modules/auth/sign_up/di.dart';
import 'package:buzz_map/modules/bookmark/di.dart';
import 'package:buzz_map/modules/calendar/di.dart';
import 'package:buzz_map/modules/events/di.dart';
import 'package:buzz_map/modules/home/di.dart';
import 'package:buzz_map/modules/interest/di.dart';
import 'package:buzz_map/modules/location/di.dart';
import 'package:buzz_map/modules/notification/di.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/modules/profile/di.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/root/di.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/notifications/firebase_notification_manager.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_it/get_it.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../shared/di.dart';
import '../shared/utils/storage.dart';
import 'app_configs.dart';

// This is our global ServiceLocator
GetIt getIt = GetIt.instance;
User? _user;

class AppStartUp {
  Future<void> setUp() async {
    getIt.allowReassignment = true;
    await initializedFirebase();
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    getIt.registerSingleton(LocalStorageUtils(sharedPreferences));

    await registerServices(getIt);
    await loadStartUpConfig();
    await firebasePushNotification();
  }

  Future<void> registerServices(ioc) async {
    setupSharedServices(ioc);
    setupNavServices(ioc);
    setupLogin(ioc);
    setupSignUp(ioc);
    setupForgotPassword(ioc);
    setupInterest(ioc);
    setupProfile(ioc);
    setupHome(ioc);
    setupLocation(ioc);
    setupBookmark(ioc);
    setupEvents(ioc);
    setupCalendar(ioc);
    setupNotification(ioc);
  }

  Future<void> loadStartUpConfig() async {
    // clear cached token if the app is a newly installed.
    var isFirstTime =
        getIt<LocalStorageUtils>().read(AppConstants.isUserFirstTime);
    if (isFirstTime != "true") {
      await const FlutterSecureStorage().deleteAll();
    }
    // Get User Object data from local storage
    var userObject = await getIt<LocalStorageUtils>()
        .readObject<User>(AppConstants.userObject);
    if (userObject != null) {
      _user = User.fromJson(userObject);

      getIt.registerSingleton<User>(_user!);

      userCurrentAddress.value = _user?.town;
      if (_user?.geoLocation != null) {
        userCurrentPosition.value =
            LatLng(_user!.geoLocation!.latitude, _user!.geoLocation!.longitude);
      }
      getIt<ProfileCubit>().getProfile();
    }
  }

  Future<void> initializedFirebase() async {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    FlutterError.onError = (errorDetails) {
      FirebaseCrashlytics.instance.recordFlutterFatalError(errorDetails);
    };

    // Pass all uncaught asynchronous errors that aren't handled by the Flutter framework to Crashlytics
    PlatformDispatcher.instance.onError = (error, stack) {
      FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
      return true;
    };
  }

  Future<void> firebasePushNotification() async {
    FirebaseNotificationManager notificationManager =
        FirebaseNotificationManager();
    await notificationManager.registerNotification();
    try {
      String token = (await FirebaseNotificationManager().deviceToken)!;
      debugPrint(token);
      await notificationManager.deviceToken;
    } catch (ex) {
      debugPrint(ex.toString());
    }
  }
}
