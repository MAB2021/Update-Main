// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static String m0(phoneNumber) => "Code has been sent to ${phoneNumber}";

  static String m1(identifier) =>
      "Enter the verification code we just sent to ${identifier}";

  static String m2(allowedSize) =>
      "File too large. Max size is ${allowedSize}MB";

  static String m3(count) => "${count} found";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "aboutEvent": MessageLookupByLibrary.simpleMessage("About Event"),
        "accountCreationSuccessful":
            MessageLookupByLibrary.simpleMessage("Account Creation Successful"),
        "addComment": MessageLookupByLibrary.simpleMessage("Add Comment"),
        "addCoverPhotos":
            MessageLookupByLibrary.simpleMessage("Add Cover Photo"),
        "addMyLocation":
            MessageLookupByLibrary.simpleMessage("Add My Location"),
        "addToCalendar":
            MessageLookupByLibrary.simpleMessage("Add to My Calender"),
        "alreadyHaveAnAccount":
            MessageLookupByLibrary.simpleMessage("Already have an account? "),
        "anErrorOccurred":
            MessageLookupByLibrary.simpleMessage("An error occurred."),
        "appUpdates": MessageLookupByLibrary.simpleMessage("App Updates"),
        "areYourSureYouWantToLogout": MessageLookupByLibrary.simpleMessage(
            "Are you sure you want to log out ?"),
        "bookNow": MessageLookupByLibrary.simpleMessage("Book Now"),
        "bookmark": MessageLookupByLibrary.simpleMessage("Bookmark"),
        "buzzMap": MessageLookupByLibrary.simpleMessage("BuzzMap"),
        "calendar": MessageLookupByLibrary.simpleMessage("Calendar"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "changePassword":
            MessageLookupByLibrary.simpleMessage("Change Password"),
        "city": MessageLookupByLibrary.simpleMessage("Event City"),
        "close": MessageLookupByLibrary.simpleMessage("Close"),
        "codeSentTo": m0,
        "comingSoonAfterEvent":
            MessageLookupByLibrary.simpleMessage("Coming soon (after event)"),
        "confirmNewPassword":
            MessageLookupByLibrary.simpleMessage("CONFIRM PASSWORD"),
        "confirmPassword":
            MessageLookupByLibrary.simpleMessage("CONFIRM PASSWORD"),
        "confirmPasswordRequired":
            MessageLookupByLibrary.simpleMessage("Please re-enter password"),
        "connectionError": MessageLookupByLibrary.simpleMessage(
            "Connection error. Contact admin or try again later."),
        "country": MessageLookupByLibrary.simpleMessage("Event Country"),
        "createANewPassword":
            MessageLookupByLibrary.simpleMessage("Create a new password"),
        "createNewEvent":
            MessageLookupByLibrary.simpleMessage("Create New Event"),
        "createNewEventAndPublish":
            MessageLookupByLibrary.simpleMessage("Create  New Event & Publish"),
        "darkMode": MessageLookupByLibrary.simpleMessage("Dark Mode"),
        "didNotReceiveCode":
            MessageLookupByLibrary.simpleMessage("Didn’t receive the code?"),
        "discoverExcitingEvents": MessageLookupByLibrary.simpleMessage(
            "Discover Exciting Sports Events, Live Concerts, Inspiring Seminars, and Much More"),
        "doNotHaveAnAccount":
            MessageLookupByLibrary.simpleMessage("Don\'t have an account? "),
        "easilyAddEventsToYourCalendar": MessageLookupByLibrary.simpleMessage(
            "Easily Add Events To Your Calendar"),
        "editProfile": MessageLookupByLibrary.simpleMessage("Edit Profile"),
        "emailAddress": MessageLookupByLibrary.simpleMessage("EMAIL ADDRESS"),
        "enterTheVerificationCodeWeSentTo": m1,
        "enterValidName":
            MessageLookupByLibrary.simpleMessage("Please enter valid name"),
        "enterValidPhoneNumber": MessageLookupByLibrary.simpleMessage(
            "Please enter valid mobile number"),
        "enterYouInformationBelowToSignIn":
            MessageLookupByLibrary.simpleMessage(
                "Enter your information below to sign in"),
        "enterYourInformationBelowToSignIn":
            MessageLookupByLibrary.simpleMessage(
                "Enter your information below to sign in"),
        "enterYourPhoneNumber":
            MessageLookupByLibrary.simpleMessage("Enter Your Phone Number"),
        "eventAddedToCalendar":
            MessageLookupByLibrary.simpleMessage("Event added to calendar"),
        "eventAddress": MessageLookupByLibrary.simpleMessage("Event Address"),
        "eventAroundYou":
            MessageLookupByLibrary.simpleMessage("Event Around You"),
        "eventCategory": MessageLookupByLibrary.simpleMessage("Event Category"),
        "eventDescription":
            MessageLookupByLibrary.simpleMessage("Event Description"),
        "eventDetail": MessageLookupByLibrary.simpleMessage("Event Details"),
        "eventHasBeenAddedToCalendar": MessageLookupByLibrary.simpleMessage(
            "Event has been added to calender"),
        "eventHasBeenBookmarked":
            MessageLookupByLibrary.simpleMessage("Event has been bookmarked"),
        "eventHasBeenRemovedFromBookmark": MessageLookupByLibrary.simpleMessage(
            "Event has been removed from bookmark"),
        "eventHasBeenRemovedFromCalendar": MessageLookupByLibrary.simpleMessage(
            "Event has been removed from calender"),
        "eventInfo": MessageLookupByLibrary.simpleMessage("Event Info"),
        "eventList": MessageLookupByLibrary.simpleMessage("Event List"),
        "eventName": MessageLookupByLibrary.simpleMessage("Event Name"),
        "eventStartDate":
            MessageLookupByLibrary.simpleMessage("Event Start Date"),
        "events": MessageLookupByLibrary.simpleMessage("Events"),
        "expandYourNetwork": MessageLookupByLibrary.simpleMessage(
            "Expand your network and join communities"),
        "exploringUpcomingAndNearbyEvent": MessageLookupByLibrary.simpleMessage(
            "Exploring Upcoming And Nearby Event"),
        "featured": MessageLookupByLibrary.simpleMessage("Featured"),
        "fileTooLarge": m2,
        "findYouFavouriteEvents":
            MessageLookupByLibrary.simpleMessage("Find Your Favourite Events"),
        "forgotPassword":
            MessageLookupByLibrary.simpleMessage("Forgot Password"),
        "found": m3,
        "fullName": MessageLookupByLibrary.simpleMessage("FULL NAME"),
        "generalNotification":
            MessageLookupByLibrary.simpleMessage("General Notification"),
        "good": MessageLookupByLibrary.simpleMessage("Good"),
        "helpCenter": MessageLookupByLibrary.simpleMessage("Help Center"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "homepage": MessageLookupByLibrary.simpleMessage("Homepage"),
        "hot": MessageLookupByLibrary.simpleMessage("Hot"),
        "imageTypes":
            MessageLookupByLibrary.simpleMessage("PNG, JPG (max. 800x400px)"),
        "interests": MessageLookupByLibrary.simpleMessage("Interest"),
        "kindlyCheckDataAndRetry":
            MessageLookupByLibrary.simpleMessage("Kindly check data and retry"),
        "kindlyTryAgain":
            MessageLookupByLibrary.simpleMessage("Kindly try again."),
        "kontinue": MessageLookupByLibrary.simpleMessage("Continue"),
        "lightMode": MessageLookupByLibrary.simpleMessage("Light Mode"),
        "location": MessageLookupByLibrary.simpleMessage("Location"),
        "locationDenied": MessageLookupByLibrary.simpleMessage(
            "Your device location permission has been denied,please kindly enable to continue"),
        "locationPermissionsAreDenied": MessageLookupByLibrary.simpleMessage(
            "Location permissions are denied"),
        "locationPermissionsPermanentlyDenied":
            MessageLookupByLibrary.simpleMessage(
                "Location permissions are permanently denied, we cannot request permissions."),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "loginNow": MessageLookupByLibrary.simpleMessage("Login Now"),
        "loginToYouAccount":
            MessageLookupByLibrary.simpleMessage("Login to your Account"),
        "logout": MessageLookupByLibrary.simpleMessage("LogOut"),
        "lowerCaseRequired": MessageLookupByLibrary.simpleMessage(
            "Password require at least one lowercase letter"),
        "maxWord": MessageLookupByLibrary.simpleMessage("Max 250 words"),
        "minimumPassword": MessageLookupByLibrary.simpleMessage(
            "Password must be minimum of six characters"),
        "myCalendarEvent":
            MessageLookupByLibrary.simpleMessage("My Calendar Event"),
        "nearByYourLocation":
            MessageLookupByLibrary.simpleMessage("Nearby Your Location"),
        "newPassword": MessageLookupByLibrary.simpleMessage("NEW PASSWORD"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "noFileSelected":
            MessageLookupByLibrary.simpleMessage("No File Selected"),
        "noInternetConnection":
            MessageLookupByLibrary.simpleMessage("No internet connection."),
        "noResultsFound":
            MessageLookupByLibrary.simpleMessage("No results found"),
        "notification": MessageLookupByLibrary.simpleMessage("Notification"),
        "numberRequired": MessageLookupByLibrary.simpleMessage(
            "Password require at least one numeric character"),
        "ok": MessageLookupByLibrary.simpleMessage("Okay"),
        "oldPassword": MessageLookupByLibrary.simpleMessage("OLD PASSWORD"),
        "ongoingLive": MessageLookupByLibrary.simpleMessage("Ongoing Live"),
        "openGallery": MessageLookupByLibrary.simpleMessage("Open Gallery"),
        "otpCorrect": MessageLookupByLibrary.simpleMessage("OTP Correct"),
        "otpIsRequired":
            MessageLookupByLibrary.simpleMessage("Otp is required"),
        "otpMustBe6Digits":
            MessageLookupByLibrary.simpleMessage("Otp must be 6 digits"),
        "otpVerification":
            MessageLookupByLibrary.simpleMessage("OTP Verification"),
        "password": MessageLookupByLibrary.simpleMessage("PASSWORD"),
        "passwordDoesNotMatch":
            MessageLookupByLibrary.simpleMessage("Password does not match"),
        "passwordRequired":
            MessageLookupByLibrary.simpleMessage("Please enter password"),
        "passwordRequirement": MessageLookupByLibrary.simpleMessage(
            "Password require at least one lowercase letter\none numeric character\nand minimum of 6 characters"),
        "permissionDenied":
            MessageLookupByLibrary.simpleMessage("Permission denied"),
        "phoneNumber": MessageLookupByLibrary.simpleMessage("PHONE NUMBER"),
        "pleaseEnterAValidEmail":
            MessageLookupByLibrary.simpleMessage("Please enter a valid email"),
        "pleaseEnterEmail":
            MessageLookupByLibrary.simpleMessage("Please enter your email"),
        "pleaseSetANewPassword":
            MessageLookupByLibrary.simpleMessage("Please set a new password"),
        "pleaseSetUpYourPreference": MessageLookupByLibrary.simpleMessage(
            "Please setup your preference"),
        "pleaseTryAnotherKeyword":
            MessageLookupByLibrary.simpleMessage("Please try another keyword"),
        "privacyPolicy": MessageLookupByLibrary.simpleMessage("Privacy Policy"),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profilePictureUploadFailed": MessageLookupByLibrary.simpleMessage(
            "Profile Picture Upload Failed"),
        "profilePictureUploaded":
            MessageLookupByLibrary.simpleMessage("Profile Picture Uploaded"),
        "rateEvent": MessageLookupByLibrary.simpleMessage("Rate Event"),
        "rateNow": MessageLookupByLibrary.simpleMessage("Rate Now!"),
        "ratingSaved": MessageLookupByLibrary.simpleMessage("Rating Saved"),
        "removeFromCalendar":
            MessageLookupByLibrary.simpleMessage("Remove from calender"),
        "removeFromYourBookmark":
            MessageLookupByLibrary.simpleMessage("Remove from your bookmark ?"),
        "removePicture": MessageLookupByLibrary.simpleMessage("Remove Picture"),
        "requestCancelled":
            MessageLookupByLibrary.simpleMessage("Request cancelled."),
        "resendOTP": MessageLookupByLibrary.simpleMessage("Resend OTP"),
        "reviews": MessageLookupByLibrary.simpleMessage("Reviews"),
        "save": MessageLookupByLibrary.simpleMessage("Save"),
        "search": MessageLookupByLibrary.simpleMessage("Search"),
        "searchResults": MessageLookupByLibrary.simpleMessage("Search Results"),
        "seconds": MessageLookupByLibrary.simpleMessage("sec"),
        "security": MessageLookupByLibrary.simpleMessage("Security"),
        "seeAll": MessageLookupByLibrary.simpleMessage("See All"),
        "seeOnMaps": MessageLookupByLibrary.simpleMessage("See on Maps"),
        "selectWhichContactDetails": MessageLookupByLibrary.simpleMessage(
            "Select which contact details should we use to reset your password"),
        "selectYourInterest":
            MessageLookupByLibrary.simpleMessage("Select Your Interest"),
        "selectYourLocation":
            MessageLookupByLibrary.simpleMessage("Select Your Location"),
        "settings": MessageLookupByLibrary.simpleMessage("Settings"),
        "signUp": MessageLookupByLibrary.simpleMessage("Sign Up"),
        "signUpForFree":
            MessageLookupByLibrary.simpleMessage("Sign Up For Free"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "sounds": MessageLookupByLibrary.simpleMessage("Sound"),
        "specialCharacterRequired": MessageLookupByLibrary.simpleMessage(
            "Password require at least one special character"),
        "takePhoto": MessageLookupByLibrary.simpleMessage("Take Photo"),
        "thanksForUsingOurApp":
            MessageLookupByLibrary.simpleMessage("Thanks for using our app"),
        "thisFieldIsRequired":
            MessageLookupByLibrary.simpleMessage("This field is required"),
        "timeZone": MessageLookupByLibrary.simpleMessage("Event City"),
        "trending": MessageLookupByLibrary.simpleMessage("Trending"),
        "update": MessageLookupByLibrary.simpleMessage("Update"),
        "uploadProfilePicture":
            MessageLookupByLibrary.simpleMessage("Upload Profile Picture"),
        "upperCaseRequired": MessageLookupByLibrary.simpleMessage(
            "Password require at least one uppercase letter"),
        "validFullName":
            MessageLookupByLibrary.simpleMessage("Enter valid full name"),
        "verify": MessageLookupByLibrary.simpleMessage("Verify"),
        "viaEmail": MessageLookupByLibrary.simpleMessage("VIA EMAIL"),
        "viaSMS": MessageLookupByLibrary.simpleMessage("VIA SMS"),
        "viewParticipantsDiscussions":
            MessageLookupByLibrary.simpleMessage("View Participant Discussion"),
        "weSentYouOtpToYourEmail": MessageLookupByLibrary.simpleMessage(
            "We sent you an OTP to your email address. Click “Continue” to complete your account setup."),
        "welcomeToBuzzMap":
            MessageLookupByLibrary.simpleMessage("Welcome To BuzzMap"),
        "yesLogout": MessageLookupByLibrary.simpleMessage("Yes, Logout"),
        "yesRemove": MessageLookupByLibrary.simpleMessage("Yes, Remove"),
        "youHaveNoBookmarkedEvent": MessageLookupByLibrary.simpleMessage(
            "You have no bookmarked event"),
        "youHaveNoEvents":
            MessageLookupByLibrary.simpleMessage("You have no events"),
        "youHaveNoNotifications":
            MessageLookupByLibrary.simpleMessage("You have no notifications"),
        "youHaveSuccessfullyRated": MessageLookupByLibrary.simpleMessage(
            "You have successfully rated this event")
      };
}
