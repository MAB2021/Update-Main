// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `An error occurred.`
  String get anErrorOccurred {
    return Intl.message(
      'An error occurred.',
      name: 'anErrorOccurred',
      desc: '',
      args: [],
    );
  }

  /// `Kindly try again.`
  String get kindlyTryAgain {
    return Intl.message(
      'Kindly try again.',
      name: 'kindlyTryAgain',
      desc: '',
      args: [],
    );
  }

  /// `No internet connection.`
  String get noInternetConnection {
    return Intl.message(
      'No internet connection.',
      name: 'noInternetConnection',
      desc: '',
      args: [],
    );
  }

  /// `Request cancelled.`
  String get requestCancelled {
    return Intl.message(
      'Request cancelled.',
      name: 'requestCancelled',
      desc: '',
      args: [],
    );
  }

  /// `Connection error. Contact admin or try again later.`
  String get connectionError {
    return Intl.message(
      'Connection error. Contact admin or try again later.',
      name: 'connectionError',
      desc: '',
      args: [],
    );
  }

  /// `Kindly check data and retry`
  String get kindlyCheckDataAndRetry {
    return Intl.message(
      'Kindly check data and retry',
      name: 'kindlyCheckDataAndRetry',
      desc: '',
      args: [],
    );
  }

  /// `BuzzMap`
  String get buzzMap {
    return Intl.message(
      'BuzzMap',
      name: 'buzzMap',
      desc: '',
      args: [],
    );
  }

  /// `Login to your Account`
  String get loginToYouAccount {
    return Intl.message(
      'Login to your Account',
      name: 'loginToYouAccount',
      desc: '',
      args: [],
    );
  }

  /// `Enter your information below to sign in`
  String get enterYouInformationBelowToSignIn {
    return Intl.message(
      'Enter your information below to sign in',
      name: 'enterYouInformationBelowToSignIn',
      desc: '',
      args: [],
    );
  }

  /// `EMAIL ADDRESS`
  String get emailAddress {
    return Intl.message(
      'EMAIL ADDRESS',
      name: 'emailAddress',
      desc: '',
      args: [],
    );
  }

  /// `PASSWORD`
  String get password {
    return Intl.message(
      'PASSWORD',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `Forgot Password`
  String get forgotPassword {
    return Intl.message(
      'Forgot Password',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Don't have an account? `
  String get doNotHaveAnAccount {
    return Intl.message(
      'Don\'t have an account? ',
      name: 'doNotHaveAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Sign Up`
  String get signUp {
    return Intl.message(
      'Sign Up',
      name: 'signUp',
      desc: '',
      args: [],
    );
  }

  /// `Please enter password`
  String get passwordRequired {
    return Intl.message(
      'Please enter password',
      name: 'passwordRequired',
      desc: '',
      args: [],
    );
  }

  /// `Password require at least one lowercase letter\none numeric character\nand minimum of 6 characters`
  String get passwordRequirement {
    return Intl.message(
      'Password require at least one lowercase letter\none numeric character\nand minimum of 6 characters',
      name: 'passwordRequirement',
      desc: '',
      args: [],
    );
  }

  /// `Password must be minimum of six characters`
  String get minimumPassword {
    return Intl.message(
      'Password must be minimum of six characters',
      name: 'minimumPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password require at least one uppercase letter`
  String get upperCaseRequired {
    return Intl.message(
      'Password require at least one uppercase letter',
      name: 'upperCaseRequired',
      desc: '',
      args: [],
    );
  }

  /// `Password require at least one lowercase letter`
  String get lowerCaseRequired {
    return Intl.message(
      'Password require at least one lowercase letter',
      name: 'lowerCaseRequired',
      desc: '',
      args: [],
    );
  }

  /// `Password require at least one numeric character`
  String get numberRequired {
    return Intl.message(
      'Password require at least one numeric character',
      name: 'numberRequired',
      desc: '',
      args: [],
    );
  }

  /// `Password require at least one special character`
  String get specialCharacterRequired {
    return Intl.message(
      'Password require at least one special character',
      name: 'specialCharacterRequired',
      desc: '',
      args: [],
    );
  }

  /// `Password does not match`
  String get passwordDoesNotMatch {
    return Intl.message(
      'Password does not match',
      name: 'passwordDoesNotMatch',
      desc: '',
      args: [],
    );
  }

  /// `Please re-enter password`
  String get confirmPasswordRequired {
    return Intl.message(
      'Please re-enter password',
      name: 'confirmPasswordRequired',
      desc: '',
      args: [],
    );
  }

  /// `Otp is required`
  String get otpIsRequired {
    return Intl.message(
      'Otp is required',
      name: 'otpIsRequired',
      desc: '',
      args: [],
    );
  }

  /// `Otp must be 6 digits`
  String get otpMustBe6Digits {
    return Intl.message(
      'Otp must be 6 digits',
      name: 'otpMustBe6Digits',
      desc: '',
      args: [],
    );
  }

  /// `Please enter your email`
  String get pleaseEnterEmail {
    return Intl.message(
      'Please enter your email',
      name: 'pleaseEnterEmail',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a valid email`
  String get pleaseEnterAValidEmail {
    return Intl.message(
      'Please enter a valid email',
      name: 'pleaseEnterAValidEmail',
      desc: '',
      args: [],
    );
  }

  /// `Sign Up For Free`
  String get signUpForFree {
    return Intl.message(
      'Sign Up For Free',
      name: 'signUpForFree',
      desc: '',
      args: [],
    );
  }

  /// `Enter your information below to sign in`
  String get enterYourInformationBelowToSignIn {
    return Intl.message(
      'Enter your information below to sign in',
      name: 'enterYourInformationBelowToSignIn',
      desc: '',
      args: [],
    );
  }

  /// `FULL NAME`
  String get fullName {
    return Intl.message(
      'FULL NAME',
      name: 'fullName',
      desc: '',
      args: [],
    );
  }

  /// `PHONE NUMBER`
  String get phoneNumber {
    return Intl.message(
      'PHONE NUMBER',
      name: 'phoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `CONFIRM PASSWORD`
  String get confirmPassword {
    return Intl.message(
      'CONFIRM PASSWORD',
      name: 'confirmPassword',
      desc: '',
      args: [],
    );
  }

  /// `Already have an account? `
  String get alreadyHaveAnAccount {
    return Intl.message(
      'Already have an account? ',
      name: 'alreadyHaveAnAccount',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid name`
  String get enterValidName {
    return Intl.message(
      'Please enter valid name',
      name: 'enterValidName',
      desc: '',
      args: [],
    );
  }

  /// `Enter valid full name`
  String get validFullName {
    return Intl.message(
      'Enter valid full name',
      name: 'validFullName',
      desc: '',
      args: [],
    );
  }

  /// `Enter Your Phone Number`
  String get enterYourPhoneNumber {
    return Intl.message(
      'Enter Your Phone Number',
      name: 'enterYourPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Please enter valid mobile number`
  String get enterValidPhoneNumber {
    return Intl.message(
      'Please enter valid mobile number',
      name: 'enterValidPhoneNumber',
      desc: '',
      args: [],
    );
  }

  /// `Close`
  String get close {
    return Intl.message(
      'Close',
      name: 'close',
      desc: '',
      args: [],
    );
  }

  /// `Account Creation Successful`
  String get accountCreationSuccessful {
    return Intl.message(
      'Account Creation Successful',
      name: 'accountCreationSuccessful',
      desc: '',
      args: [],
    );
  }

  /// `We sent you an OTP to your email address. Click “Continue” to complete your account setup.`
  String get weSentYouOtpToYourEmail {
    return Intl.message(
      'We sent you an OTP to your email address. Click “Continue” to complete your account setup.',
      name: 'weSentYouOtpToYourEmail',
      desc: '',
      args: [],
    );
  }

  /// `Continue`
  String get kontinue {
    return Intl.message(
      'Continue',
      name: 'kontinue',
      desc: '',
      args: [],
    );
  }

  /// `Thanks for using our app`
  String get thanksForUsingOurApp {
    return Intl.message(
      'Thanks for using our app',
      name: 'thanksForUsingOurApp',
      desc: '',
      args: [],
    );
  }

  /// `OTP Verification`
  String get otpVerification {
    return Intl.message(
      'OTP Verification',
      name: 'otpVerification',
      desc: '',
      args: [],
    );
  }

  /// `Enter the verification code we just sent to {identifier}`
  String enterTheVerificationCodeWeSentTo(Object identifier) {
    return Intl.message(
      'Enter the verification code we just sent to $identifier',
      name: 'enterTheVerificationCodeWeSentTo',
      desc: '',
      args: [identifier],
    );
  }

  /// `Didn’t receive the code?`
  String get didNotReceiveCode {
    return Intl.message(
      'Didn’t receive the code?',
      name: 'didNotReceiveCode',
      desc: '',
      args: [],
    );
  }

  /// `Resend OTP`
  String get resendOTP {
    return Intl.message(
      'Resend OTP',
      name: 'resendOTP',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  /// `OTP Correct`
  String get otpCorrect {
    return Intl.message(
      'OTP Correct',
      name: 'otpCorrect',
      desc: '',
      args: [],
    );
  }

  /// `Please setup your preference`
  String get pleaseSetUpYourPreference {
    return Intl.message(
      'Please setup your preference',
      name: 'pleaseSetUpYourPreference',
      desc: '',
      args: [],
    );
  }

  /// `Select which contact details should we use to reset your password`
  String get selectWhichContactDetails {
    return Intl.message(
      'Select which contact details should we use to reset your password',
      name: 'selectWhichContactDetails',
      desc: '',
      args: [],
    );
  }

  /// `VIA SMS`
  String get viaSMS {
    return Intl.message(
      'VIA SMS',
      name: 'viaSMS',
      desc: '',
      args: [],
    );
  }

  /// `VIA EMAIL`
  String get viaEmail {
    return Intl.message(
      'VIA EMAIL',
      name: 'viaEmail',
      desc: '',
      args: [],
    );
  }

  /// `Code has been sent to {phoneNumber}`
  String codeSentTo(Object phoneNumber) {
    return Intl.message(
      'Code has been sent to $phoneNumber',
      name: 'codeSentTo',
      desc: '',
      args: [phoneNumber],
    );
  }

  /// `Please set a new password`
  String get pleaseSetANewPassword {
    return Intl.message(
      'Please set a new password',
      name: 'pleaseSetANewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Create a new password`
  String get createANewPassword {
    return Intl.message(
      'Create a new password',
      name: 'createANewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Welcome To BuzzMap`
  String get welcomeToBuzzMap {
    return Intl.message(
      'Welcome To BuzzMap',
      name: 'welcomeToBuzzMap',
      desc: '',
      args: [],
    );
  }

  /// `Homepage`
  String get homepage {
    return Intl.message(
      'Homepage',
      name: 'homepage',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  /// `Exploring Upcoming And Nearby Event`
  String get exploringUpcomingAndNearbyEvent {
    return Intl.message(
      'Exploring Upcoming And Nearby Event',
      name: 'exploringUpcomingAndNearbyEvent',
      desc: '',
      args: [],
    );
  }

  /// `Expand your network and join communities`
  String get expandYourNetwork {
    return Intl.message(
      'Expand your network and join communities',
      name: 'expandYourNetwork',
      desc: '',
      args: [],
    );
  }

  /// `Easily Add Events To Your Calendar`
  String get easilyAddEventsToYourCalendar {
    return Intl.message(
      'Easily Add Events To Your Calendar',
      name: 'easilyAddEventsToYourCalendar',
      desc: '',
      args: [],
    );
  }

  /// `Find Your Favourite Events`
  String get findYouFavouriteEvents {
    return Intl.message(
      'Find Your Favourite Events',
      name: 'findYouFavouriteEvents',
      desc: '',
      args: [],
    );
  }

  /// `Discover Exciting Sports Events, Live Concerts, Inspiring Seminars, and Much More`
  String get discoverExcitingEvents {
    return Intl.message(
      'Discover Exciting Sports Events, Live Concerts, Inspiring Seminars, and Much More',
      name: 'discoverExcitingEvents',
      desc: '',
      args: [],
    );
  }

  /// `Next`
  String get next {
    return Intl.message(
      'Next',
      name: 'next',
      desc: '',
      args: [],
    );
  }

  /// `Skip`
  String get skip {
    return Intl.message(
      'Skip',
      name: 'skip',
      desc: '',
      args: [],
    );
  }

  /// `Login Now`
  String get loginNow {
    return Intl.message(
      'Login Now',
      name: 'loginNow',
      desc: '',
      args: [],
    );
  }

  /// `sec`
  String get seconds {
    return Intl.message(
      'sec',
      name: 'seconds',
      desc: '',
      args: [],
    );
  }

  /// `Select Your Interest`
  String get selectYourInterest {
    return Intl.message(
      'Select Your Interest',
      name: 'selectYourInterest',
      desc: '',
      args: [],
    );
  }

  /// `Profile`
  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: '',
      args: [],
    );
  }

  /// `Interest`
  String get interests {
    return Intl.message(
      'Interest',
      name: 'interests',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  /// `Edit Profile`
  String get editProfile {
    return Intl.message(
      'Edit Profile',
      name: 'editProfile',
      desc: '',
      args: [],
    );
  }

  /// `Notification`
  String get notification {
    return Intl.message(
      'Notification',
      name: 'notification',
      desc: '',
      args: [],
    );
  }

  /// `Security`
  String get security {
    return Intl.message(
      'Security',
      name: 'security',
      desc: '',
      args: [],
    );
  }

  /// `Privacy Policy`
  String get privacyPolicy {
    return Intl.message(
      'Privacy Policy',
      name: 'privacyPolicy',
      desc: '',
      args: [],
    );
  }

  /// `Help Center`
  String get helpCenter {
    return Intl.message(
      'Help Center',
      name: 'helpCenter',
      desc: '',
      args: [],
    );
  }

  /// `LogOut`
  String get logout {
    return Intl.message(
      'LogOut',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  /// `Update`
  String get update {
    return Intl.message(
      'Update',
      name: 'update',
      desc: '',
      args: [],
    );
  }

  /// `General Notification`
  String get generalNotification {
    return Intl.message(
      'General Notification',
      name: 'generalNotification',
      desc: '',
      args: [],
    );
  }

  /// `Sound`
  String get sounds {
    return Intl.message(
      'Sound',
      name: 'sounds',
      desc: '',
      args: [],
    );
  }

  /// `App Updates`
  String get appUpdates {
    return Intl.message(
      'App Updates',
      name: 'appUpdates',
      desc: '',
      args: [],
    );
  }

  /// `Change Password`
  String get changePassword {
    return Intl.message(
      'Change Password',
      name: 'changePassword',
      desc: '',
      args: [],
    );
  }

  /// `OLD PASSWORD`
  String get oldPassword {
    return Intl.message(
      'OLD PASSWORD',
      name: 'oldPassword',
      desc: '',
      args: [],
    );
  }

  /// `NEW PASSWORD`
  String get newPassword {
    return Intl.message(
      'NEW PASSWORD',
      name: 'newPassword',
      desc: '',
      args: [],
    );
  }

  /// `CONFIRM PASSWORD`
  String get confirmNewPassword {
    return Intl.message(
      'CONFIRM PASSWORD',
      name: 'confirmNewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Events`
  String get events {
    return Intl.message(
      'Events',
      name: 'events',
      desc: '',
      args: [],
    );
  }

  /// `Location`
  String get location {
    return Intl.message(
      'Location',
      name: 'location',
      desc: '',
      args: [],
    );
  }

  /// `Calendar`
  String get calendar {
    return Intl.message(
      'Calendar',
      name: 'calendar',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to log out ?`
  String get areYourSureYouWantToLogout {
    return Intl.message(
      'Are you sure you want to log out ?',
      name: 'areYourSureYouWantToLogout',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Yes, Logout`
  String get yesLogout {
    return Intl.message(
      'Yes, Logout',
      name: 'yesLogout',
      desc: '',
      args: [],
    );
  }

  /// `Search`
  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Featured`
  String get featured {
    return Intl.message(
      'Featured',
      name: 'featured',
      desc: '',
      args: [],
    );
  }

  /// `See All`
  String get seeAll {
    return Intl.message(
      'See All',
      name: 'seeAll',
      desc: '',
      args: [],
    );
  }

  /// `Book Now`
  String get bookNow {
    return Intl.message(
      'Book Now',
      name: 'bookNow',
      desc: '',
      args: [],
    );
  }

  /// `You have no notifications`
  String get youHaveNoNotifications {
    return Intl.message(
      'You have no notifications',
      name: 'youHaveNoNotifications',
      desc: '',
      args: [],
    );
  }

  /// `You have no bookmarked event`
  String get youHaveNoBookmarkedEvent {
    return Intl.message(
      'You have no bookmarked event',
      name: 'youHaveNoBookmarkedEvent',
      desc: '',
      args: [],
    );
  }

  /// `Bookmark`
  String get bookmark {
    return Intl.message(
      'Bookmark',
      name: 'bookmark',
      desc: '',
      args: [],
    );
  }

  /// `Trending`
  String get trending {
    return Intl.message(
      'Trending',
      name: 'trending',
      desc: '',
      args: [],
    );
  }

  /// `Remove from your bookmark ?`
  String get removeFromYourBookmark {
    return Intl.message(
      'Remove from your bookmark ?',
      name: 'removeFromYourBookmark',
      desc: '',
      args: [],
    );
  }

  /// `Yes, Remove`
  String get yesRemove {
    return Intl.message(
      'Yes, Remove',
      name: 'yesRemove',
      desc: '',
      args: [],
    );
  }

  /// `Your device location permission has been denied,please kindly enable to continue`
  String get locationDenied {
    return Intl.message(
      'Your device location permission has been denied,please kindly enable to continue',
      name: 'locationDenied',
      desc: '',
      args: [],
    );
  }

  /// `Location permissions are denied`
  String get locationPermissionsAreDenied {
    return Intl.message(
      'Location permissions are denied',
      name: 'locationPermissionsAreDenied',
      desc: '',
      args: [],
    );
  }

  /// `Location permissions are permanently denied, we cannot request permissions.`
  String get locationPermissionsPermanentlyDenied {
    return Intl.message(
      'Location permissions are permanently denied, we cannot request permissions.',
      name: 'locationPermissionsPermanentlyDenied',
      desc: '',
      args: [],
    );
  }

  /// `Permission denied`
  String get permissionDenied {
    return Intl.message(
      'Permission denied',
      name: 'permissionDenied',
      desc: '',
      args: [],
    );
  }

  /// `Okay`
  String get ok {
    return Intl.message(
      'Okay',
      name: 'ok',
      desc: '',
      args: [],
    );
  }

  /// `No results found`
  String get noResultsFound {
    return Intl.message(
      'No results found',
      name: 'noResultsFound',
      desc: '',
      args: [],
    );
  }

  /// `Please try another keyword`
  String get pleaseTryAnotherKeyword {
    return Intl.message(
      'Please try another keyword',
      name: 'pleaseTryAnotherKeyword',
      desc: '',
      args: [],
    );
  }

  /// `Search Results`
  String get searchResults {
    return Intl.message(
      'Search Results',
      name: 'searchResults',
      desc: '',
      args: [],
    );
  }

  /// `{count} found`
  String found(Object count) {
    return Intl.message(
      '$count found',
      name: 'found',
      desc: '',
      args: [count],
    );
  }

  /// `Select Your Location`
  String get selectYourLocation {
    return Intl.message(
      'Select Your Location',
      name: 'selectYourLocation',
      desc: '',
      args: [],
    );
  }

  /// `Add My Location`
  String get addMyLocation {
    return Intl.message(
      'Add My Location',
      name: 'addMyLocation',
      desc: '',
      args: [],
    );
  }

  /// `Event Around You`
  String get eventAroundYou {
    return Intl.message(
      'Event Around You',
      name: 'eventAroundYou',
      desc: '',
      args: [],
    );
  }

  /// `Event List`
  String get eventList {
    return Intl.message(
      'Event List',
      name: 'eventList',
      desc: '',
      args: [],
    );
  }

  /// `You have no events`
  String get youHaveNoEvents {
    return Intl.message(
      'You have no events',
      name: 'youHaveNoEvents',
      desc: '',
      args: [],
    );
  }

  /// `Add to My Calender`
  String get addToCalendar {
    return Intl.message(
      'Add to My Calender',
      name: 'addToCalendar',
      desc: '',
      args: [],
    );
  }

  /// `See on Maps`
  String get seeOnMaps {
    return Intl.message(
      'See on Maps',
      name: 'seeOnMaps',
      desc: '',
      args: [],
    );
  }

  /// `View Participant Discussion`
  String get viewParticipantsDiscussions {
    return Intl.message(
      'View Participant Discussion',
      name: 'viewParticipantsDiscussions',
      desc: '',
      args: [],
    );
  }

  /// `About Event`
  String get aboutEvent {
    return Intl.message(
      'About Event',
      name: 'aboutEvent',
      desc: '',
      args: [],
    );
  }

  /// `Reviews`
  String get reviews {
    return Intl.message(
      'Reviews',
      name: 'reviews',
      desc: '',
      args: [],
    );
  }

  /// `Coming soon (after event)`
  String get comingSoonAfterEvent {
    return Intl.message(
      'Coming soon (after event)',
      name: 'comingSoonAfterEvent',
      desc: '',
      args: [],
    );
  }

  /// `Rate Event`
  String get rateEvent {
    return Intl.message(
      'Rate Event',
      name: 'rateEvent',
      desc: '',
      args: [],
    );
  }

  /// `Rate Now!`
  String get rateNow {
    return Intl.message(
      'Rate Now!',
      name: 'rateNow',
      desc: '',
      args: [],
    );
  }

  /// `Add Comment`
  String get addComment {
    return Intl.message(
      'Add Comment',
      name: 'addComment',
      desc: '',
      args: [],
    );
  }

  /// `Max 250 words`
  String get maxWord {
    return Intl.message(
      'Max 250 words',
      name: 'maxWord',
      desc: '',
      args: [],
    );
  }

  /// `My Calendar Event`
  String get myCalendarEvent {
    return Intl.message(
      'My Calendar Event',
      name: 'myCalendarEvent',
      desc: '',
      args: [],
    );
  }

  /// `Upload Profile Picture`
  String get uploadProfilePicture {
    return Intl.message(
      'Upload Profile Picture',
      name: 'uploadProfilePicture',
      desc: '',
      args: [],
    );
  }

  /// `Remove Picture`
  String get removePicture {
    return Intl.message(
      'Remove Picture',
      name: 'removePicture',
      desc: '',
      args: [],
    );
  }

  /// `Take Photo`
  String get takePhoto {
    return Intl.message(
      'Take Photo',
      name: 'takePhoto',
      desc: '',
      args: [],
    );
  }

  /// `Open Gallery`
  String get openGallery {
    return Intl.message(
      'Open Gallery',
      name: 'openGallery',
      desc: '',
      args: [],
    );
  }

  /// `No File Selected`
  String get noFileSelected {
    return Intl.message(
      'No File Selected',
      name: 'noFileSelected',
      desc: '',
      args: [],
    );
  }

  /// `File too large. Max size is {allowedSize}MB`
  String fileTooLarge(Object allowedSize) {
    return Intl.message(
      'File too large. Max size is ${allowedSize}MB',
      name: 'fileTooLarge',
      desc: '',
      args: [allowedSize],
    );
  }

  /// `Profile Picture Uploaded`
  String get profilePictureUploaded {
    return Intl.message(
      'Profile Picture Uploaded',
      name: 'profilePictureUploaded',
      desc: '',
      args: [],
    );
  }

  /// `Profile Picture Upload Failed`
  String get profilePictureUploadFailed {
    return Intl.message(
      'Profile Picture Upload Failed',
      name: 'profilePictureUploadFailed',
      desc: '',
      args: [],
    );
  }

  /// `Event added to calendar`
  String get eventAddedToCalendar {
    return Intl.message(
      'Event added to calendar',
      name: 'eventAddedToCalendar',
      desc: '',
      args: [],
    );
  }

  /// `Hot`
  String get hot {
    return Intl.message(
      'Hot',
      name: 'hot',
      desc: '',
      args: [],
    );
  }

  /// `Good`
  String get good {
    return Intl.message(
      'Good',
      name: 'good',
      desc: '',
      args: [],
    );
  }

  /// `Ongoing Live`
  String get ongoingLive {
    return Intl.message(
      'Ongoing Live',
      name: 'ongoingLive',
      desc: '',
      args: [],
    );
  }

  /// `Light Mode`
  String get lightMode {
    return Intl.message(
      'Light Mode',
      name: 'lightMode',
      desc: '',
      args: [],
    );
  }

  /// `Dark Mode`
  String get darkMode {
    return Intl.message(
      'Dark Mode',
      name: 'darkMode',
      desc: '',
      args: [],
    );
  }

  /// `Event has been added to calender`
  String get eventHasBeenAddedToCalendar {
    return Intl.message(
      'Event has been added to calender',
      name: 'eventHasBeenAddedToCalendar',
      desc: '',
      args: [],
    );
  }

  /// `Event has been removed from calender`
  String get eventHasBeenRemovedFromCalendar {
    return Intl.message(
      'Event has been removed from calender',
      name: 'eventHasBeenRemovedFromCalendar',
      desc: '',
      args: [],
    );
  }

  /// `Event has been bookmarked`
  String get eventHasBeenBookmarked {
    return Intl.message(
      'Event has been bookmarked',
      name: 'eventHasBeenBookmarked',
      desc: '',
      args: [],
    );
  }

  /// `Event has been removed from bookmark`
  String get eventHasBeenRemovedFromBookmark {
    return Intl.message(
      'Event has been removed from bookmark',
      name: 'eventHasBeenRemovedFromBookmark',
      desc: '',
      args: [],
    );
  }

  /// `Remove from calender`
  String get removeFromCalendar {
    return Intl.message(
      'Remove from calender',
      name: 'removeFromCalendar',
      desc: '',
      args: [],
    );
  }

  /// `You have successfully rated this event`
  String get youHaveSuccessfullyRated {
    return Intl.message(
      'You have successfully rated this event',
      name: 'youHaveSuccessfullyRated',
      desc: '',
      args: [],
    );
  }

  /// `Nearby Your Location`
  String get nearByYourLocation {
    return Intl.message(
      'Nearby Your Location',
      name: 'nearByYourLocation',
      desc: '',
      args: [],
    );
  }

  /// `Create New Event`
  String get createNewEvent {
    return Intl.message(
      'Create New Event',
      name: 'createNewEvent',
      desc: '',
      args: [],
    );
  }

  /// `Add Cover Photo`
  String get addCoverPhotos {
    return Intl.message(
      'Add Cover Photo',
      name: 'addCoverPhotos',
      desc: '',
      args: [],
    );
  }

  /// `Create  New Event & Publish`
  String get createNewEventAndPublish {
    return Intl.message(
      'Create  New Event & Publish',
      name: 'createNewEventAndPublish',
      desc: '',
      args: [],
    );
  }

  /// `Event Details`
  String get eventDetail {
    return Intl.message(
      'Event Details',
      name: 'eventDetail',
      desc: '',
      args: [],
    );
  }

  /// `Event Name`
  String get eventName {
    return Intl.message(
      'Event Name',
      name: 'eventName',
      desc: '',
      args: [],
    );
  }

  /// `Event Description`
  String get eventDescription {
    return Intl.message(
      'Event Description',
      name: 'eventDescription',
      desc: '',
      args: [],
    );
  }

  /// `Event Info`
  String get eventInfo {
    return Intl.message(
      'Event Info',
      name: 'eventInfo',
      desc: '',
      args: [],
    );
  }

  /// `Event Address`
  String get eventAddress {
    return Intl.message(
      'Event Address',
      name: 'eventAddress',
      desc: '',
      args: [],
    );
  }

  /// `PNG, JPG (max. 800x400px)`
  String get imageTypes {
    return Intl.message(
      'PNG, JPG (max. 800x400px)',
      name: 'imageTypes',
      desc: '',
      args: [],
    );
  }

  /// `Event Country`
  String get country {
    return Intl.message(
      'Event Country',
      name: 'country',
      desc: '',
      args: [],
    );
  }

  /// `Event City`
  String get city {
    return Intl.message(
      'Event City',
      name: 'city',
      desc: '',
      args: [],
    );
  }

  /// `Event City`
  String get timeZone {
    return Intl.message(
      'Event City',
      name: 'timeZone',
      desc: '',
      args: [],
    );
  }

  /// `Event Category`
  String get eventCategory {
    return Intl.message(
      'Event Category',
      name: 'eventCategory',
      desc: '',
      args: [],
    );
  }

  /// `This field is required`
  String get thisFieldIsRequired {
    return Intl.message(
      'This field is required',
      name: 'thisFieldIsRequired',
      desc: '',
      args: [],
    );
  }

  /// `Event Start Date`
  String get eventStartDate {
    return Intl.message(
      'Event Start Date',
      name: 'eventStartDate',
      desc: '',
      args: [],
    );
  }

  /// `Rating Saved`
  String get ratingSaved {
    return Intl.message(
      'Rating Saved',
      name: 'ratingSaved',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
