import 'package:dio/dio.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/forgot_password_model.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/update_password_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import '../services/api_service.dart';

part 'forgot_password_state.dart';

class ForgotPasswordCubit extends Cubit<ForgotPasswordState> {
  final ForgotPasswordApiService apiService;

  ForgotPasswordCubit({required this.apiService})
      : super(ForgotPasswordInitial());

  void forgotPassword(
      {required ForgotPasswordModel forgotPasswordModel}) async {
    emit(ForgotPasswordLoading());
    try {
      final response = await apiService.forgotPassword(forgotPasswordModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        debugPrint('Response: ${response.data}');
        emit(ForgotPasswordSuccess(message: response.data['message']));
      } else {
        emit(ForgotPasswordFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ForgotPasswordFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ForgotPasswordFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void validateOTP({required VerifyOtpModel verifyOtpModel}) async {
    emit(ValidateOTPLoading());
    try {
      final response = await apiService.verifyOtp(verifyOtpModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(ValidateOTPSuccess(message: response.data['message']));
      } else {
        emit(ValidateOTPFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ValidateOTPFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ValidateOTPFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void updatePassword(
      {required UpdatePasswordModel updatePasswordModel}) async {
    emit(UpdatePasswordLoading());
    try {
      final response = await apiService.updatePassword(updatePasswordModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(UpdatePasswordSuccess(message: response.data['message']));
      } else {
        emit(UpdatePasswordFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdatePasswordFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdatePasswordFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void resendOTP({required ForgotPasswordModel forgotPasswordModel}) async {
    emit(ResendOTPLoading());
    try {
      final response = await apiService.resendOTP(forgotPasswordModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        debugPrint('Response: ${response.data}');
        emit(ResendOTPSuccess(message: response.data['message']));
      } else {
        emit(ResendOTPFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ResendOTPFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ResendOTPFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
