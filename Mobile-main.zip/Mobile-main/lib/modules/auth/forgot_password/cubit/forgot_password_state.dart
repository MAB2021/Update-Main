part of 'forgot_password_cubit.dart';

@immutable
abstract class ForgotPasswordState {}

class ForgotPasswordInitial extends ForgotPasswordState {}

// Forgot password

class ForgotPasswordLoading extends ForgotPasswordState {}

class ForgotPasswordSuccess extends ForgotPasswordState {
  final String message;

  ForgotPasswordSuccess({required this.message});
}

class ForgotPasswordFailed extends ForgotPasswordState {
  final String errorMessage;

  ForgotPasswordFailed({required this.errorMessage});
}

//Validate otp state

class ValidateOTPLoading extends ForgotPasswordState {}

class ValidateOTPSuccess extends ForgotPasswordState {
  final String message;

  ValidateOTPSuccess({required this.message});
}

class ValidateOTPFailed extends ForgotPasswordState {
  final String errorMessage;

  ValidateOTPFailed({required this.errorMessage});
}

//Update password state

class UpdatePasswordLoading extends ForgotPasswordState {}

class UpdatePasswordSuccess extends ForgotPasswordState {
  final String message;

  UpdatePasswordSuccess({required this.message});
}

class UpdatePasswordFailed extends ForgotPasswordState {
  final String errorMessage;

  UpdatePasswordFailed({required this.errorMessage});
}

//Resend OTP

class ResendOTPLoading extends ForgotPasswordState {}

class ResendOTPSuccess extends ForgotPasswordState {
  final String message;

  ResendOTPSuccess({required this.message});
}

class ResendOTPFailed extends ForgotPasswordState {
  final String errorMessage;

  ResendOTPFailed({required this.errorMessage});
}
