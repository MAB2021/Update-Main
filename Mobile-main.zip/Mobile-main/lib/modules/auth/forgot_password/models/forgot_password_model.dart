import 'dart:convert';

ForgotPasswordModel forgotPasswordModelFromJson(String str) =>
    ForgotPasswordModel.fromJson(json.decode(str));

String forgotPasswordModelToJson(ForgotPasswordModel data) =>
    json.encode(data.toJson());

class ForgotPasswordModel {
  final String? email;
  final String? phoneNumber;
  final bool? resendOtp;

  ForgotPasswordModel({
    this.email,
    this.phoneNumber,
    this.resendOtp,
  });

  factory ForgotPasswordModel.fromJson(Map<String, dynamic> json) =>
      ForgotPasswordModel(
        email: json["email"],
        phoneNumber: json["phone_number"],
        resendOtp: json["resend_otp"],
      );

  Map<String, dynamic> toJson() => {
        "email": email,
        "phone_number": phoneNumber,
        "resend_otp": resendOtp,
      };
}
