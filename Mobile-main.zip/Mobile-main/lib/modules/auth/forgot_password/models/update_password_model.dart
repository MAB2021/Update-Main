import 'dart:convert';

UpdatePasswordModel updatePasswordModelFromJson(String str) =>
    UpdatePasswordModel.fromJson(json.decode(str));

String updatePasswordModelToJson(UpdatePasswordModel data) =>
    json.encode(data.toJson());

class UpdatePasswordModel {
  final String? email;
  final String? phoneNumber;
  final String? password;

  UpdatePasswordModel({
    this.email,
    this.phoneNumber,
    this.password,
  });

  factory UpdatePasswordModel.fromJson(Map<String, dynamic> json) =>
      UpdatePasswordModel(
        email: json["email"],
        phoneNumber: json["phone_number"],
        password: json["password"],
      );

  Map<String, dynamic> toJson() => {
        "email": email,
        "phone_number": phoneNumber,
        "password": password,
      };
}
