import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/forgot_password/cubit/forgot_password_cubit.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/forgot_password_model.dart';
import 'package:buzz_map/modules/auth/forgot_password/routes/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  bool isFormValid = false;
  bool obscureText = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ForgotPasswordCubit>(),
        listener: (context, state) {
          if (state is ForgotPasswordLoading) {
            isLoading = true;
          } else if (state is ForgotPasswordSuccess) {
            isLoading = false;
            goToVerificationScreen();
          } else if (state is ForgotPasswordFailed) {
            isLoading = false;
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const CustomBackButton(),
                        Text(S.current.forgotPassword,
                            style: Theme.of(context).textTheme.displayMedium),
                      ],
                    ),
                    10.h.verticalSpace,
                    Text(S.current.selectWhichContactDetails,
                        style: Theme.of(context).textTheme.titleMedium),
                    // 24.h.verticalSpace,
                    // InputText(
                    //   controller: _phoneNumberController,
                    //   labelText: S.current.viaSMS,
                    //   keyboardType: TextInputType.phone,
                    //   validator: (value) => Validator.validateMobile(value),
                    //   textInputAction: TextInputAction.next,
                    //   onChanged: (value) => checkFormValid(),
                    //   isFilled: true,
                    //   prefixWidget: const BuzzMapAssetImage(
                    //     url: AssetResources.nigeria,
                    //   ),
                    // ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _emailController,
                      labelText: S.current.viaEmail,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) => Validator.validateEmail(value),
                      textInputAction: TextInputAction.done,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.message,
                      ),
                    ),
                    30.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: isFormValid ? () => _submit() : null,
                      textColor: Colors.white,
                      child: isLoading
                          ? const CustomButtonLoader()
                          : Text(
                              S.current.kontinue,
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  checkFormValid() {
    setState(() {
      if (_formKey.currentState!.validate()) {
        isFormValid = true;
      } else {
        isFormValid = false;
      }
    });
  }

  _submit() {
    FocusScope.of(context).unfocus();
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      getIt<ForgotPasswordCubit>().forgotPassword(
        forgotPasswordModel: ForgotPasswordModel(
            phoneNumber: "",
            email: _emailController.text.trim(),
            resendOtp: false),
      );
    }
  }

  goToVerificationScreen() {
    getIt<NavigationService>().toWithParameters(
        routeName: ForgotPasswordRoutes.forgotPasswordOtpVerification,
        args: {
          "forgotPasswordModel": ForgotPasswordModel(
              phoneNumber: _phoneNumberController.text,
              email: _emailController.text.trim(),
              resendOtp: true)
        });
  }
}
