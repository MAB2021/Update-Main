class ForgotPasswordRoutes {
  static const String forgotPasswordRoot = 'forgotPasswordRoot';
  static const String forgotPasswordOtpVerification =
      "forgotPasswordOtpVerification";
  static const String resetPassword = 'resetPassword';
}
