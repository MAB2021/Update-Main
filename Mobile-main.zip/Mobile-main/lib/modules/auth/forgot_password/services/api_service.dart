import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/forgot_password_model.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/update_password_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class ForgotPasswordApiService {
  final HttpService http;

  ForgotPasswordApiService({required this.http});

  Future<Response> forgotPassword(ForgotPasswordModel body) async {
    return http.post(AppURL.forgotPassword, data: body.toJson());
  }

  Future<Response> verifyOtp(VerifyOtpModel verifyOtpModel) async {
    return http.post("${AppURL.forgotPassword}${AppURL.validate}",
        data: verifyOtpModel.toJson());
  }

  Future<Response> updatePassword(
      UpdatePasswordModel updatePasswordModel) async {
    return http.post(AppURL.updatePassword, data: updatePasswordModel.toJson());
  }

  Future<Response> resendOTP(ForgotPasswordModel body) async {
    return http.post(AppURL.forgotPassword, data: body.toJson());
  }
}
