import 'dart:async';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/forgot_password/cubit/forgot_password_cubit.dart';
import 'package:buzz_map/modules/auth/forgot_password/models/forgot_password_model.dart';
import 'package:buzz_map/modules/auth/forgot_password/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/modules/auth/sign_up/widgets/success_bottom_sheet.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:buzz_map/shared/widgets/otp_timer_countdown.dart';
import 'package:buzz_map/shared/widgets/pin_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class ForgotPasswordOTPVerificationScreen extends StatefulWidget {
  final ForgotPasswordModel forgotPasswordModel;
  const ForgotPasswordOTPVerificationScreen(
      {super.key, required this.forgotPasswordModel});

  @override
  State<ForgotPasswordOTPVerificationScreen> createState() =>
      _ForgotPasswordOTPVerificationScreenState();
}

class _ForgotPasswordOTPVerificationScreenState
    extends State<ForgotPasswordOTPVerificationScreen> {
  TextEditingController pinController = TextEditingController();
  bool _showResendButton = false;
  bool isFormValid = false;
  bool isLoading = false;

  int _start = AppConstants.resendOtpTime;

  late Timer timer;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ForgotPasswordCubit>(),
        listener: (context, state) {
          if (state is ValidateOTPLoading) {
            isLoading = true;
            DialogUtil.showLoadingDialog(context);
          } else if (state is ValidateOTPSuccess) {
            isLoading = false;
            DialogUtil.dismissWithNavigationService();
            showOTPCorrectBottomSheet();
          } else if (state is ValidateOTPFailed) {
            isLoading = false;
            DialogUtil.dismissWithNavigationService();
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          } else if (state is ResendOTPLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is ResendOTPSuccess) {
            DialogUtil.dismissWithNavigationService();
            NotificationMessage.showMessage(
              context,
              message: state.message,
              isError: false,
            );
          } else if (state is ResendOTPFailed) {
            DialogUtil.dismissWithNavigationService();
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const CustomBackButton(),
                      Text(
                        S.current.forgotPassword,
                        style: Theme.of(context).textTheme.titleLarge!.copyWith(
                            fontWeight: FontWeight.w700, fontSize: 18.sp),
                      ),
                    ],
                  ),
                  10.h.verticalSpace,
                  Text(
                    S.current.codeSentTo(widget.forgotPasswordModel.email ??
                        widget.forgotPasswordModel.phoneNumber ??
                        ""),
                    style: Theme.of(context).textTheme.titleMedium,
                    textAlign: TextAlign.center,
                  ),
                  20.h.verticalSpace,
                  OtpTimerCountdownWidget(
                    showResendButton: _showResendButton,
                    start: _start,
                  ),
                  40.h.verticalSpace,
                  Center(
                    child: BuzzMapPinWidget(
                      controller: pinController,
                      length: AppConstants.otpPINLength,
                      onCompleted: (pin) {
                        if (pin.length == AppConstants.otpPINLength) {
                          setState(() {
                            isFormValid = true;
                          });
                        }
                      },
                    ),
                  ),
                  resendOTPWidget(),
                  BuzzMapButton(
                    text: S.current.verify,
                    onPressed: isFormValid ? () => submit() : null,
                    // isFormValid ? () => submit() : null,
                    textColor: Colors.white,
                    child: isLoading
                        ? const CustomButtonLoader()
                        : Text(
                            S.current.verify,
                            style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget resendOTPWidget() {
    return GestureDetector(
      onTap: () {
        if (_showResendButton) {
          getIt<ForgotPasswordCubit>()
              .resendOTP(forgotPasswordModel: widget.forgotPasswordModel);
          setState(() {
            _start = AppConstants.resendOtpTime;
            _showResendButton = false;
          });
          startTimer();
        }
      },
      child: Column(
        children: [
          51.h.verticalSpace,
          Text(
            S.current.didNotReceiveCode,
            style: Theme.of(context).textTheme.displayLarge,
            textAlign: TextAlign.center,
          ),
          10.h.verticalSpace,
          Text(
            S.current.resendOTP,
            style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                  fontSize: 16.sp,
                ),
            textAlign: TextAlign.center,
          ),
          24.h.verticalSpace,
        ],
      ),
    );
  }

  void submit() {
    getIt<ForgotPasswordCubit>().validateOTP(
        verifyOtpModel: VerifyOtpModel(
      email: widget.forgotPasswordModel.email,
      otp: pinController.text,
      phoneNumber: widget.forgotPasswordModel.email,
    ));
  }

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    timer = Timer.periodic(
      oneSec,
      (Timer timer) {
        if (_start == 0) {
          setState(() {
            _showResendButton = true;
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  showOTPCorrectBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      elevation: 0,
      isDismissible: false,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25.r),
        ),
      ),
      builder: (_) => AccountSuccessfullyCreated(
        title: S.current.otpCorrect,
        subTitle: S.current.pleaseSetANewPassword,
        onPressed: () {
          getIt<NavigationService>().toWithParameters(
              routeName: ForgotPasswordRoutes.resetPassword,
              args: {
                "email": widget.forgotPasswordModel.email,
                "phoneNumber": widget.forgotPasswordModel.phoneNumber
              });
        },
      ),
    );
  }
}
