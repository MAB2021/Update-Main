'`r Sys.Date()`'

- TODO: Created the initial setup of the Login feature/module
