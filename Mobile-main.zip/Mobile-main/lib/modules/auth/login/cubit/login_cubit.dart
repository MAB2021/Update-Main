import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/modules/notification/cubit/notification_cubit.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:buzz_map/modules/auth/login/models/login_model.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/api_service.dart';

part 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {
  final LoginApiService apiService;

  LoginCubit({required this.apiService}) : super(LoginInitial());

  void login({required LoginModel loginModel}) async {
    emit(LoginLoading());
    try {
      final response = await apiService.login(loginModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        var accessToken = response.data["token"];
        UserTokenManager.insertAccessToken(accessToken);
        User userModel = User.fromJson(response.data['user']);
        getIt<LocalStorageUtils>()
            .saveObject<User>(AppConstants.userObject, userModel);
        getIt.registerSingleton<User>(userModel);
        userCurrentAddress.value = userModel.town;

        if (userModel.geoLocation != null) {
          userCurrentPosition.value = LatLng(userModel.geoLocation!.latitude,
              userModel.geoLocation!.longitude);
        } else {
          getCurrentPosition();
        }

        getIt<NotificationCubit>().addDeviceToken();

        saveLoginCredentials(
            email: loginModel.email!, password: loginModel.password!);
        getIt<ProfileCubit>().getProfile();
        emit(LoginSuccess(userModel: userModel));
      } else {
        emit(LoginFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(LoginFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(LoginFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  Future<void> getCurrentPosition() async {
    Position position = await determinePosition(
        getIt<NavigationService>().navigatorKey.currentContext!);
    getIt<LocationCubit>().findCoordinateAddress(
        LatLng(position.latitude, position.longitude), false);
    userCurrentPosition.value = LatLng(position.latitude, position.longitude);
    getIt<HomeCubit>().getCategories();
    getIt<EventsCubit>().getEvents(pageNumber: 1);
  }

  //! remove this method from here before pushing the code to prod
  //Write login credentials to shared preferences
  void saveLoginCredentials({required String email, required String password}) {
    getIt<LocalStorageUtils>().write(AppConstants.email, email);
    getIt<LocalStorageUtils>().write(AppConstants.password, password);
  }
}
