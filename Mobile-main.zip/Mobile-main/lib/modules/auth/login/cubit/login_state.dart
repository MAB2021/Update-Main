part of 'login_cubit.dart';

@immutable
abstract class LoginState {}

class LoginInitial extends LoginState {}

//Login login state
class LoginLoading extends LoginState {}

class LoginSuccess extends LoginState {
  final User userModel;

  LoginSuccess({required this.userModel});
}

class LoginFailed extends LoginState {
  final String errorMessage;

  LoginFailed({required this.errorMessage});
}
