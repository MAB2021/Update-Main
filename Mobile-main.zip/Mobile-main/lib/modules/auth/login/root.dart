import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/forgot_password/routes/route.dart';
import 'package:buzz_map/modules/auth/login/cubit/login_cubit.dart';
import 'package:buzz_map/modules/auth/login/models/login_model.dart';
import 'package:buzz_map/modules/auth/sign_up/routes/route.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool isFormValid = false;
  bool obscureText = true;
  bool isLoading = false;

  @override
  void initState() {
    isFormValid = true;
    // _getLoginCredentials();
    if (kDebugMode) {
      _emailController.text = "jookoyoski@gmail.com";
      _passwordController.text = "Jokoyoski200@";
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<LoginCubit>(),
        listener: (context, state) {
          if (state is LoginLoading) {
            isLoading = true;
          } else if (state is LoginSuccess) {
            isLoading = false;
            // getIt<NavigationService>()
            //     .to(routeName: LocationRoutes.selectLocation);
            getIt<NavigationService>().to(routeName: RootRoutes.home);
          } else if (state is LoginFailed) {
            isLoading = false;
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(S.current.loginToYouAccount,
                          style: Theme.of(context).textTheme.titleLarge),
                    ),
                    10.h.verticalSpace,
                    Center(
                      child: Text(S.current.enterYouInformationBelowToSignIn,
                          style: Theme.of(context).textTheme.titleMedium),
                    ),
                    34.h.verticalSpace,
                    InputText(
                      controller: _emailController,
                      labelText: S.current.emailAddress,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) => Validator.validateEmail(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: BuzzMapAssetImage(
                        url: _emailController.text.isEmpty
                            ? AssetResources.message
                            : isDarkMode
                                ? AssetResources.whiteMessage
                                : AssetResources.darkMessage,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      prefixWidget: BuzzMapAssetImage(
                        url: _passwordController.text.isEmpty
                            ? AssetResources.password
                            : isDarkMode
                                ? AssetResources.whitePadlock
                                : AssetResources.darkPadlock,
                      ),
                      controller: _passwordController,
                      labelText: S.current.password,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validatePassword(value),
                      isPassword: obscureText,
                      suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            obscureText = !obscureText;
                          });
                        },
                        icon: BuzzMapAssetImage(
                          url: isDarkMode
                              ? (obscureText
                                  ? AssetResources.passwordVisible
                                  : AssetResources.passwordNotVisible)
                              : AssetResources.darkPassword,
                        ),
                      ),
                      textInputAction: TextInputAction.done,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                    ),
                    20.h.verticalSpace,
                    GestureDetector(
                      onTap: () {
                        getIt<NavigationService>().to(
                            routeName: ForgotPasswordRoutes.forgotPasswordRoot);
                      },
                      child: Text(
                        "${S.current.forgotPassword}?",
                        style: GoogleFonts.outfit(
                          fontSize: 16.sp,
                          color: Theme.of(context).primaryColorDark,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    40.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: isFormValid ? () => _login() : null,
                      textColor: Colors.white,
                      child: isLoading
                          ? const CustomButtonLoader()
                          : Text(
                              S.current.login,
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                    20.h.verticalSpace,
                    Center(
                      child: RichText(
                          text: TextSpan(
                            text: S.of(context).doNotHaveAnAccount,
                            style: Theme.of(context).textTheme.titleMedium,
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => getIt<NavigationService>()
                                  .to(routeName: SignUpRoutes.signUpRoot),
                            children: <TextSpan>[
                              TextSpan(
                                text: S.of(context).signUp,
                                style: GoogleFonts.outfit(
                                  fontSize: 16.sp,
                                  color: Theme.of(context).primaryColorDark,
                                  fontWeight: FontWeight.w700,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () => getIt<NavigationService>()
                                      .to(routeName: SignUpRoutes.signUpRoot),
                              ),
                            ],
                          ),
                          textAlign: TextAlign.center),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  _login() {
    FocusScope.of(context).unfocus();
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      getIt<LoginCubit>().login(
        loginModel: LoginModel(
          email: _emailController.text.trim(),
          password: _passwordController.text,
        ),
      );
    }
    getIt<LocalStorageUtils>().write(AppConstants.isUserFirstTime, 'true');
  }

  checkFormValid() {
    setState(() {
      if (_formKey.currentState!.validate()) {
        isFormValid = true;
      } else {
        isFormValid = false;
      }
    });
  }

  //!remove before production
  //get login credentials
  _getLoginCredentials() async {
    final email = await getIt<LocalStorageUtils>().read(AppConstants.email);
    final password =
        await getIt<LocalStorageUtils>().read(AppConstants.password);
    if (email != null && password != null) {
      _emailController.text = email;
      _passwordController.text = password;
    }
  }
}
