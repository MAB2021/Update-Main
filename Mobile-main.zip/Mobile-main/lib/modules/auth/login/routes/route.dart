class LoginRoutes {
  static const String loginRoot = 'login';
}
