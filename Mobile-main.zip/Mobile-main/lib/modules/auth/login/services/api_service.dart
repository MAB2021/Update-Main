import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/modules/auth/login/models/login_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class LoginApiService {
  final HttpService http;

  LoginApiService({required this.http});

  Future<Response> login(LoginModel body) async {
    return http.post(AppURL.login, data: body.toJson());
  }
}
