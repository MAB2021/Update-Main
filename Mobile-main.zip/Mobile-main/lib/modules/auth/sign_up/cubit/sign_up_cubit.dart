import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/notification/cubit/notification_cubit.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:buzz_map/modules/auth/sign_up/models/sign_up_model.dart';
import 'package:flutter/material.dart';
import '../../../profile/models/user.dart';
import '../services/api_service.dart';

part 'sign_up_state.dart';

class SignUpCubit extends Cubit<SignUpState> {
  final SignUpApiService apiService;

  SignUpCubit({required this.apiService}) : super(SignUpInitial());

  void signUp({required SignUpModel signUpModel}) async {
    emit(SignUpLoading());
    try {
      final response = await apiService.signUp(signUpModel);

      if (response.isSuccessful && response.data['status'] == 200) {
        debugPrint(response.data.toString());
        emit(SignUpSuccess());
      } else {
        emit(SignUpFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(SignUpFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(SignUpFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void validateOTP({required VerifyOtpModel verifyOtpModel}) async {
    emit(ValidateOTPLoading());
    try {
      final response = await apiService.verifyOtp(verifyOtpModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        var accessToken = response.data["data"]["token"];
        UserTokenManager.insertAccessToken(accessToken);
        User userModel = User.fromJson(response.data["data"]['user']);
        getIt<LocalStorageUtils>()
            .saveObject<User>(AppConstants.userObject, userModel);
        getIt.registerSingleton<User>(userModel);

        getIt<NotificationCubit>().addDeviceToken();

        debugPrint(response.data.toString());
        emit(ValidateOTPSuccess(message: response.data['message']));
      } else {
        emit(ValidateOTPFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ValidateOTPFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ValidateOTPFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void resendOTP({required SignUpModel signUpModel}) async {
    emit(ResendOTPLoading());
    try {
      final response = await apiService.resendOTP(signUpModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(ResendOTPSuccess(message: response.data['message']));
      } else {
        emit(ResendOTPFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ResendOTPFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ResendOTPFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
