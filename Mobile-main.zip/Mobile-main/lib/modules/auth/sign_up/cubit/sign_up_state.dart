part of 'sign_up_cubit.dart';

@immutable
abstract class SignUpState {}

class SignUpInitial extends SignUpState {}

//Sign up state

class SignUpLoading extends SignUpState {}

class SignUpSuccess extends SignUpState {
  SignUpSuccess();
}

class SignUpFailed extends SignUpState {
  final String errorMessage;

  SignUpFailed({required this.errorMessage});
}

//Validate OTP
class ValidateOTPLoading extends SignUpState {}

class ValidateOTPSuccess extends SignUpState {
  final String message;

  ValidateOTPSuccess({required this.message});
}

class ValidateOTPFailed extends SignUpState {
  final String errorMessage;

  ValidateOTPFailed({required this.errorMessage});
}

//Resend OTP

class ResendOTPLoading extends SignUpState {}

class ResendOTPSuccess extends SignUpState {
  final String message;

  ResendOTPSuccess({required this.message});
}

class ResendOTPFailed extends SignUpState {
  final String errorMessage;

  ResendOTPFailed({required this.errorMessage});
}
