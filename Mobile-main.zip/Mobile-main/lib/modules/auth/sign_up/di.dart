import 'package:get_it/get_it.dart';
import './services/api_service.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'cubit/sign_up_cubit.dart';
import 'package:buzz_map/configs/app_configs.dart';

void setupSignUp(GetIt ioc) {
  ioc.registerSingleton<SignUpCubit>(SignUpCubit(
    apiService: SignUpApiService(
      http: HttpService(
        baseUrl: AppURL.baseUrl,
        isFormType: false,
      ),
    ),
  ));
}
