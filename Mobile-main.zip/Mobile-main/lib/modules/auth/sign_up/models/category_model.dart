import 'dart:convert';

List<CategoryModel> categoryModelFromJson(String str) =>
    List<CategoryModel>.from(
        json.decode(str).map((x) => CategoryModel.fromJson(x)));

String categoryModelToJson(List<CategoryModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CategoryModel {
  final int id;
  final String categoryName;
  final String icon;
  final String slug;
  final bool? isActive;

  CategoryModel({
    required this.id,
    required this.categoryName,
    required this.icon,
    required this.slug,
    this.isActive,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
        id: json["id"],
        categoryName: json["category_name"],
        icon: json["icon"],
        slug: json["slug"],
        isActive: json["is_active"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "category_name": categoryName,
        "icon": icon,
        "slug": slug,
        "is_active": isActive,
      };
}
