import 'dart:convert';

SignUpModel signUpModelFromJson(String str) =>
    SignUpModel.fromJson(json.decode(str));

String signUpModelToJson(SignUpModel data) => json.encode(data.toJson());

class SignUpModel {
  final String firstName;
  final String lastName;
  final String email;
  final String phoneNumber;
  final String password;
  final bool resendOtp;
  final String countryCode;
  final String dialCode;

  SignUpModel({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phoneNumber,
    required this.password,
    required this.resendOtp,
    required this.countryCode,
    required this.dialCode
  });

  factory SignUpModel.fromJson(Map<String, dynamic> json) => SignUpModel(
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        phoneNumber: json["phone_number"],
        password: json["password"],
        resendOtp: json["resend_otp"],
        countryCode: json["country_code"],
        dialCode: json["dial_code"]
      );

  Map<String, dynamic> toJson() => {
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "phone_number": phoneNumber,
        "password": password,
        "user_type": "Customer",
        "resend_otp": resendOtp,
        "country_code": countryCode,
        "dial_code": dialCode
      };
}
