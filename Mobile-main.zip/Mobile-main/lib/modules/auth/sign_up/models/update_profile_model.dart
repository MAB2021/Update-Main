import 'dart:convert';
import 'package:buzz_map/shared/models/geo_location.dart';

UpdateProfileModel updateProfileModelFromJson(String str) =>
    UpdateProfileModel.fromJson(json.decode(str));

String updateProfileModelToJson(UpdateProfileModel data) =>
    json.encode(data.toJson());

class UpdateProfileModel {
  final List<int>? interests;
  final GeoLocation? location;
  final bool? generalNotification;
  final bool? sound;
  final bool? appUpdates;

  UpdateProfileModel({
    this.interests,
    this.location,
    this.generalNotification,
    this.sound,
    this.appUpdates,
  });

  factory UpdateProfileModel.fromJson(Map<String, dynamic> json) =>
      UpdateProfileModel(
        interests: List<int>.from(json["interests"].map((x) => x)),
        location: GeoLocation.fromJson(json["location"]),
        generalNotification: json["general_notification"],
        sound: json["sound"],
        appUpdates: json["app_updates"],
      );

  Map<String, dynamic> toJson() => {
        if (interests != null && interests?.length != 0)
          "interests": List<dynamic>.from(interests!.map((x) => x)),
        "location": location?.toJson(),
        "general_notification": generalNotification,
        "sound": sound,
        "app_updates": appUpdates,
        // if (generalNotification != null)
        //   "general_notification": generalNotification,
        // if (sound != null) "sound": sound,
        // if (appUpdates != null) "app_updates": appUpdates,
      };
}
