import 'dart:convert';

VerifyOtpModel verifyOtpModelFromJson(String str) => VerifyOtpModel.fromJson(json.decode(str));

String verifyOtpModelToJson(VerifyOtpModel data) => json.encode(data.toJson());

class VerifyOtpModel {
    final String? email;
    final String? phoneNumber;
    final String? otp;

    VerifyOtpModel({
        this.email,
        this.phoneNumber,
        this.otp,
    });

    factory VerifyOtpModel.fromJson(Map<String, dynamic> json) => VerifyOtpModel(
        email: json["email"],
        phoneNumber: json["phone_number"],
        otp: json["otp"],
    );

    Map<String, dynamic> toJson() => {
        "email": email,
        "phone_number": phoneNumber,
        "otp": otp,
    };
}
