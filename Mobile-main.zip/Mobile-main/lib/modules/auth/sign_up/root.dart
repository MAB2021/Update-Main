import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/cubit/sign_up_cubit.dart';
import 'package:buzz_map/modules/auth/sign_up/models/sign_up_model.dart';
import 'package:buzz_map/modules/auth/sign_up/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/widgets/success_bottom_sheet.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/utils/custom_style.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:fl_country_code_picker/fl_country_code_picker.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  String? selectedCountry;
  String selectedCountryCode = "+234";
  String? selectedCountryFlag;
  String? selectedCountryPackage;
  String? countryCode = "NG";

  bool isFormValid = false;
  bool obscureText = true;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    /// Default.
    final countryPicker = FlCountryCodePicker(
      localize: true,
      showDialCode: true,
      showSearchBar: true,
      title: Padding(
        padding: EdgeInsets.only(left: 16.w, top: 10.h, bottom: 10.h),
        child: Text(
          "Select a country",
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w500),
        ),
      ),
      searchBarTextStyle: Theme.of(context).textTheme.headlineSmall,
      countryTextStyle: Theme.of(context).textTheme.titleMedium,
      dialCodeTextStyle: Theme.of(context).textTheme.titleMedium,
      searchBarDecoration: InputDecoration(
        // prefixIconConstraints: BoxConstraints(maxHeight: 40.w),

        labelStyle: Theme.of(context).textTheme.labelSmall,
        hintText: "Select a country",
        hintStyle: Theme.of(context).textTheme.displaySmall,
        isDense: true,
        filled: true,
        fillColor: !AdaptiveTheme.of(context).mode.isDark
            ? AppColors.lightInputFiledColor
            : AppColors.primaryColor,
        border: AppStyles.focusedBorder,
        focusedBorder: AppStyles.focusedBorder,
        disabledBorder: AppStyles.focusBorder,
        enabledBorder: AppStyles.focusBorder,
        errorBorder: AppStyles.focusErrorBorder,
        focusedErrorBorder: AppStyles.focusErrorBorder,
      ),
    );
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<SignUpCubit>(),
        listener: (context, state) {
          if (state is SignUpLoading) {
            isLoading = true;
          } else if (state is SignUpSuccess) {
            isLoading = false;

            showOTPBottomSheet();
          } else if (state is SignUpFailed) {
            isLoading = false;
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Form(
                autovalidateMode: AutovalidateMode.disabled,
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(S.current.signUpForFree,
                          style: Theme.of(context).textTheme.titleLarge),
                    ),
                    10.h.verticalSpace,
                    Center(
                      child: Text(S.current.enterYouInformationBelowToSignIn,
                          style: Theme.of(context).textTheme.titleMedium),
                    ),
                    34.h.verticalSpace,
                    InputText(
                      controller: _fullNameController,
                      labelText: S.current.fullName,
                      keyboardType: TextInputType.name,
                      validator: (value) => Validator.validateFullName(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.user,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _phoneNumberController,
                      labelText: S.current.phoneNumber,
                      keyboardType: TextInputType.number,
                      validator: (value) => Validator.validateMobile(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: GestureDetector(
                        onTap: () async {
                          // Show the country code picker when tapped.
                          final picked = await countryPicker.showPicker(
                              scrollToDeviceLocale: true,
                              backgroundColor:
                                  Theme.of(context).scaffoldBackgroundColor,
                              context: context);
                          // Null check
                          if (picked != null) {
                            setState(() {
                              selectedCountry = picked.name;
                              selectedCountryCode = picked.dialCode;
                              selectedCountryFlag = picked.flagUri;
                              selectedCountryPackage = picked.flagImagePackage;
                              countryCode = picked.code;
                            });
                          }
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10.w),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: BuzzMapAssetImage(
                              height: 30.h,
                              width: 30.w,
                              fit: BoxFit.scaleDown,
                              url:
                                  selectedCountryFlag ?? AssetResources.nigeria,
                              package: selectedCountryPackage,
                            ),
                          ),
                        ),
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _emailController,
                      labelText: S.current.emailAddress,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) => Validator.validateEmail(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.message,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _passwordController,
                      labelText: S.current.password,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validatePassword(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.password,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _confirmPasswordController,
                      labelText: S.current.confirmPassword,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validateConfirmPassword(
                          value, _passwordController.text),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.password,
                      ),
                    ),
                    40.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: isFormValid ? () => submit() : null,
                      textColor: Colors.white,
                      child: isLoading
                          ? const CustomButtonLoader()
                          : Text(
                              S.current.signUp,
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                    20.h.verticalSpace,
                    Center(
                      child: RichText(
                          text: TextSpan(
                            text: S.of(context).alreadyHaveAnAccount,
                            style: Theme.of(context).textTheme.titleMedium,
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => getIt<NavigationService>()
                                  .to(routeName: LoginRoutes.loginRoot),
                            children: <TextSpan>[
                              TextSpan(
                                text: S.of(context).login,
                                style: GoogleFonts.outfit(
                                  fontSize: 16.sp,
                                  color: Theme.of(context).primaryColorDark,
                                  fontWeight: FontWeight.w700,
                                ),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () => getIt<NavigationService>()
                                      .to(routeName: LoginRoutes.loginRoot),
                              ),
                            ],
                          ),
                          textAlign: TextAlign.center),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  submit() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      getIt<SignUpCubit>().signUp(
          signUpModel: SignUpModel(
        firstName: _fullNameController.text.trim().split(" ").first,
        lastName: _fullNameController.text.trim().split(" ").last,
        phoneNumber: "$selectedCountryCode${_phoneNumberController.text}",
        email: _emailController.text.trim(),
        password: _passwordController.text,
        resendOtp: false,
        countryCode: countryCode!,
        dialCode: selectedCountryCode,
      ));
    }
  }

  checkFormValid() {
    setState(() {
      if (_formKey.currentState!.validate()) {
        isFormValid = true;
      } else {
        isFormValid = false;
      }
    });
  }

  goToOTPScreen() {
    getIt<NavigationService>()
        .toWithParameters(routeName: SignUpRoutes.otpVerificationScreen, args: {
      "signUpModel": SignUpModel(
        firstName: _fullNameController.text.trim().split(" ").first,
        lastName: _fullNameController.text.trim().split(" ").last,
        phoneNumber: "$selectedCountryCode${_phoneNumberController.text}",
        email: _emailController.text.trim(),
        password: _passwordController.text,
        resendOtp: true,
        countryCode: countryCode!,
        dialCode: selectedCountryCode,
      )
    });
  }

  showOTPBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      isDismissible: false,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25.r),
        ),
      ),
      builder: (_) => AccountSuccessfullyCreated(
        title: S.current.accountCreationSuccessful,
        subTitle: S.current.weSentYouOtpToYourEmail,
        onPressed: () {
          goToOTPScreen();
        },
      ),
    );
  }
}
