class SignUpRoutes {
  static const String signUpRoot = 'signUp';
  static const String otpVerificationScreen = 'otpVerificationScreen';
}
