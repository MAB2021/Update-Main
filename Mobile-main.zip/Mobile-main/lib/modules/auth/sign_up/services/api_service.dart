import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/modules/auth/sign_up/models/sign_up_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class SignUpApiService {
  final HttpService http;

  SignUpApiService({required this.http});

  Future<Response> signUp(SignUpModel body) async {
    return http.post(AppURL.user, data: body.toJson());
  }

  Future<Response> verifyOtp(VerifyOtpModel body) async {
    return http.post(AppURL.otp, data: body.toJson());
  }

  Future<Response> resendOTP(SignUpModel body) async {
    return http.post(AppURL.user, data: body.toJson());
  }
}
