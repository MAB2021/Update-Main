import 'dart:async';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/cubit/sign_up_cubit.dart';
import 'package:buzz_map/modules/auth/sign_up/models/sign_up_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/verify_otp_model.dart';
import 'package:buzz_map/modules/auth/sign_up/widgets/success_bottom_sheet.dart';
import 'package:buzz_map/modules/interest/routes/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:buzz_map/shared/widgets/otp_timer_countdown.dart';
import 'package:buzz_map/shared/widgets/pin_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class OTPVerificationScreen extends StatefulWidget {
  final SignUpModel signUpModel;
  const OTPVerificationScreen({super.key, required this.signUpModel});

  @override
  State<OTPVerificationScreen> createState() => _OTPVerificationScreenState();
}

class _OTPVerificationScreenState extends State<OTPVerificationScreen> {
  TextEditingController pinController = TextEditingController();
  bool _showResendButton = false;
  bool isFormValid = false;
  bool isLoading = false;

  int _start = AppConstants.resendOtpTime;

  late Timer timer;

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<SignUpCubit>(),
        listener: (context, state) {
          if (state is ValidateOTPLoading) {
            isLoading = true;
          } else if (state is ValidateOTPSuccess) {
            isLoading = false;
            showOTPCorrectBottomSheet();
          } else if (state is ValidateOTPFailed) {
            isLoading = false;
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          } else if (state is ResendOTPSuccess) {
            NotificationMessage.showMessage(
              context,
              message: state.message,
              isError: false,
            );
          } else if (state is ResendOTPFailed) {
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    S.current.otpVerification,
                    style: Theme.of(context).textTheme.titleLarge!.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  20.h.verticalSpace,
                  Text(
                    S.current.enterTheVerificationCodeWeSentTo(
                        widget.signUpModel.email),
                    style: Theme.of(context).textTheme.titleMedium,
                    textAlign: TextAlign.center,
                  ),
                  20.h.verticalSpace,
                  OtpTimerCountdownWidget(
                    showResendButton: _showResendButton,
                    start: _start,
                  ),
                  40.h.verticalSpace,
                  Center(
                    child: BuzzMapPinWidget(
                      controller: pinController,
                      length: AppConstants.otpPINLength,
                      onCompleted: (pin) {
                        if (pin.length == AppConstants.otpPINLength) {
                          setState(() {
                            isFormValid = true;
                          });
                        }
                      },
                    ),
                  ),
                  resendOTPWidget(),
                  BuzzMapButton(
                    onPressed: isFormValid ? () => submit() : null,
                    textColor: Colors.white,
                    child: isLoading
                        ? const CustomButtonLoader()
                        : Text(
                            S.current.verify,
                            style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget resendOTPWidget() {
    return GestureDetector(
      onTap: () {
        if (_showResendButton) {
          getIt<SignUpCubit>().resendOTP(
            signUpModel: widget.signUpModel,
          );
          setState(() {
            _start = AppConstants.resendOtpTime;
            _showResendButton = false;
          });
          startTimer();
        }
      },
      child: Column(
        children: [
          51.h.verticalSpace,
          Text(
            S.current.didNotReceiveCode,
            style: Theme.of(context).textTheme.displayLarge,
            textAlign: TextAlign.center,
          ),
          10.h.verticalSpace,
          Text(
            S.current.resendOTP,
            style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                  fontSize: 16.sp,
                ),
            textAlign: TextAlign.center,
          ),
          24.h.verticalSpace,
        ],
      ),
    );
  }

  void submit() {
    getIt<SignUpCubit>().validateOTP(
        verifyOtpModel: VerifyOtpModel(
      email: widget.signUpModel.email,
      otp: pinController.text,
    ));
  }

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    timer = Timer.periodic(
      oneSec,
      (Timer timer) {
        if (_start == 0) {
          setState(() {
            _showResendButton = true;
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  showOTPCorrectBottomSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      elevation: 0,
      isDismissible: false,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25.r),
        ),
      ),
      builder: (_) => AccountSuccessfullyCreated(
        title: S.current.otpCorrect,
        subTitle: S.current.pleaseSetUpYourPreference,
        onPressed: () {
          getIt<NavigationService>().to(routeName: InterestRoutes.interestRoot);
        },
      ),
    );
  }
}
