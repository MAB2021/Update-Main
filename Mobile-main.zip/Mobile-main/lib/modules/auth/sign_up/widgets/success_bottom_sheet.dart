import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';

class AccountSuccessfullyCreated extends StatefulWidget {
  final String title;
  final String? subTitle;
  final Function onPressed;
  const AccountSuccessfullyCreated(
      {super.key, required this.title, this.subTitle, required this.onPressed});

  @override
  State<AccountSuccessfullyCreated> createState() =>
      _AccountSuccessfullyCreatedState();
}

class _AccountSuccessfullyCreatedState
    extends State<AccountSuccessfullyCreated> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.8,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: Column(
          children: [
            30.h.verticalSpace,
            Align(
              alignment: Alignment.centerRight,
              child: GestureDetector(
                onTap: () {
                  getIt<NavigationService>().back();
                },
                child: Text(
                  S.current.close,
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
              ),
            ),
            Lottie.asset('assets/json/success.json',
                fit: BoxFit.scaleDown, height: 200.h, width: 200.w),
            20.h.verticalSpace,
            Text(
              widget.title,
              style: Theme.of(context).textTheme.headlineLarge!.copyWith(
                    fontSize: 32.sp,
                  ),
              textAlign: TextAlign.center,
            ),
            5.h.verticalSpace,
            if (widget.subTitle != null)
              Text(
                widget.subTitle!,
                style: Theme.of(context).textTheme.titleSmall,
                textAlign: TextAlign.center,
              ),
            47.5.h.verticalSpace,
            BuzzMapButton(
              text: S.current.kontinue,
              onPressed: () {
                widget.onPressed();
              },
              textColor: Colors.white,
            ),
            10.h.verticalSpace,
            Text(
              S.current.thanksForUsingOurApp,
              style: Theme.of(context).textTheme.titleMedium!.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
