'`r Sys.Date()`'

- TODO: Created the initial setup of the Bookmark feature/module
