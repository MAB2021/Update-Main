import 'package:dio/dio.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'bookmark_state.dart';

class BookmarkCubit extends Cubit<BookmarkState> {
  final BookmarkApiService apiService;

  BookmarkCubit({required this.apiService}) : super(BookmarkInitial());

  void addEventToBookmark(
      {required EventModel eventModel,
      required int index,
      required String widgetIdentifier}) async {
    emit(AddEventBookmarkLoading(
        id: eventModel.eventId,
        index: index,
        widgetIdentifier: widgetIdentifier));
    try {
      final response =
          await apiService.addEventToBookmark(eventModel: eventModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(AddEventBookmarkSuccess(
            message: response.data['message'],
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      } else {
        emit(AddEventBookmarkFailed(
            errorMessage: response.data['message'],
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      }
    } catch (e) {
      if (e is DioException) {
        emit(AddEventBookmarkFailed(
            errorMessage: networkErrorHandler(e),
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      } else {
        emit(AddEventBookmarkFailed(
            errorMessage: S.current.anErrorOccurred,
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      }
    }
  }

  void removeEventBookmark(
      {required num id,
      required int index,
      required EventModel eventModel,
      required String widgetIdentifier}) async {
    emit(RemoveEventBookmarkLoading(
        id: eventModel.eventId,
        index: index,
        widgetIdentifier: widgetIdentifier));
    try {
      final response = await apiService.removeEventFromBookmark(id: id);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(RemoveEventBookmarkSuccess(
            message: response.data['message'],
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      } else {
        emit(RemoveEventBookmarkFailed(
            errorMessage: response.data['message'],
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      }
    } catch (e) {
      if (e is DioException) {
        emit(RemoveEventBookmarkFailed(
            errorMessage: networkErrorHandler(e),
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      } else {
        emit(RemoveEventBookmarkFailed(
            errorMessage: S.current.anErrorOccurred,
            id: eventModel.eventId,
            index: index,
            widgetIdentifier: widgetIdentifier));
      }
    }
  }

  void getBookmarkedEvents({required String categoryName}) async {
    emit(GetBookmarkedEventsLoading());
    try {
      final response = await apiService.getBookmark(categoryName: categoryName);
      if (response.isSuccessful && response.data['status'] == 200) {
        List<EventModel> events = [];
        response.data['data'].forEach((event) {
          final EventModel eventModel = EventModel.fromJson(event["event"]);
          events.add(eventModel);
        });
        emit(GetBookmarkedEventsSuccess(events: events));
      } else {
        emit(GetBookmarkedEventsFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetBookmarkedEventsFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(
            GetBookmarkedEventsFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
