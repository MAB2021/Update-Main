part of 'bookmark_cubit.dart';

@immutable
abstract class BookmarkState {}

class BookmarkInitial extends BookmarkState {}

//Add event to bookmark

class AddEventBookmarkLoading extends BookmarkState {
  final String id;
  final int index;
  final String widgetIdentifier;

  AddEventBookmarkLoading({
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

class AddEventBookmarkSuccess extends BookmarkState {
  final String message;
  final String id;
  final int index;
  final String widgetIdentifier;

  AddEventBookmarkSuccess({
    required this.message,
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

class AddEventBookmarkFailed extends BookmarkState {
  final String errorMessage;
  final String id;
  final int index;
  final String widgetIdentifier;

  AddEventBookmarkFailed({
    required this.errorMessage,
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

//Remove event from bookmark

class RemoveEventBookmarkLoading extends BookmarkState {
  final String id;
  final int index;
  final String widgetIdentifier;
  
  RemoveEventBookmarkLoading({
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

class RemoveEventBookmarkSuccess extends BookmarkState {
  final String message;
  final String id;
  final int index;
  final String widgetIdentifier;

  RemoveEventBookmarkSuccess({
    required this.message,
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

class RemoveEventBookmarkFailed extends BookmarkState {
  final String errorMessage;
  final String id;
  final int index;
  final String widgetIdentifier;
  RemoveEventBookmarkFailed({
    required this.errorMessage,
    required this.id,
    required this.index,
    required this.widgetIdentifier,
  });
}

class GetBookmarkedEventsLoading extends BookmarkState {}

class GetBookmarkedEventsSuccess extends BookmarkState {
  final List<EventModel> events;

  GetBookmarkedEventsSuccess({required this.events});
}

class GetBookmarkedEventsFailed extends BookmarkState {
  final String errorMessage;

  GetBookmarkedEventsFailed({required this.errorMessage});
}
