import 'package:get_it/get_it.dart';
import './services/api_service.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'cubit/bookmark_cubit.dart';
import 'package:buzz_map/configs/app_configs.dart';


void setupBookmark(GetIt ioc){
  ioc.registerSingleton<BookmarkCubit>(BookmarkCubit(
    apiService: BookmarkApiService(
      http: HttpService(baseUrl: AppURL.baseUrl,hasAuthorization: true),
    ),
  ));
}