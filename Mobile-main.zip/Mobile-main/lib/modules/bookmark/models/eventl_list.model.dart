import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'dart:convert';

List<EventListEventModel> eventListEventModelFromJson(String str) => List<EventListEventModel>.from(json.decode(str).map((x) => EventListEventModel.fromJson(x)));

String eventListEventModelToJson(List<EventListEventModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class EventListEventModel {
    final int id;
    final User user;
    final EventModel event;

    EventListEventModel({
        required this.id,
        required this.user,
        required this.event,
    });

    factory EventListEventModel.fromJson(Map<String, dynamic> json) => EventListEventModel(
        id: json["id"],
        user: User.fromJson(json["user"]),
        event: EventModel.fromJson(json["event"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "user": user.toJson(),
        "event": event.toJson(),
    };
}
