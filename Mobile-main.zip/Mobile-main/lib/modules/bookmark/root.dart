import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/bookmark/cubit/bookmark_cubit.dart';
import 'package:buzz_map/modules/bookmark/widgets/bookmark_item.dart';
import 'package:buzz_map/modules/home/widgets/shimmer/trending_item_shimmer.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/empty_state.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BookmarkRootScreen extends StatefulWidget {
  const BookmarkRootScreen({super.key});

  @override
  State<BookmarkRootScreen> createState() => _BookmarkRootScreenState();
}

class _BookmarkRootScreenState extends State<BookmarkRootScreen>
    with TickerProviderStateMixin {
  late TabController tabController;
  List<CategoryModel> categories = [
    CategoryModel(
        id: 1, categoryName: "All", icon: "all", slug: "all", isActive: true),
  ];
  List<EventModel> bookmarkedEvents = [];
  bool isLoading = true;
  @override
  void initState() {
    super.initState();

    categories.addAll(
      getIt<List<CategoryModel>>(),
    );
    tabController = TabController(length: categories.length, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      getIt<BookmarkCubit>()
          .getBookmarkedEvents(categoryName: categories[0].categoryName);
    });
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leadingWidth: 200.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(text: S.current.bookmark),
        ),
      ),
      body: BlocConsumer(
        bloc: getIt<BookmarkCubit>(),
        listener: (context, state) {
          if (state is GetBookmarkedEventsLoading) {
            isLoading = true;
          } else if (state is GetBookmarkedEventsSuccess) {
            bookmarkedEvents = state.events;
            isLoading = false;
          } else if (state is GetBookmarkedEventsFailed) {
            isLoading = false;
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  TabBar(
                    controller: tabController,
                    isScrollable: true,
                    padding: EdgeInsets.only(top: 24.w, left: 10.w, right: 0.w),
                    enableFeedback: false,
                    splashBorderRadius: BorderRadius.zero,
                    onTap: (value) {
                      FocusScope.of(context).requestFocus(FocusNode());
                      getIt<BookmarkCubit>().getBookmarkedEvents(
                        categoryName: categories[value].categoryName,
                      );
                    },
                    tabs: categories
                        .map(
                          (e) => Tab(text: e.categoryName),
                        )
                        .toList(),
                  ),
                  isLoading
                      ? const TrendingItemShimmer()
                      : bookmarkedEvents.isEmpty
                          ? EmptyStateWidget(
                              imageUrl: AssetResources.emptyBookmark,
                              title: S.current.youHaveNoBookmarkedEvent)
                          : ListView.separated(
                              itemCount: bookmarkedEvents.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.only(top: 23.h),
                              separatorBuilder:
                                  (BuildContext context, int index) {
                                return 15.h.verticalSpace;
                              },
                              itemBuilder: (BuildContext context, int index) {
                                final EventModel eventModel =
                                    bookmarkedEvents[index];
                                return BookmarkItemWidget(
                                  eventModel: eventModel,
                                );
                              },
                            ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
