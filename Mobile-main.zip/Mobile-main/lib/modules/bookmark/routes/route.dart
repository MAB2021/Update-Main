class BookmarkRoutes{
    static const String bookmarkRoot = 'bookmark';
}