import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class BookmarkApiService {
  final HttpService http;

  BookmarkApiService({required this.http});

  Future<Response> addEventToBookmark({required EventModel eventModel}) async {
    return http.post(
      AppURL.addBookmark,
      data: eventModel.toJson(),
    );
  }

  Future<Response> removeEventFromBookmark({required dynamic id}) async {
    return http.put(
      "${AppURL.removeEventBookmark}$id/",
    );
  }

  Future<Response> getBookmark({required String categoryName}) async {
    return http.getRequest(AppURL.getEventBookmark,
        queryParameters: {"category": categoryName});
  }
}
