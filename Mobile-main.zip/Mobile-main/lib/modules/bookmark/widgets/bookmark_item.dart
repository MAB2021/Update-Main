import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/bookmark/widgets/remove_item.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/events/event_category_tag.dart';
import 'package:buzz_map/shared/widgets/events/event_date.dart';
import 'package:buzz_map/shared/widgets/events/event_location.dart';
import 'package:buzz_map/shared/widgets/events/network_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BookmarkItemWidget extends StatelessWidget {
  final EventModel eventModel;
  const BookmarkItemWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return InkWell(
      onTap: () {
        getIt<NavigationService>()
            .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          "eventModel": eventModel,
        });
      },
      child: Container(
        // height: 316.01.h,
        width: double.infinity,
        decoration: BoxDecoration(
            color:
                isDarkMode ? AppColors.primaryColor : AppColors.buzzMapWhite),
        child: Column(
          // alignment: Alignment.topCenter,
          children: [
            EventDateAndBackgroundWidget(
              eventModel: eventModel,
            ),
            EventWidget(
              eventModel: eventModel,
            ),
          ],
        ),
      ),
    );
  }
}

class EventDateAndBackgroundWidget extends StatelessWidget {
  final EventModel eventModel;
  const EventDateAndBackgroundWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topRight,
      children: [
        BuzzMapCacheImage(
            width: double.infinity,
            height: 203.h,
            boxFit: BoxFit.fitWidth,
            memCacheHeight: 800,
            memCacheWidth: 800,
            // borderRadius: 10.r,
            imgUrl: eventModel.eventImage),
        EventDateWidget(
          date: formatStringDate(eventModel.eventStartDate.toString()),
        ),
      ],
    );
  }
}

class EventWidget extends StatelessWidget {
  final EventModel eventModel;
  const EventWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 18.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          10.h.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 180.w,
                child: Text(
                  eventModel.eventName,
                  style: Theme.of(context).textTheme.displayMedium,
                  maxLines: 2,
                ),
              ),
              if (eventModel.heatMap != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: NetworkSignalIndicator(
                      signalStrength: eventModel.heatMap!),
                ),
            ],
          ),
          10.h.verticalSpace,
          EventCategoryTagWidget(
            name: eventModel.eventCategory,
          ),
          14.h.verticalSpace,
          EventLocation(
            eventModel: eventModel,
          ),
          10.h.verticalSpace,
        ],
      ),
    );
  }
}

class EventLocation extends StatelessWidget {
  final EventModel eventModel;
  final bool showBookmarkIcon;
  const EventLocation({
    super.key,
    required this.eventModel,
    this.showBookmarkIcon = true,
  });

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Row(
      children: [
        EventAddressWidget(
          address: eventModel.eventAddress,
        ),
        const Spacer(),
        Visibility(
          visible: showBookmarkIcon,
          child: GestureDetector(
            onTap: () {
              showModalBottomSheet(
                context: context,
                builder: (BuildContext context) {
                  return ReusableBottomSheet(
                    minHeight: 400.h,
                    initHeight: 400.h,
                    maxHeight: MediaQuery.of(context).size.height * 5.5,
                    content: RemoveEventWidget(
                      eventModel: eventModel,
                    ),
                  );
                },
              );
            },
            child: BuzzMapAssetImage(
              url: isDarkMode
                  ? AssetResources.whiteBookmark
                  : AssetResources.blackBookmark,
              height: 18.h,
              width: 18.w,
              fit: BoxFit.scaleDown,
            ),
          ),
        ),
        5.w.horizontalSpace,
      ],
    );
  }
}
