import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/bookmark/cubit/bookmark_cubit.dart';
import 'package:buzz_map/modules/bookmark/widgets/bookmark_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/events/event_category_tag.dart';
import 'package:buzz_map/shared/widgets/events/event_date.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class RemoveEventWidget extends StatefulWidget {
  final EventModel eventModel;
  const RemoveEventWidget({super.key, required this.eventModel});

  @override
  State<RemoveEventWidget> createState() => _RemoveEventWidgetState();
}

class _RemoveEventWidgetState extends State<RemoveEventWidget> {
  EventModel get eventModel => widget.eventModel;
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const BottomSheetGreyContainer(),
        41.h.verticalSpace,
        ClipRRect(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(8.r),
            topRight: Radius.circular(8.r),
          ),
          child: Stack(
            alignment: Alignment.topRight,
            children: [
              BuzzMapCacheImage(
                  width: double.infinity,
                  height: 77.h,
                  boxFit: BoxFit.fitWidth,
                  memCacheHeight: 800,
                  memCacheWidth: 800,
                  // borderRadius: 10.r,
                  imgUrl: eventModel.eventImage),
              EventDateWidget(
                date: formatStringDate(eventModel.eventStartDate.toString()),
              ),
            ],
          ),
        ),
        10.h.verticalSpace,
        Text(
          eventModel.eventName,
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        10.h.verticalSpace,
        EventCategoryTagWidget(name: eventModel.eventCategory),
        10.h.verticalSpace,
        EventLocation(
          eventModel: eventModel,
          showBookmarkIcon: false,
        ),
        40.h.verticalSpace,
        Center(
          child: Text(
            S.current.removeFromYourBookmark,
            style: GoogleFonts.outfit(
              color:
                  !isDarkMode ? AppColors.primaryColor : AppColors.buzzMapWhite,
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        23.h.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            BuzzMapButton(
              borderRadius: 10.r,
              height: 60.h,
              width: 153.w,
              color: Colors.transparent,
              borderColor: Theme.of(context).primaryColorDark,
              child: Text(
                S.current.cancel,
                style: GoogleFonts.outfit(
                  color: isDarkMode
                      ? AppColors.buzzMapWhite
                      : Colors.black.withOpacity(0.5),
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              onPressed: () {
                getIt<NavigationService>().back();
              },
            ),
            BlocConsumer(
              bloc: getIt<BookmarkCubit>(),
              listener: (context, state) {
                if (state is RemoveEventBookmarkSuccess) {
                  DialogUtil.dismissLoadingDialog(context);
                  getIt<NavigationService>().back();
                  getIt<NavigationService>().back();
                  NotificationMessage.showMessage(context,
                      message: state.message, isError: false);
                } else if (state is RemoveEventBookmarkFailed) {
                  DialogUtil.dismissLoadingDialog(context);
                  NotificationMessage.showMessage(
                    context,
                    message: state.errorMessage,
                    isError: true,
                  );
                } else if (state is RemoveEventBookmarkLoading) {
                  DialogUtil.showLoadingDialog(context);
                }
              },
              builder: (context, state) {
                return BuzzMapButton(
                  borderRadius: 10.r,
                  height: 60.h,
                  width: 153.w,
                  color: Theme.of(context).primaryColorDark,
                  child: Text(
                    S.current.yesRemove,
                    style: GoogleFonts.outfit(
                      color: AppColors.buzzMapWhite,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  onPressed: () {
                    getIt<BookmarkCubit>().removeEventBookmark(
                        id: eventModel.id,
                        index: 1,
                        eventModel: eventModel,
                        widgetIdentifier: "Bookmark");
                  },
                );
              },
            ),
          ],
        ),
        23.h.verticalSpace,
      ],
    );
  }
}
