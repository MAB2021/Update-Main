import 'package:buzz_map/modules/calendar/utils.dart';
import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'calendar_state.dart';

class CalendarCubit extends Cubit<CalendarState> {
  final CalendarApiService apiService;

  CalendarCubit({required this.apiService}) : super(CalendarInitial());
  final CalendarUtil _calendarUtil = CalendarUtil();

  //Get events from calendar

  Future<void> getEvents(
    DateTime startDate,
    DateTime endDate,
  ) async {
    emit(CalendarLoadingState());
    try {
      List<Event> listOfEvents =
          await _calendarUtil.getEvents(startDate, endDate);
      emit(GetEventsState(events: listOfEvents));
    } catch (e) {
      emit(
        CalendarErrorState(
          errorMessage: e.toString(),
        ),
      );
    }
  }

  //Remove event from calendar and return updated event list for the selected date

  Future<void> removeEvent(String eventId) async {
    emit(CalendarLoadingState());
    try {
      await _calendarUtil.removeEvent(eventId);
      emit(RemoveEventState(isRemoved: true));
    } catch (e) {
      emit(
        CalendarErrorState(
          errorMessage: e.toString(),
        ),
      );
    }
  }

  //Get events for selected date
  getEventsForSelectedDate(DateTime selectedDate) async {
    emit(CalendarLoadingState());
    try {
      List<Event> listOfEvents =
          await _calendarUtil.getEventsForSelectedDate(selectedDate);
      emit(GetEventsForSelectedDateState(events: listOfEvents));
    } catch (e) {
      emit(
        CalendarErrorState(
          errorMessage: e.toString(),
        ),
      );
    }
  }

  //Add event

  Future<void> addEvent(Event event, String? calendarId) async {
    emit(AddingEvent());
    try {
      final eventId = await _calendarUtil.addEvent(event, calendarId);
      if (eventId != null) {
        emit(AddEventState(eventId: eventId));
      } else {
        emit(AddEventFailed(errorMessage: 'Failed to add event'));
      }
    } catch (e) {
      emit(
        AddEventFailed(
          errorMessage: e.toString(),
        ),
      );
    }
  }
}
