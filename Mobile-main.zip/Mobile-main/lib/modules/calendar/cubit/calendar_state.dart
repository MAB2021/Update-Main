part of 'calendar_cubit.dart';

@immutable
abstract class CalendarState {}

class CalendarInitial extends CalendarState {}

//Getting events
class CalendarLoadingState extends CalendarState {}

//Get event state
class GetEventsState extends CalendarState {
  final List<Event> events;

  GetEventsState({required this.events});
}

//Error state
class CalendarErrorState extends CalendarState {
  final String errorMessage;

  CalendarErrorState({required this.errorMessage});
}

//Remove event state

class RemovingEventsState extends CalendarState {}

class RemoveEventState extends CalendarState {
  final bool isRemoved;

  RemoveEventState({required this.isRemoved});
}

class RemovingEventsFailedState extends CalendarState {
  final String errorMessage;

  RemovingEventsFailedState({required this.errorMessage});
}

//Get events for selected date
class GetEventsForSelectedDateState extends CalendarState {
  final List<Event> events;

  GetEventsForSelectedDateState({required this.events});
}

//Add event

class AddingEvent extends CalendarState {}

class AddEventState extends CalendarState {
  final String eventId;

  AddEventState({required this.eventId});
}

class AddEventFailed extends CalendarState {
  final String errorMessage;

  AddEventFailed({required this.errorMessage});
}
