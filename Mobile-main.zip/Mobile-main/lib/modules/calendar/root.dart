import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/calendar/cubit/calendar_cubit.dart';
import 'package:buzz_map/modules/calendar/widgets/calendar_event_item.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:table_calendar/table_calendar.dart';

class CalendarRootWidget extends StatefulWidget {
  final bool isCurrent;

  const CalendarRootWidget({super.key, required this.isCurrent});

  @override
  State<CalendarRootWidget> createState() => _CalendarRootWidgetState();
}

class _CalendarRootWidgetState extends State<CalendarRootWidget> {
  List<Event> listOfEvents = [];
  List<Event> selectedListOfEvents = [];
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  void initState() {
    getEvents();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Offstage(
      offstage: !widget.isCurrent,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          centerTitle: false,
          leading: const SizedBox.shrink(),
          leadingWidth: 10,
          title: Text(
            S.current.myCalendarEvent,
            style: Theme.of(context).textTheme.titleLarge!.copyWith(
                  fontSize: 18.sp,
                ),
          ),
        ),
        body: BlocConsumer(
          bloc: getIt<CalendarCubit>(),
          listener: (context, state) {
            if (state is GetEventsState) {
              listOfEvents = List.from(state.events); // Make a modifiable copy
              selectedListOfEvents = listOfEvents
                  .where((element) => isSameDay(element.start, DateTime.now()))
                  .toList();
            } else if (state is CalendarErrorState) {
              NotificationMessage.showMessage(context,
                  message: state.errorMessage, isError: true);
            } else if (state is RemoveEventState) {
              // if (state.isRemoved) {
              //   getEvents();
              //   getIt<CalendarCubit>().getEventsForSelectedDate(_selectedDay!);
              // }
            } else if (state is GetEventsForSelectedDateState) {
              // selectedListOfEvents =
              //     List.from(state.events); // Make a modifiable copy
            }
          },
          builder: (context, state) {
            return SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: isDarkMode
                          ? AppColors.primaryColor
                          : AppColors.buzzMapGrayLight[90],
                      borderRadius: BorderRadius.circular(16.r),
                    ),
                    child: TableCalendar(
                      firstDay: DateTime.now(),
                      lastDay: DateTime.now().add(
                        const Duration(days: 30 * 13),
                      ),
                      focusedDay: _focusedDay,
                      selectedDayPredicate: (day) {
                        return isSameDay(_selectedDay, day);
                      },
                      eventLoader: (day) {
                        return listOfEvents
                            .where((element) => isSameDay(element.start, day))
                            .toList();
                      },
                      onDaySelected: (selectedDay, focusedDay) {
                        setState(() {
                          _selectedDay = selectedDay;
                          _focusedDay = focusedDay;
                          _updateSelectedListOfEvents();
                        });
                      },
                      rowHeight: 64.h,
                      daysOfWeekHeight: 35.h,
                      sixWeekMonthsEnforced: false,
                      availableCalendarFormats: const {
                        CalendarFormat.month: "Month",
                      },
                      headerStyle: HeaderStyle(
                        titleTextStyle:
                            Theme.of(context).textTheme.titleLarge!.copyWith(
                                  fontSize: 20.sp,
                                ),
                        formatButtonVisible: false,
                        titleCentered: false,
                        leftChevronIcon: Icon(
                          Icons.chevron_left,
                          color: isDarkMode
                              ? AppColors.buzzMapWhite
                              : AppColors.primaryColor,
                        ),
                        rightChevronIcon: Icon(
                          Icons.chevron_right,
                          color: isDarkMode
                              ? AppColors.buzzMapWhite
                              : AppColors.primaryColor,
                        ),
                      ),
                      daysOfWeekStyle: DaysOfWeekStyle(
                        weekdayStyle:
                            Theme.of(context).textTheme.titleSmall!.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                        weekendStyle:
                            Theme.of(context).textTheme.titleSmall!.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      calendarStyle: CalendarStyle(
                        outsideDaysVisible: false,
                        cellMargin: EdgeInsets.zero,
                        defaultDecoration: const BoxDecoration(
                          color: Colors.transparent,
                          shape: BoxShape.rectangle,
                        ),
                        weekendDecoration: const BoxDecoration(
                          color: Colors.transparent,
                          shape: BoxShape.rectangle,
                        ),
                        tableBorder: TableBorder.symmetric(
                          inside: BorderSide(
                            color: AppColors.dividerColor,
                            width: 1,
                          ),
                          outside: BorderSide.none,
                        ),
                        markerDecoration: BoxDecoration(
                          color: AppColors.red,
                          shape: BoxShape.circle,
                        ),
                        markersMaxCount: 1,
                        selectedDecoration: BoxDecoration(
                          color: AppColors.darkPurple,
                          shape: BoxShape.rectangle,
                        ),
                        todayDecoration: BoxDecoration(
                          color: AppColors.darkPurple,
                          shape: BoxShape.rectangle,
                        ),
                        disabledTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                        outsideTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                        selectedTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                        withinRangeTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                        todayTextStyle: Theme.of(context).textTheme.titleSmall!,
                        defaultTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                        weekendTextStyle:
                            Theme.of(context).textTheme.titleSmall!,
                      ),
                    ),
                  ),
                  27.h.verticalSpace,
                  Text("${S.current.events} ${selectedListOfEvents.length}",
                      style: Theme.of(context).textTheme.bodyLarge),
                  13.h.verticalSpace,
                  ListView.builder(
                    itemCount: selectedListOfEvents.length,
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Dismissible(
                        key: Key(selectedListOfEvents[index].eventId!),
                        onDismissed: (direction) {
                          final eventId = selectedListOfEvents[index].eventId!;
                          getIt<CalendarCubit>().removeEvent(eventId);
                          setState(() {
                            _removeEventFromList(eventId);
                          });
                        },
                        background: Container(
                          color: Colors.red,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: const Icon(Icons.delete, color: Colors.white),
                        ),
                        child: CalendarEventItem(
                          event: selectedListOfEvents[index],
                        ),
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  DateTime convertTZDateTimeToDateTime(TZDateTime tzDateTime) {
    return DateTime(
      tzDateTime.year,
      tzDateTime.month,
      tzDateTime.day,
      tzDateTime.hour,
      tzDateTime.minute,
      tzDateTime.second,
    );
  }

  void getEvents() {
    getIt<CalendarCubit>().getEvents(
        DateTime.now(), DateTime.now().add(const Duration(days: 30 * 13)));
  }

  void _updateSelectedListOfEvents() {
    setState(() {
      selectedListOfEvents = List.from(listOfEvents
          .where((element) => isSameDay(
              convertTZDateTimeToDateTime(element.start!), _selectedDay))
          .toList()); // Make a modifiable copy
    });
  }

  void _removeEventFromList(String eventId) {
    setState(() {
      listOfEvents =
          listOfEvents.where((event) => event.eventId != eventId).toList();
      selectedListOfEvents = selectedListOfEvents
          .where((event) => event.eventId != eventId)
          .toList();
    });
    _updateSelectedListOfEvents();
  }
}
