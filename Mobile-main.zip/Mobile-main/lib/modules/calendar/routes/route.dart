class CalendarRoutes{
    static const String calendarRoot = '/calendar';
}