import 'package:buzz_map/shared/network/network_request.dart';

class CalendarApiService{
  final HttpService http;

  CalendarApiService({required this.http});


}