import 'package:buzz_map/configs/app_configs.dart';
import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/material.dart';

class CalendarUtil {
  final DeviceCalendarPlugin _deviceCalendarPlugin = DeviceCalendarPlugin();

  Future<void> requestCalendarPermissions() async {
    try {
      // Request permission to modify calendars
      final permissionStatus = await _deviceCalendarPlugin.requestPermissions();

      if (permissionStatus.isSuccess && permissionStatus.data != null) {
        // Permission granted, you can now modify calendars
        // Add your code to modify calendars here
      } else {
        // Permission denied, handle accordingly (e.g., show a message to the user)
      }
    } catch (e) {
      // Handle any errors that occur during permission request
      throw ('Error requesting calendar permissions: $e');
    }
  }

  Future<String?> getCalendarId() async {
    try {
      final calendarsResult = await _deviceCalendarPlugin.retrieveCalendars();

      if (calendarsResult.isSuccess && calendarsResult.data != null) {
        for (final calendar in calendarsResult.data!) {
          if (calendar.name == AppConstants.calendarName) {
            return calendar.id;
          }
        }
      }
    } catch (e) {
      throw ('Error retrieving calendar ID: $e');
    }
    return null;
  }

  Future<String?> createCalendar() async {
    try {
      final result =
          await _deviceCalendarPlugin.createCalendar(AppConstants.calendarName);
      if (result.isSuccess && result.data != null) {
        return result.data;
      } else {
        debugPrint('Error creating calendar: ${result.errors.join(', ')}');
        return null;
      }
    } catch (e) {
      debugPrint('Error creating calendar: $e');
      return null;
    }
  }

  Future<String?> getOrCreateCalendar() async {
    await requestCalendarPermissions();

    final String? calendarId = await getCalendarId();
    if (calendarId != null) {
      return calendarId;
    } else {
      return await createCalendar();
    }
  }

  Future<List<Event>> getEvents(DateTime startDate, DateTime endDate) async {
    try {
      final calendarId = await getCalendarId();
      if (calendarId != null) {
        final eventsResult = await _deviceCalendarPlugin.retrieveEvents(
          calendarId,
          RetrieveEventsParams(startDate: startDate, endDate: endDate),
        );
        if (eventsResult.isSuccess && eventsResult.data != null) {
          return eventsResult.data!;
        }
      }
    } catch (e) {
      debugPrint('Error retrieving events: $e');
    }
    return []; // Return an empty list if there's an error or no events are found
  }

  //Remove event
  Future<void> removeEvent(String eventId) async {
    try {
      final calendarId = await getCalendarId();
      if (calendarId != null) {
        final deleteResult = await _deviceCalendarPlugin.deleteEvent(
          calendarId,
          eventId,
        );
        if (deleteResult.isSuccess) {
          debugPrint('Event deleted successfully');
        } else {
          debugPrint('Error deleting event: ${deleteResult.errors.join(', ')}');
        }
      }
    } catch (e) {
      debugPrint('Error deleting event: $e');
    }
  }

  //Get events from calendar on selected date
  Future<List<Event>> getEventsForSelectedDate(DateTime selectedDate) async {
    try {
      final calendarId = await getCalendarId();
      if (calendarId != null) {
        final eventsResult = await _deviceCalendarPlugin.retrieveEvents(
          calendarId,
          RetrieveEventsParams(startDate: selectedDate, endDate: selectedDate),
        );
        if (eventsResult.isSuccess && eventsResult.data != null) {
          return eventsResult.data!;
        }
      }
    } catch (e) {
      debugPrint('Error retrieving events: $e');
    }
    return []; // Return an empty list if there's an error or no events are found
  }

// Add event to calendar
  // Add event to calendar and return event ID if successful
  Future<String?> addEvent(Event event, String? calendarId) async {
    try {
      if (calendarId != null) {
        // Query existing events
        final existingEventsResult = await _deviceCalendarPlugin.retrieveEvents(
          calendarId,
          RetrieveEventsParams(
            startDate: DateTime(
                event.start!.year, event.start!.month, event.start!.day),
            endDate: DateTime(event.end!.year, event.end!.month, event.end!.day)
                .add(const Duration(days: 1)),
          ),
        );

        if (existingEventsResult.isSuccess &&
            existingEventsResult.data != null) {
          final existingEvents = existingEventsResult.data!;

          // Check for duplicate events
          if (isDuplicateEvent(event, existingEvents)) {
            debugPrint('Duplicate event detected, not adding.');
            return null;
          }
        }

        // Add the event if no duplicates are found
        final createResult =
            await _deviceCalendarPlugin.createOrUpdateEvent(event);
        if (createResult!.isSuccess) {
          debugPrint('Event added successfully');
          return createResult.data;
        } else {
          debugPrint('Error adding event: ${createResult.errors.join(', ')}');
          return null;
        }
      } else {
        debugPrint('Calendar ID is null');
        return null;
      }
    } catch (e) {
      debugPrint('Error adding event: $e');
      return null;
    }
  }

  // Function to find a specific event by title and date
  Future<Event?> findEventByTitleAndDate(
      String calendarId, String eventTitle, DateTime eventDate) async {
    // Adjust the date range as needed
    final events = await getEvents(
      eventDate.subtract(const Duration(days: 1)),
      eventDate.add(const Duration(days: 1)),
    );

    for (var event in events) {
      if (event.title == eventTitle &&
          event.start!.year == eventDate.year &&
          event.start!.month == eventDate.month &&
          event.start!.day == eventDate.day) {
        return event;
      }
    }

    return null;
  }

  bool isDuplicateEvent(Event newEvent, List<Event> existingEvents) {
    return existingEvents.any((event) =>
        event.title == newEvent.title &&
        event.start == newEvent.start &&
        event.end == newEvent.end);
  }
}
