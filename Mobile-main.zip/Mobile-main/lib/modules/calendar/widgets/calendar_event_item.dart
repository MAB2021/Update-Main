import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:device_calendar/device_calendar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

class CalendarEventItem extends StatelessWidget {
  final Event event;
  const CalendarEventItem({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return GestureDetector(
      onTap: () {
        getIt<NavigationService>().toWithParameters(
            routeName: HomeRoutes.eventDetail,
            args: {"eventId": event.description});
      },
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.only(bottom: 20.h),
        padding: EdgeInsets.all(20.w),
        decoration: BoxDecoration(
          border: Border.all(
            color: isDarkMode
                ? Colors.white.withOpacity(0.10)
                : AppColors.buzzMapGrayLight[90]!,
            width: 1.w,
          ),
          color: isDarkMode
              ? AppColors.primaryColor
              : AppColors.buzzMapGrayLight[90],
          borderRadius: BorderRadius.circular(16.r),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              event.title!,
              style: Theme.of(context).textTheme.displayMedium!.copyWith(
                    fontSize: 18.sp,
                  ),
            ),
            10.h.verticalSpace,
            Text(
              event.location!,
              style: Theme.of(context).textTheme.titleSmall,
              maxLines: 2,
            ),
            10.h.verticalSpace,
            Text(
              DateFormat('h:mm a').format(event.start!.toLocal()),
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ],
        ),
      ),
    );
  }
}
