import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EventToCalendarWidget extends StatelessWidget {
  final String message;
  const EventToCalendarWidget({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return ReusableBottomSheet(
      minHeight: 88.41.h,
      initHeight: 88.41.h,
      maxHeight: 400,
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const BottomSheetGreyContainer(),
          26.39.h.verticalSpace,
          Text(
            message,
            style: Theme.of(context).textTheme.titleMedium!.copyWith(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
