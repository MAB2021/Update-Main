'`r Sys.Date()`'

- TODO: Created the initial setup of the Events feature/module
