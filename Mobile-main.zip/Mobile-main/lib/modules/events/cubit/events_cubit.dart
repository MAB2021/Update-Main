import 'package:buzz_map/modules/events/models/add_event.dart';
import 'package:buzz_map/modules/events/models/rate_event.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'events_state.dart';

class EventsCubit extends Cubit<EventsState> {
  final EventsApiService apiService;

  EventsCubit({required this.apiService}) : super(EventsInitial());
  void getCategories() async {
    emit(GetCategoriesLoading());
    try {
      final response = await apiService.getCategories();
      if (response.isSuccessful && response.data['status'] == 200) {
        List<CategoryModel> categories = [];
        response.data['data']['categories'].forEach((category) {
          categories.add(CategoryModel.fromJson(category));
        });
        getIt.registerSingleton<List<CategoryModel>>(categories);
        emit(GetCategoriesSuccess(categories: categories));
      } else {
        emit(GetCategoriesFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetCategoriesFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetCategoriesFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void getEvents({required int pageNumber}) async {
    emit(GetEventsLoading());
    try {
      final response = await apiService.getEvents(pageNumber: pageNumber);
      if (response.isSuccessful && response.data['status'] == 200) {
        List<EventModel> events = [];
        response.data['data'].forEach((event) {
          events.add(EventModel.fromJson(event));
        });
        emit(GetEventsSuccess(events: events));
      } else {
        emit(GetEventsFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetEventsFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetEventsFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Rate event
  void rateEvent({required RateEvent rateEvent}) async {
    emit(RateEventLoading());
    try {
      final response = await apiService.rateEvent(rateEvent: rateEvent);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(RateEventSuccess());
      } else {
        emit(RateEventFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(RateEventFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(RateEventFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Get event by Id
  void getEventById({required String eventId}) async {
    emit(GetEventByIdLoading());
    try {
      final response = await apiService.getEventById(eventId: eventId);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(GetEventByIdSuccess(
            event: EventModel.fromJson(response.data['data'])));
      } else {
        emit(GetEventByIdFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetEventByIdFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetEventByIdFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Add event
  void addEvent({required AddEvent event}) async {
    emit(AddEventLoading());
    try {
      final response = await apiService.addEvent(event: event);

      if (response.isSuccessful && response.data['success'] == true) {
        emit(AddEventSuccess(message: response.data['message']));
      } else {
        emit(AddEventFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(AddEventFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(AddEventFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Update event
  void updateEvent({required AddEvent event}) async {
    emit(UpdateEventLoading());
    try {
      final response = await apiService.updateEvent(event: event);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(UpdateEventSuccess());
      } else {
        emit(UpdateEventFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdateEventFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdateEventFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Delete event
  void deleteEvent({required String eventId}) async {
    emit(DeleteEventLoading());
    try {
      final response = await apiService.deleteEvent(eventId: eventId);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(DeleteEventSuccess());
      } else {
        emit(DeleteEventFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(DeleteEventFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(DeleteEventFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Get timezone
  void getTimezone(
      {required double latitude, required double longitude}) async {
    emit(GettingEventTimezone());
    try {
      final response = await apiService.getTimeZone(
          latitude: latitude, longitude: longitude);
      if (response.isSuccessful && response.data['status'] == "OK") {
        emit(GettingEventTimezoneSuccess(timezone: response.data['zoneName']));
      } else {
        emit(
            GettingEventTimezoneFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GettingEventTimezoneFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GettingEventTimezoneFailed(
            errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
