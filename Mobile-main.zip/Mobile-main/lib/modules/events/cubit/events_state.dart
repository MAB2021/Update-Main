part of 'events_cubit.dart';

@immutable
abstract class EventsState {}

class EventsInitial extends EventsState {}

class GetCategoriesLoading extends EventsState {}

class GetCategoriesSuccess extends EventsState {
  final List<CategoryModel> categories;

  GetCategoriesSuccess({required this.categories});
}

class GetCategoriesFailed extends EventsState {
  final String errorMessage;

  GetCategoriesFailed({required this.errorMessage});
}

//Get events

class GetEventsLoading extends EventsState {}

class GetEventsSuccess extends EventsState {
  final List<EventModel> events;

  GetEventsSuccess({required this.events});
}

class GetEventsFailed extends EventsState {
  final String errorMessage;

  GetEventsFailed({required this.errorMessage});
}

//Rate events

class RateEventLoading extends EventsState {}

class RateEventSuccess extends EventsState {}

class RateEventFailed extends EventsState {
  final String errorMessage;

  RateEventFailed({required this.errorMessage});
}

//Get event by id

class GetEventByIdLoading extends EventsState {}

class GetEventByIdSuccess extends EventsState {
  final EventModel event;

  GetEventByIdSuccess({required this.event});
}

class GetEventByIdFailed extends EventsState {
  final String errorMessage;

  GetEventByIdFailed({required this.errorMessage});
}

//Add event

class AddEventLoading extends EventsState {}

class AddEventSuccess extends EventsState {
  final String message;

  AddEventSuccess({required this.message});
}

class AddEventFailed extends EventsState {
  final String errorMessage;

  AddEventFailed({required this.errorMessage});
}

//Update event

class UpdateEventLoading extends EventsState {}

class UpdateEventSuccess extends EventsState {}

class UpdateEventFailed extends EventsState {
  final String errorMessage;

  UpdateEventFailed({required this.errorMessage});
}

//Get custom nodescale events

class GettingCustomEvent extends EventsState {}

class GetCustomEventSuccess extends EventsState {
  final List<EventModel> events;

  GetCustomEventSuccess({required this.events});
}

class GetCustomEventFailed extends EventsState {
  final String errorMessage;

  GetCustomEventFailed({required this.errorMessage});
}

//Delete event
class DeleteEventLoading extends EventsState {}

class DeleteEventSuccess extends EventsState {}

class DeleteEventFailed extends EventsState {
  final String errorMessage;

  DeleteEventFailed({required this.errorMessage});
}

//Get timezone

class GettingEventTimezone extends EventsState {}

class GettingEventTimezoneSuccess extends EventsState {
  final String timezone;

  GettingEventTimezoneSuccess({required this.timezone});
}

class GettingEventTimezoneFailed extends EventsState {
  final String errorMessage;

  GettingEventTimezoneFailed({required this.errorMessage});
}
