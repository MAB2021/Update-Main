import 'package:get_it/get_it.dart';
import './services/api_service.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'cubit/events_cubit.dart';
import 'package:buzz_map/configs/app_configs.dart';

void setupEvents(GetIt ioc) {
  ioc.registerSingleton<EventsCubit>(EventsCubit(
    apiService: EventsApiService(
      http: HttpService(baseUrl: AppURL.baseUrl, hasAuthorization: true),
    ),
  ));
  ioc.registerSingleton<EventsCubit>(
      EventsCubit(
        apiService: EventsApiService(
          http: HttpService(
            baseUrl: AppURL.nodescaleBaseUrl,
            hasAuthorization: true,
          ),
        ),
      ),
      instanceName: "nodescale");
}
