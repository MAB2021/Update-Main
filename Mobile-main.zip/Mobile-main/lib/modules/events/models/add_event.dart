import 'dart:convert';
import 'package:uuid/uuid.dart';

AddEvent addEventFromJson(String str) => AddEvent.fromJson(json.decode(str));

String addEventToJson(AddEvent data) => json.encode(data.toJson());

class AddEvent {
  final String eventName;
  final String eventDescription;
  final String eventStartDate;
  final String country;
  final String eventAddress;
  final String eventImage;
  final String timeZone;
  final String eventInfo;
  final String eventCity;
  final String eventCategory;
  // final int ratings;
  final String realCategory;
  // final int attending;
  final bool isActive;
  final String createdBy;

  AddEvent(
      {required this.eventName,
      required this.eventDescription,
      required this.eventStartDate,
      required this.country,
      required this.eventAddress,
      required this.eventImage,
      required this.timeZone,
      required this.eventInfo,
      required this.eventCity,
      required this.eventCategory,
      // required this.ratings,
      required this.realCategory,
      // required this.attending,
      required this.isActive,
      required this.createdBy});

  factory AddEvent.fromJson(Map<String, dynamic> json) => AddEvent(
        eventName: json["event_name"],

        eventDescription: json["event_description"],
        eventStartDate: json["event_start_date"],
        country: json["country"],
        eventAddress: json["event_address"],
        eventImage: json["event_image"],
        timeZone: json["time_zone"],
        eventInfo: json["event_info"],
        eventCity: json["event_city"],
        eventCategory: json["event_category"],
        // ratings: json["ratings"],
        realCategory: json["real_category"],
        // attending: json["attending"],
        isActive: json["is_active"],
        createdBy: json["created_by"],
      );

  Map<String, dynamic> toJson() => {
        "event_name": eventName,
        "event_id": const Uuid().v4(),
        "event_description": eventDescription,
        "event_start_date": eventStartDate,
        "country": country,
        "event_address": eventAddress,
        "event_image": eventImage,
        "time_zone": timeZone,
        "event_info": eventInfo,
        "event_city": eventCity,
        "event_category": eventCategory,
        "ratings": 0,
        "real_category": realCategory,
        "attending": 0,
        "is_active": isActive,
        "host": "nodescale",
        "created_by": createdBy,
      };
}
