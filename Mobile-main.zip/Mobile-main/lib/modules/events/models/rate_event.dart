import 'dart:convert';

RateEvent rateEventFromJson(String str) => RateEvent.fromJson(json.decode(str));

String rateEventToJson(RateEvent data) => json.encode(data.toJson());

class RateEvent {
  final String eventId;
  final num score;
  final String description;

  RateEvent({
    required this.eventId,
    required this.score,
    required this.description,
  });

  factory RateEvent.fromJson(Map<String, dynamic> json) => RateEvent(
        eventId: json["event_id"],
        score: json["score"],
        description: json["description"],
      );

  Map<String, dynamic> toJson() => {
        "event_id": eventId,
        "score": score,
        "description": description,
      };
}
