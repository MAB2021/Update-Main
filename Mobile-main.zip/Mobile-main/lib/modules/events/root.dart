import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/routes/route.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/modules/home/widgets/search/search_input_text.dart';
import 'package:buzz_map/modules/home/widgets/shimmer/trending_item_shimmer.dart';
import 'package:buzz_map/modules/home/widgets/trending/all_trending/all_trending_item.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/empty_state.dart';
import 'package:buzz_map/shared/widgets/lottie_loader.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EventsRootWidget extends StatefulWidget {
  final bool isCurrent;

  const EventsRootWidget({super.key, required this.isCurrent});

  @override
  State<EventsRootWidget> createState() => _EventsRootWidgetState();
}

class _EventsRootWidgetState extends State<EventsRootWidget> {
  final ScrollController _scrollController = ScrollController();
  List<CategoryModel> categories = [];
  List<EventModel> events = [];
  bool isLoading = true;
  bool isLoadingMore = false;
  int pageNumber = 1;
  @override
  void initState() {
    _scrollController.addListener(_scrollListener);
    getEvents();
    super.initState();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      // User has scrolled to the end of the list
      loadMoreEvents();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Offstage(
      offstage: !widget.isCurrent,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          centerTitle: false,
          leading: const SizedBox.shrink(),
          leadingWidth: 10,
          title: Text(
            S.current.eventList,
            style: Theme.of(context).textTheme.titleLarge!.copyWith(
                  fontSize: 18.sp,
                ),
          ),
        ),
        body: BlocConsumer(
          bloc: getIt<EventsCubit>(),
          listener: (context, state) {
            if (state is GetEventsLoading) {
              isLoading = true;
            } else if (state is GetEventsSuccess) {
              events.addAll(state.events);
              isLoading = false;
              setState(() {
                pageNumber++;
                isLoadingMore = false;
              });
            } else if (state is GetEventsFailed) {
              isLoading = false;
              isLoadingMore = false;
              NotificationMessage.showMessage(
                context,
                message: state.errorMessage,
                isError: true,
              );
            }
          },
          builder: (context, state) {
            return SafeArea(
              top: true,
              child: RefreshIndicator(
                onRefresh: () async {
                  events.clear();
                  pageNumber = 1;
                  getEvents();
                },
                child: SingleChildScrollView(
                  controller: _scrollController,
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: () => getIt<NavigationService>()
                            .to(routeName: HomeRoutes.search),
                        child: const SearchInputText(),
                      ),
                      isLoading && !isLoadingMore
                          ? const TrendingItemShimmer()
                          : events.isEmpty
                              ? EmptyStateWidget(
                                  imageUrl: AssetResources.noEvents,
                                  title: S.current.youHaveNoEvents)
                              : ListView.separated(
                                  itemCount: events.length,
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  padding: EdgeInsets.only(top: 23.h),
                                  separatorBuilder:
                                      (BuildContext context, int index) {
                                    return 15.h.verticalSpace;
                                  },
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    final EventModel eventModel = events[index];
                                    return AllTrendingItem(
                                      model: eventModel,
                                      index: index,
                                    );
                                  },
                                ),
                      isLoadingMore
                          ? const LottieLoader()
                          : const SizedBox.shrink(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        floatingActionButton: FloatingActionButton(
          shape: const CircleBorder(),
          onPressed: () {
            getIt<NavigationService>()
                .to(routeName: EventsRoutes.createEventsRoot);
          },
          backgroundColor: AppColors.secondaryColor,
          child: const BuzzMapAssetImage(
            url: AssetResources.addEvent,
          ),
        ),
      ),
    );
  }

  loadMoreEvents() {
    getIt<EventsCubit>().getEvents(
      pageNumber: pageNumber,
    );
    setState(() {
      isLoadingMore = true;
    });
  }

  getEvents() {
    if (userCurrentPosition.value != null) {
      getIt<EventsCubit>().getEvents(pageNumber: pageNumber);
    }
  }
}
