class EventsRoutes {
  static const String eventsRoot = '/events';
  static const String createEventsRoot = 'createEventsRoot';
  static const String eventAddressSearchScreen = 'eventAddressSearchScreen';
}
