import 'package:buzz_map/modules/events/models/add_event.dart';
import 'package:buzz_map/modules/events/models/rate_event.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class EventsApiService {
  final HttpService http;

  EventsApiService({required this.http});

  Future<Response> getCategories() async {
    return http.getRequest(AppURL.categories);
  }

  Future<Response> getEvents({required int pageNumber}) async {
    return http.getRequest(AppURL.upcomingEvent, queryParameters: {
      "latitude": userCurrentPosition.value!.latitude,
      "longitude": userCurrentPosition.value!.longitude,
      "is_guest": 0,
      "page": pageNumber
    });
  }

  //Rate event
  Future<Response> rateEvent({required RateEvent rateEvent}) async {
    return http.post(AppURL.rate, data: rateEvent);
  }

  //Get event by id
  Future<Response> getEventById({required String eventId}) async {
    return http
        .getRequest(AppURL.getEvent, queryParameters: {"event_id": eventId});
  }

  //Add event
  Future<Response> addEvent({required AddEvent event}) async {
    return HttpService(baseUrl: AppURL.nodescaleBaseUrl, hasAuthorization: true)
        .post(AppURL.addEvent, data: event.toJson());
  }

  //Update event
  Future<Response> updateEvent({required AddEvent event}) async {
    return HttpService(baseUrl: AppURL.nodescaleBaseUrl, hasAuthorization: true)
        .put(AppURL.updateEvent, data: event);
  }

  //Delete event
  Future<Response> deleteEvent({required String eventId}) async {
    return HttpService(baseUrl: AppURL.nodescaleBaseUrl, hasAuthorization: true)
        .delete(AppURL.updateEvent, queryParameters: {"event_id": eventId});
  }

  //Get timezone
  Future<Response> getTimeZone(
      {required double latitude, required double longitude}) async {
    return HttpService(
            baseUrl: AppURL.timezoneURL(
                AppConfig.timezoneApiKey, longitude, latitude),
            hasAuthorization: false)
        .getRequest("");
  }
}
