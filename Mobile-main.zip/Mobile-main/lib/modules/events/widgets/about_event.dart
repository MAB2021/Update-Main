import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AboutEvent extends StatelessWidget {
  final EventModel eventModel;
  const AboutEvent({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        13.h.verticalSpace,
        Text(
          S.current.aboutEvent,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        10.h.verticalSpace,
        Text(
          eventModel.eventDescription,
          style: Theme.of(context).textTheme.titleSmall,
        ),
        13.h.verticalSpace,
      ],
    );
  }
}
