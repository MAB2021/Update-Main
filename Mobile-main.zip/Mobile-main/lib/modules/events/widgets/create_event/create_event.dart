import 'dart:io';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/models/add_event.dart';
import 'package:buzz_map/modules/events/routes/route.dart';
import 'package:buzz_map/modules/events/widgets/create_event/upload_widget.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_style.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/utils/upload_image.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/forms/input_drop_down.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:buzz_map/shared/widgets/platform_widget/platform_date_picker.dart';
import 'package:fl_country_code_picker/fl_country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CreateEventScreen extends StatefulWidget {
  const CreateEventScreen({super.key});

  @override
  State<CreateEventScreen> createState() => _CreateEventScreenState();
}

class _CreateEventScreenState extends State<CreateEventScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _eventName = TextEditingController();
  final TextEditingController _eventDescription = TextEditingController();
  final TextEditingController _eventCountry = TextEditingController();
  final TextEditingController _eventStartTime = TextEditingController();
  final TextEditingController _eventCity = TextEditingController();
  final TextEditingController _eventAddress = TextEditingController();
  final TextEditingController _eventInfo = TextEditingController();
  final TextEditingController _eventTimezone = TextEditingController();

  String? eventType;
  String? eventStartDateTime;
  LatLng? eventCoordinates;
  String? selectedEventCategory;
  String? formattedEventDate;

  bool isFormValid = false;

  File? coverPicture;
  File? eventImage1;
  File? eventImage2;
  File? eventImage3;

  String? coverPictureURL;
  String? eventImageURL1;
  String? eventImageURL2;
  String? eventImageURL3;

  bool isUploadingCoverPicture = false;
  bool isUploadingEventImage1 = false;
  bool isUploadingEventImage2 = false;
  bool isUploadingEventImage3 = false;

  List<CategoryModel> categories = [];
  CountryCode? selectedCountry;

  @override
  void initState() {
    categories = getIt<List<CategoryModel>>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final countryPicker = FlCountryCodePicker(
      localize: true,
      showDialCode: true,
      showSearchBar: true,
      title: Padding(
        padding: EdgeInsets.only(left: 16.w, top: 10.h, bottom: 10.h),
        child: Text(
          "Select a country",
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w500),
        ),
      ),
      searchBarTextStyle: Theme.of(context).textTheme.headlineSmall,
      countryTextStyle: Theme.of(context).textTheme.titleMedium,
      dialCodeTextStyle: Theme.of(context).textTheme.titleMedium,
      searchBarDecoration: InputDecoration(
        // prefixIconConstraints: BoxConstraints(maxHeight: 40.w),

        labelStyle: Theme.of(context).textTheme.labelSmall,
        hintText: "Select a country",
        hintStyle: Theme.of(context).textTheme.displaySmall,
        isDense: true,
        filled: true,
        fillColor: !AdaptiveTheme.of(context).mode.isDark
            ? AppColors.lightInputFiledColor
            : AppColors.primaryColor,
        border: AppStyles.focusedBorder,
        focusedBorder: AppStyles.focusedBorder,
        disabledBorder: AppStyles.focusBorder,
        enabledBorder: AppStyles.focusBorder,
        errorBorder: AppStyles.focusErrorBorder,
        focusedErrorBorder: AppStyles.focusErrorBorder,
      ),
    );
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: const SizedBox.shrink(),
        leadingWidth: 0.w,
        centerTitle: false,
        title: BackButtonWithTitle(text: S.current.createNewEvent),
      ),
      body: BlocConsumer(
        bloc: getIt<EventsCubit>(),
        listener: (context, state) {
          if (state is AddEventLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is AddEventSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            getIt<NavigationService>().back();
            NotificationMessage.showMessage(
              context,
              message: state.message,
              isError: false,
            );
          } else if (state is AddEventFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          } else if (state is GettingEventTimezone) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is GettingEventTimezoneSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            _eventTimezone.text = state.timezone;
          } else if (state is AddEventFailed) {
            DialogUtil.dismissLoadingDialog(context);
            getIt<NavigationService>().back();
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  UploadWidget(
                    onSelectFile: onSelectCoverPicture,
                    file: coverPicture,
                    deleteFile: onDeleteCoverPicture,
                    isOptional: true,
                    showText: true,
                    height: 130,
                    width: MediaQuery.of(context).size.width,
                    imageUrl: coverPictureURL ?? "",
                    isLoading: isUploadingCoverPicture,
                  ),
                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //   children: [
                  //     UploadWidget(
                  //       onSelectFile: (file) => onSelectEventPicture(file, 1),
                  //       file: eventImage1,
                  //       deleteFile: () => onDeleteEventPicture(1),
                  //       isOptional: true,
                  //       height: 100,
                  //       width: 100,
                  //       imageUrl: eventImageURL1 ?? "",
                  //       isLoading: isUploadingEventImage1,
                  //     ),
                  //     UploadWidget(
                  //       onSelectFile: (file) => onSelectEventPicture(file, 2),
                  //       file: eventImage2,
                  //       deleteFile: () => onDeleteEventPicture(2),
                  //       isOptional: true,
                  //       height: 100,
                  //       width: 100,
                  //       imageUrl: eventImageURL2 ?? "",
                  //       isLoading: isUploadingEventImage2,
                  //     ),
                  //     UploadWidget(
                  //       onSelectFile: (file) => onSelectEventPicture(file, 3),
                  //       file: eventImage3,
                  //       deleteFile: () => onDeleteEventPicture(3),
                  //       isOptional: true,
                  //       height: 100,
                  //       width: 100,
                  //       imageUrl: eventImageURL3 ?? "",
                  //       isLoading: isUploadingEventImage3,
                  //     ),
                  //   ],
                  // ),
                  // 27.h.verticalSpace,
                  const BuzzMapDivider(),
                  24.h.verticalSpace,
                  Text(
                    S.current.eventDetail,
                    style: Theme.of(context).textTheme.displayMedium!.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                  24.h.verticalSpace,

                  CustomDropdownButton(
                    hint: S.of(context).eventCategory,
                    value: selectedEventCategory,
                    dropdownItems:
                        categories.map((e) => e.categoryName).toList(),
                    onChanged: (value) {
                      if (value == null) {
                        selectedEventCategory = null;
                      } else {
                        selectedEventCategory = value;
                      }
                      setState(() {});
                      checkFormValid();
                    },
                  ),
                  20.h.verticalSpace,
                  InputText(
                    controller: _eventName,
                    labelText: S.current.eventName,
                    keyboardType: TextInputType.name,
                    validator: (value) =>
                        Validator.requiredValidator(value, S.current.eventName),
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => checkFormValid(),
                    isFilled: true,
                  ),
                  20.h.verticalSpace,
                  InputText(
                    controller: _eventDescription,
                    labelText: S.current.eventDescription,
                    keyboardType: TextInputType.name,
                    validator: (value) => Validator.requiredValidator(
                        value, S.current.eventDescription),
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => checkFormValid(),
                    isFilled: true,
                  ),
                  20.h.verticalSpace,
                  InputText(
                    controller: _eventInfo,
                    labelText: S.current.eventInfo,
                    keyboardType: TextInputType.name,
                    validator: (value) =>
                        Validator.requiredValidator(value, S.current.eventInfo),
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => checkFormValid(),
                    isFilled: true,
                  ),

                  20.h.verticalSpace,
                  PlatformDatePicker(
                    controller: _eventStartTime,
                    validator: (value) =>
                        Validator.requiredValidator(value, "Event start date"),
                    onSaved: (val) {
                      eventStartDateTime = val!;
                    },
                    onChange: (val) {
                      eventStartDateTime = val;
                      // Parse the first date string
                      DateTime eventDate = DateTime.parse(eventStartDateTime!);

                      // Format the date to match the desired format
                      formattedEventDate =
                          "${eventDate.year}-${eventDate.month.toString().padLeft(2, '0')}-${eventDate.day.toString().padLeft(2, '0')} ${eventDate.hour.toString().padLeft(2, '0')}:${eventDate.minute.toString().padLeft(2, '0')}:${eventDate.second.toString().padLeft(2, '0')}";

                      checkFormValid();
                    },
                  ),
                  20.h.verticalSpace,
                  GestureDetector(
                    onTap: () async {
                      // Show the country code picker when tapped.
                      final picked = await countryPicker.showPicker(
                          scrollToDeviceLocale: true,
                          backgroundColor:
                              Theme.of(context).scaffoldBackgroundColor,
                          context: context);
                      // Null check
                      if (picked != null) {
                        setState(() {
                          selectedCountry = picked;
                          _eventCountry.text = selectedCountry!.name;
                        });
                      }
                    },
                    child: InputText(
                      controller: _eventCountry,
                      labelText: S.current.country,
                      keyboardType: TextInputType.streetAddress,
                      validator: (value) =>
                          Validator.requiredValidator(value, S.current.country),
                      textInputAction: TextInputAction.next,
                      // onChanged: (_) => checkFormValid(),
                      isFilled: true,
                      enabled: false,
                    ),
                  ),
                  20.h.verticalSpace,
                  GestureDetector(
                    onTap: () async {
                      var res = await getIt<NavigationService>()
                          .to(routeName: EventsRoutes.eventAddressSearchScreen);
                      setState(() {
                        _eventAddress.text = res["address"];
                        LatLng latLng = res["latLng"];
                        if (res["cityName"] != null) {
                          _eventCity.text = res["cityName"];
                        }
                        getIt<EventsCubit>().getTimezone(
                            latitude: latLng.latitude,
                            longitude: latLng.longitude);
                      });
                    },
                    child: InputText(
                      controller: _eventAddress,
                      labelText: S.current.eventAddress,
                      keyboardType: TextInputType.streetAddress,
                      validator: (value) => Validator.requiredValidator(
                          value, S.current.eventAddress),
                      textInputAction: TextInputAction.next,
                      onChanged: (_) => checkFormValid(),
                      isFilled: true,
                      enabled: false,
                    ),
                  ),

                  20.h.verticalSpace,
                  InputText(
                    controller: _eventCity,
                    labelText: S.current.city,
                    keyboardType: TextInputType.streetAddress,
                    validator: (value) =>
                        Validator.requiredValidator(value, S.current.city),
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => checkFormValid(),
                    isFilled: true,
                  ),
                  20.h.verticalSpace,
                  InputText(
                    enabled: false,
                    controller: _eventTimezone,
                    labelText: "Event Time Zone",
                    keyboardType: TextInputType.streetAddress,
                    validator: (value) =>
                        Validator.requiredValidator(value, "Event Time Zone"),
                    textInputAction: TextInputAction.next,
                    onChanged: (_) => checkFormValid(),
                    isFilled: true,
                  ),

                  46.h.verticalSpace,
                  BuzzMapButton(
                    text: S.current.createNewEventAndPublish,
                    onPressed: isFormValid
                        ? () {
                            final event = AddEvent(
                                eventName: _eventName.text,
                                eventDescription: _eventDescription.text,
                                eventStartDate: formattedEventDate!,
                                // eventStartDateTime!,
                                country: _eventCountry.text,
                                eventAddress: _eventAddress.text,
                                eventImage: coverPictureURL ?? "",
                                timeZone: _eventTimezone.text,
                                eventInfo: _eventInfo.text,
                                eventCity: _eventCity.text,
                                eventCategory: selectedEventCategory ?? "",
                                realCategory: selectedEventCategory ?? "",
                                isActive: false,
                                createdBy: getIt<User>().email);
                            getIt<EventsCubit>().addEvent(event: event);
                          }
                        : null,
                  ),
                  46.h.verticalSpace,
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void checkFormValid() {
    setState(() {
      isFormValid = _formKey.currentState?.validate() ?? false;
    });
  }

  Future<void> onSelectCoverPicture(File? file) async {
    setState(() {
      isUploadingCoverPicture = true;
    });

    if (file != null) {
      coverPictureURL = await UploadImage.uploadImage(imagePath: file.path);
    }

    setState(() {
      coverPicture = file;
      isUploadingCoverPicture = false;
    });
  }

  void onDeleteCoverPicture() {
    setState(() {
      coverPicture = null;
      coverPictureURL = null;
    });
  }

  Future<void> onSelectEventPicture(File? file, int index) async {
    setState(() {
      switch (index) {
        case 1:
          isUploadingEventImage1 = true;
          break;
        case 2:
          isUploadingEventImage2 = true;
          break;
        case 3:
          isUploadingEventImage3 = true;
          break;
      }
    });

    if (file != null) {
      final imageUrl = await UploadImage.uploadImage(imagePath: file.path);
      setState(() {
        switch (index) {
          case 1:
            eventImage1 = file;
            eventImageURL1 = imageUrl;
            isUploadingEventImage1 = false;
            break;
          case 2:
            eventImage2 = file;
            eventImageURL2 = imageUrl;
            isUploadingEventImage2 = false;
            break;
          case 3:
            eventImage3 = file;
            eventImageURL3 = imageUrl;
            isUploadingEventImage3 = false;
            break;
        }
      });
    }
  }

  void onDeleteEventPicture(int index) {
    setState(() {
      switch (index) {
        case 1:
          eventImage1 = null;
          eventImageURL1 = null;
          break;
        case 2:
          eventImage2 = null;
          eventImageURL2 = null;
          break;
        case 3:
          eventImage3 = null;
          eventImageURL3 = null;
          break;
      }
    });
  }
}
