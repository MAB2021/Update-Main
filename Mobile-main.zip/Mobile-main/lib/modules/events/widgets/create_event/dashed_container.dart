import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

class DashedBorderContainer extends StatelessWidget {
  final Widget child;
  final double? width, height;
  final double? borderWidth;
  final Color? borderColor;
  final double? borderRadius;
  final List<double>? dashPattern;
  const DashedBorderContainer({
    super.key,
    required this.child,
    this.borderWidth,
    this.height,
    this.width,
    this.borderColor,
    this.borderRadius,
    this.dashPattern,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: width,
      child: DottedBorder(
        borderType: BorderType.RRect,
        color: borderColor ?? Colors.black,
        strokeWidth: borderWidth ?? 1,
        radius: Radius.circular(borderRadius ?? 0),
        dashPattern: dashPattern ?? [5, 5],
        child: child,
      ),
    );
  }
}
