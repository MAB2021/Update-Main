import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ImageContainer extends StatelessWidget {
  final VoidCallback onTap;
  final String imagePath;
  final VoidCallback removeImage;
  final double height, width;
  const ImageContainer({
    super.key,
    required this.onTap,
    required this.imagePath,
    required this.removeImage,
    this.height = 85,
    this.width = 85,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: height.h,
        width: width.w,
        padding: EdgeInsets.all(5.w),
        margin: EdgeInsets.only(bottom: 10.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.r),
          border: Border.all(color: AppColors.secondaryColor, width: 0.5),
        ),
        child: Stack(
          children: [
            Center(
              child: imagePath.startsWith("https")
                  ? BuzzMapCacheImage(
                      imgUrl: imagePath,
                      height: height.h - 50,
                      width: width.w - 50,
                      // boxFit: BoxFit.fill,
                    )
                  : CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(
                        AppColors.primaryColor,
                      ),
                    ),
            ),
            Center(
              child: Container(
                height: 60.h,
                width: 60.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5.r),
                ),
              ),
            ),
            Positioned(
              top: -1,
              right: -1,
              child: GestureDetector(
                onTap: removeImage,
                child: Icon(
                  Icons.cancel,
                  size: 20.r,
                  color: AppColors.secondaryColor,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class SelectImageContainer extends StatelessWidget {
  final VoidCallback onTap;
  final String imagePath;
  final double? height;
  final double? width;
  final double? imageHeight;
  final double? imageWidth;
  const SelectImageContainer(
      {super.key,
      required this.onTap,
      required this.imagePath,
      this.height,
      this.width,
      this.imageHeight,
      this.imageWidth});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 75.h,
        width: 65.w,
        margin: EdgeInsets.only(right: 20.w, bottom: 20.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.r),
          border: Border.all(color: AppColors.secondaryColor, width: 0.5),
        ),
        child: Center(
          child: BuzzMapCacheImage(
            imgUrl: imagePath,
            borderRadius: 50.r,
            height: 56.h,
            width: 53.w,
            boxFit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}
