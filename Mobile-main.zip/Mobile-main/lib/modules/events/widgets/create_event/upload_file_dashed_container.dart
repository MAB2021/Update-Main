import 'dart:io';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/events/widgets/create_event/dashed_container.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/photo_bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class UploadFileWidgetWithDashedBorder extends StatefulWidget {
  final double height, width;
  final Function(File?) onsSelectFile;
  final bool showText;
  final bool isLoading;
  const UploadFileWidgetWithDashedBorder({
    super.key,
    required this.onsSelectFile,
    this.showText = false,
    required this.height,
    required this.width,
    this.isLoading = false,
  });

  @override
  State<UploadFileWidgetWithDashedBorder> createState() =>
      _UploadFileWidgetWithDashedBorderState();
}

class _UploadFileWidgetWithDashedBorderState
    extends State<UploadFileWidgetWithDashedBorder> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showPhotoDialogBottomSheet(
        context: context,
        onCompleted: (File file) {
          checkFileSize(file);
        },
      ),
      child: DashedBorderContainer(
        height: widget.height.h,
        width: widget.width.w,
        borderRadius: 10.0.r,
        borderWidth: 1,
        borderColor: AppColors.buzzMapGrayLight[80],
        child: widget.isLoading
            ? Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppColors.primaryColor,
                  ),
                ),
              )
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    BuzzMapAssetImage(
                      url: AssetResources.purpleAddEvent,
                      height: 20.h,
                      width: 20.w,
                    ),
                    Visibility(
                        visible: widget.showText, child: 17.h.verticalSpace),
                    Visibility(
                      visible: widget.showText,
                      child: Text(S.current.addCoverPhotos,
                          // "\n${S.current.imageTypes}",
                          style: Theme.of(context).textTheme.titleSmall),
                    )
                  ],
                ),
              ),
      ),
    );
  }

  void checkFileSize(File file) {
    // Set max file size as 1GB (1 * 1024 * 1024 * 1024 bytes)
    const int maxFileSize = 1 * 1024 * 1024 * 1024;

    // Check if the file is too large
    if (file.lengthSync() > maxFileSize) {
      NotificationMessage.showMessage(
        context,
        message: S.current
            .fileTooLarge(maxFileSize ~/ (1024 * 1024)), // Display size in MB
        isError: true,
      );
      return;
    } else {
      setState(() {
        widget.onsSelectFile(file);
      });
    }
  }
}
