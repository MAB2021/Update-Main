import 'dart:io';
import 'package:buzz_map/modules/events/widgets/create_event/image_container.dart';
import 'package:buzz_map/shared/utils/image_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'upload_file_dashed_container.dart';

class UploadWidget extends StatefulWidget {
  final Function(File?) onSelectFile;
  final File? file;
  final Function deleteFile;
  final bool? isOptional;
  final bool showText;
  final double height, width;
  final bool isLoading;
  final String imageUrl;
  const UploadWidget(
      {super.key,
      required this.onSelectFile,
      this.file,
      required this.deleteFile,
      this.isOptional = false,
      this.showText = false,
      required this.height,
      required this.width,
      this.isLoading = false,
      this.imageUrl = ""});

  @override
  State<UploadWidget> createState() => _UploadWidgetState();
}

class _UploadWidgetState extends State<UploadWidget> {
  // Initialize the ImageUtil class
  final ImageUtil imageUtil = ImageUtil();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 5.verticalSpace,
        // widget.file != null
        //     ? FutureBuilder(
        //         future: imageUtil.getFileSizeIfNeeded(widget.file!.path, 1),
        //         builder: (BuildContext context, AsyncSnapshot snapshot) {
        //           if (snapshot.connectionState == ConnectionState.waiting) {
        //             return SizedBox(
        //               width: 10.w,
        //               child: LinearProgressIndicator(
        //                 color: AppColors.primaryColor,
        //                 backgroundColor: AppColors.secondaryColor,
        //               ),
        //             ); // Show a loading indicator while fetching data
        //           } else if (snapshot.hasError) {
        //             return Text('Error: ${snapshot.error}');
        //           } else if (snapshot.data == -1) {
        //             return const Text('Error getting file size');
        //           } else {
        //             return Text(' ${snapshot.data} ',
        //                 style: Theme.of(context).textTheme.titleSmall);
        //           }
        //         },
        //       )
        //     : const SizedBox.shrink(),

        5.verticalSpace,
        widget.imageUrl != ""
            ? ImageContainer(
                onTap: () async {},
                removeImage: () {
                  widget.deleteFile();
                },
                imagePath: widget.imageUrl,
                height: widget.height,
                width: widget.width,
              )
            : UploadFileWidgetWithDashedBorder(
                onsSelectFile: widget.onSelectFile,
                showText: widget.showText,
                height: widget.height,
                width: widget.width,
                isLoading: widget.isLoading,
              ),
        16.verticalSpace
      ],
    );
  }
}
