import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/widgets/event_details_widget.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/events/added_to_bookmark.dart';
import 'package:buzz_map/shared/widgets/events/rate_event.dart';
import 'package:buzz_map/shared/widgets/events/removed_from_bookmark.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:lottie/lottie.dart' as lottie;

class EventDetailScreen extends StatefulWidget {
  final EventModel? eventModel;
  final String? eventId;
  const EventDetailScreen({super.key, this.eventModel, this.eventId});

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen> {
  EventModel? eventModel;
  bool isLoading = false;

  Set<Marker> markers = {};
  @override
  void initState() {
    eventModel = widget.eventModel;
    if (widget.eventId != null) {
      getIt<EventsCubit>().getEventById(eventId: widget.eventId!);
      isLoading = true;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<EventsCubit>(),
        listener: (context, state) {
          if (state is RateEventLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is RateEventSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            rateEventDialog(S.current.ratingSaved);
          } else if (state is RateEventFailed) {
            DialogUtil.dismissLoadingDialog(context);
            rateEventDialog(state.errorMessage);
          } else if (state is GetEventByIdLoading) {
          } else if (state is GetEventByIdSuccess) {
            eventModel = state.event;
            isLoading = false;
          } else if (state is GetEventByIdFailed) {
            rateEventDialog(state.errorMessage);
            isLoading = false;
          }
        },
        builder: (context, state) {
          return eventModel == null
              ? Container(
                  height: MediaQuery.of(context).size.height,
                  decoration: BoxDecoration(
                    color: AppColors.buzzMapWhite,
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  child: Center(
                    child: SizedBox(
                      height: 70.h,
                      child: lottie.LottieBuilder.asset(
                        "assets/json/loader.json",
                        height: 100.h,
                      ),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  child: Column(
                    children: [
                      Stack(
                        children: [
                          ColorFiltered(
                            colorFilter: ColorFilter.mode(
                              Colors.black.withOpacity(0.45),
                              BlendMode.srcOver,
                            ),
                            child: BuzzMapCacheImage(
                              width: double.infinity,
                              height: 349.h,
                              boxFit: BoxFit.cover,
                              memCacheHeight: 1000,
                              memCacheWidth: 1000,
                              imgUrl: eventModel!.eventImage,
                            ),
                          ),
                          Positioned(
                            top: 40.h,
                            left: 0.w,
                            right: 300.w,
                            child: GestureDetector(
                              onTap: () {
                                getIt<NavigationService>().back();
                              },
                              child: BuzzMapAssetImage(
                                url: AssetResources.backArrow,
                                height: 30.h,
                                width: 30.w,
                              ),
                            ),
                          ),
                        ],
                      ),
                      9.h.verticalSpace,
                      EventDetailsWidget(eventModel: eventModel!),
                      50.h.verticalSpace,
                    ],
                  ),
                );
        },
      ),
    );
  }

  addedToBookmark() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const AddedToBookmarkWidget();
        });
  }

  removedFromBookmark() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const RemovedFromBookmarkWidget();
        });
  }

  rateEventDialog(message) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return RateEventDialogWidget(
            message: message,
          );
        });
  }
}
