import 'dart:async';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/calendar/cubit/calendar_cubit.dart';
import 'package:buzz_map/modules/calendar/utils.dart';
import 'package:buzz_map/modules/events/widgets/about_event.dart';
import 'package:buzz_map/modules/calendar/widgets/event_to_calendar.dart';
import 'package:buzz_map/modules/events/widgets/event_location.dart';
import 'package:buzz_map/modules/events/widgets/event_location_map.dart';
import 'package:buzz_map/modules/events/widgets/event_review.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/utils/map_launcher.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/events/event_category_tag.dart';
import 'package:buzz_map/shared/widgets/events/network_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:device_calendar/device_calendar.dart';

class EventDetailsWidget extends StatefulWidget {
  final EventModel eventModel;
  const EventDetailsWidget({super.key, required this.eventModel});

  @override
  State<EventDetailsWidget> createState() => _EventDetailsWidgetState();
}

class _EventDetailsWidgetState extends State<EventDetailsWidget> {
  final CalendarUtil _calendarUtil = CalendarUtil();
  bool showRemoveFromCalendar = false;
  Event? _event;
  CalendarCubit calendarCubit =
      getIt<CalendarCubit>(instanceName: "eventDetails");

// As an example, our default timezone is UTC.
  Location _currentLocation = getLocation('UTC');

  Future setCurrentLocation() async {
    String timezone = 'UTC';
    try {
      timezone = await FlutterTimezone.getLocalTimezone();
      debugPrint(timezone);
    } catch (e) {
      debugPrint('Could not get the local timezone');
    }
    _currentLocation = getLocation(timezone);
    setLocalLocation(_currentLocation);
  }

  @override
  void initState() {
    setCurrentLocation();
    _searchEvent();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              EventCategoryTagWidget(name: widget.eventModel.eventCategory),
              if (widget.eventModel.heatMap != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: NetworkSignalIndicator(
                      signalStrength: widget.eventModel.heatMap!),
                ),
            ],
          ),
          14.h.verticalSpace,
          Row(
            children: [
              Expanded(
                child: Text(
                  widget.eventModel.eventName,
                  style: Theme.of(context).textTheme.displayMedium!.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                  maxLines: 2,
                ),
              ),
              // 10.w.horizontalSpace,
              // EventRatingTagWidget(
              //   ratings: widget.eventModel.ratings,
              // ),
            ],
          ),
          14.h.verticalSpace,
          BlocConsumer(
            bloc: calendarCubit,
            listener: (context, state) {
              if (state is AddingEvent) {
              } else if (state is AddEventState) {
                showRemoveFromCalendar = true;
                _event = Event(
                  AppConstants.calendarName,
                  eventId: state.eventId,
                  title: widget.eventModel.eventName,
                  description: widget.eventModel.eventDescription,
                  start: TZDateTime.from(
                      widget.eventModel.eventStartDate, _currentLocation),
                  end: TZDateTime.from(
                      widget.eventModel.eventStartDate
                          .add(const Duration(days: 1)),
                      _currentLocation),
                  location: widget.eventModel.eventAddress,
                  // url: Uri.parse(widget.eventModel.eventInfo),
                );
                eventToCalendar(S.current.eventHasBeenAddedToCalendar);
              } else if (state is AddEventFailed) {
                eventToCalendar(state.errorMessage);
              } else if (state is RemovingEventsState) {
              } else if (state is RemoveEventState) {
                showRemoveFromCalendar = false;
                eventToCalendar(S.current.eventHasBeenRemovedFromCalendar);
                getIt<CalendarCubit>().getEvents(DateTime.now(),
                    DateTime.now().add(const Duration(days: 30 * 13)));
              } else if (state is RemovingEventsFailedState) {
                eventToCalendar(state.errorMessage);
              }
            },
            builder: (context, state) {
              return GestureDetector(
                onTap: () async {
                  if (showRemoveFromCalendar) {
                    removeEventFromCalendar();
                  } else {
                    addEventToCalendar();
                  }
                },
                child: EventAddressLocationWidget(
                  iconUrl: AssetResources.calendar,
                  title:
                      convertDate(widget.eventModel.eventStartDate.toString()),
                  subTitle: widget.eventModel.hideTime
                      ? null
                      : formatWeekDayTime(
                          widget.eventModel.eventStartDate.toString()),
                  buttonWidget: Container(
                    height: 40.h,
                    alignment: Alignment.center,
                    constraints: BoxConstraints(maxWidth: 178.w),
                    padding: EdgeInsets.symmetric(horizontal: 10.w),
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(81.r),
                      border: Border.all(
                        color: Theme.of(context).primaryColorDark,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      showRemoveFromCalendar
                          ? S.current.removeFromCalendar
                          : S.current.addToCalendar,
                      style:
                          Theme.of(context).textTheme.displayMedium!.copyWith(
                                fontSize: 13.sp,
                              ),
                    ),
                  ),
                ),
              );
            },
          ),
          14.h.verticalSpace,
          GestureDetector(
            onTap: () {
              openMapsSheet(
                  context: context,
                  address: widget.eventModel.eventAddress,
                  latitude: widget.eventModel.eventLatitude,
                  longitude: widget.eventModel.eventLongitude);
            },
            child: EventAddressLocationWidget(
              iconUrl: AssetResources.purpleLocation,
              title: widget.eventModel.eventAddress,
              buttonWidget: Container(
                height: 40.h,
                constraints: BoxConstraints(maxWidth: 120.w),
                alignment: Alignment.center,
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(81.r),
                  border: Border.all(
                    color: Theme.of(context).primaryColorDark,
                    width: 1,
                  ),
                ),
                child: Text(
                  S.current.seeOnMaps,
                  style: Theme.of(context).textTheme.displayMedium!.copyWith(
                        fontSize: 13.sp,
                      ),
                ),
              ),
            ),
          ),
          20.h.verticalSpace,
          BuzzMapButton(
            onPressed: () {},
            child: Text(
              S.current.viewParticipantsDiscussions,
              style: GoogleFonts.outfit(
                color: Colors.white,
                fontSize: 16.sp,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          13.h.verticalSpace,
          const BuzzMapDivider(),
          AboutEvent(eventModel: widget.eventModel),
          EventLocationMap(eventModel: widget.eventModel),
          ReviewWidget(
            eventModel: widget.eventModel,
          ),
        ],
      ),
    );
  }

  eventToCalendar(String message) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return EventToCalendarWidget(
          message: message,
        );
      },
    );
  }

  addEventToCalendar() async {
    final calendarId = await _calendarUtil.getOrCreateCalendar();

    final newEvent = Event(
      calendarId,
      title: widget.eventModel.eventName,
      description: widget.eventModel.eventId,
      start:
          TZDateTime.from(widget.eventModel.eventStartDate, _currentLocation),
      end: TZDateTime.from(
          widget.eventModel.eventStartDate.add(const Duration(days: 1)),
          _currentLocation),
      location: widget.eventModel.eventAddress,
      // url: Uri.parse(widget.eventModel.eventInfo),
    );

    calendarCubit.addEvent(newEvent, calendarId);
  }

  removeEventFromCalendar() {
    calendarCubit.removeEvent(_event!.eventId!);
  }

  Future<void> _searchEvent() async {
    final event = await _calendarUtil.findEventByTitleAndDate(
      AppConstants.calendarName,
      widget.eventModel.eventName,
      widget.eventModel.eventStartDate,
    );
    if (event != null) {
      _event = event;
      showRemoveFromCalendar = true;
    }
    setState(() {
      _event = event;
    });
  }
}
