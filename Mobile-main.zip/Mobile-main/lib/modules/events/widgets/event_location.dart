import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EventAddressLocationWidget extends StatelessWidget {
  final String title;
  final String? subTitle;
  final String iconUrl;
  final Widget buttonWidget;
  const EventAddressLocationWidget(
      {super.key,
      required this.title,
      this.subTitle,
      required this.iconUrl,
      required this.buttonWidget});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          alignment: Alignment.center,
          height: 55.h,
          width: 55.w,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isDarkMode
                  ? AppColors.primaryColor
                  : AppColors.lightInputFiledColor),
          child: BuzzMapAssetImage(
            url: iconUrl,
          ),
        ),
        10.w.horizontalSpace,
        SizedBox(
          width: 200.w,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium,
                maxLines: 2,
              ),
              Visibility(visible: subTitle != null, child: 5.h.verticalSpace),
              Visibility(
                visible: subTitle != null,
                child: Text(
                  subTitle ?? "",
                  style: Theme.of(context).textTheme.titleSmall,
                ),
              ),
              5.h.verticalSpace,
              buttonWidget
            ],
          ),
        )
      ],
    );
  }
}
