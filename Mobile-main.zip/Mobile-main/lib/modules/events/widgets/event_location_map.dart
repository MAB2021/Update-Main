import 'dart:async';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class EventLocationMap extends StatefulWidget {
  final EventModel eventModel;
  const EventLocationMap({super.key, required this.eventModel});

  @override
  State<EventLocationMap> createState() => _EventLocationMapState();
}

class _EventLocationMapState extends State<EventLocationMap> {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  String? _mapStyle;

  @override
  void initState() {
    rootBundle.loadString('assets/map_style.txt').then((string) {
      _mapStyle = string;
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(S.current.location,
            style: Theme.of(context).textTheme.titleMedium),
        10.h.verticalSpace,
        ClipRRect(
          borderRadius: BorderRadius.circular(10.r),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 150.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: GoogleMap(
                  mapType: MapType.normal,
                  myLocationButtonEnabled: false,
                  initialCameraPosition: CameraPosition(
                    target: LatLng(widget.eventModel.eventLatitude,
                        widget.eventModel.eventLongitude),
                    zoom: 15,
                  ),
                  onMapCreated: (GoogleMapController controller) {
                    _controller.complete(controller);
                    controller.setMapStyle(_mapStyle);
                  },
                ),
              ),
              BuzzMapAssetImage(
                url: AssetResources.mapMarker,
                fit: BoxFit.scaleDown,
                height: 30.h,
                width: 30.w,
              ),
            ],
          ),
        ),
      ],
    );
  }
}