import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/events/widgets/rate_event.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/events/bookmark.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';

class ReviewWidget extends StatelessWidget {
  final EventModel eventModel;
  const ReviewWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        20.h.verticalSpace,
        Text(S.current.reviews, style: Theme.of(context).textTheme.titleMedium),
        10.h.verticalSpace,
        Text(S.current.comingSoonAfterEvent,
            style: Theme.of(context).textTheme.titleSmall),
        14.h.verticalSpace,
        const BuzzMapDivider(),
        11.h.verticalSpace,
        Row(
          children: [
            Row(
              children: [
                InkWell(
                  onTap: () {
                    String shareMessage = '''
    Join us for ${eventModel.eventCategory} ${eventModel.eventName} ${eventModel.eventDescription} event  
    happening at ${eventModel.eventAddress} on ${eventModel.eventStartDate} with ${eventModel.attending} attending and ${eventModel.ratings} ratings. Download the app now to get more details.
    ''';

                    Share.share(shareMessage);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    height: 40.h,
                    width: 40.w,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color:
                            isDarkMode ? AppColors.primaryColor : Colors.white),
                    child: BuzzMapAssetImage(
                      url: isDarkMode
                          ? AssetResources.shuffle
                          : AssetResources.blackShuffle,
                    ),
                  ),
                ),
                14.w.horizontalSpace,
                AddAndRemoveBookmarkWidget(
                  eventModel: eventModel,
                  index: 1,
                  widgetIdentifier: "eventDetail",
                  height: 40.h,
                  width: 40.w,
                ),
              ],
            ),
            const Spacer(),
            BuzzMapButton(
              width: 189.w,
              height: 60.h,
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (BuildContext context) {
                    return ReusableBottomSheet(
                      minHeight: 600,
                      initHeight: 600,
                      maxHeight: 800,
                      backgroundColor: isDarkMode
                          ? AppColors.inputFiledColor
                          : AppColors.buzzMapWhite,
                      content: RateEventWidget(
                        eventModel: eventModel,
                      ),
                    );
                  },
                );
              },
              child: Text(
                S.current.rateEvent,
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
