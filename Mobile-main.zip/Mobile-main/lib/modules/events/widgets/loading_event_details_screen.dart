import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/widgets/event_details_widget.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/events/added_to_bookmark.dart';
import 'package:buzz_map/shared/widgets/events/rate_event.dart';
import 'package:buzz_map/shared/widgets/events/removed_from_bookmark.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class LoadingEventDetailScreen extends StatefulWidget {
  final String eventId;
  const LoadingEventDetailScreen({super.key, required this.eventId});

  @override
  State<LoadingEventDetailScreen> createState() =>
      _LoadingEventDetailScreenState();
}

class _LoadingEventDetailScreenState extends State<LoadingEventDetailScreen> {
  EventModel? eventModel;

  Set<Marker> markers = {};
  @override
  void initState() {
    getIt<EventsCubit>().getEventById(eventId: widget.eventId);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<EventsCubit>(),
        listener: (context, state) {
          if (state is GetEventByIdLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is GetEventByIdSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            eventModel = state.event;
          } else if (state is GetEventByIdFailed) {
            DialogUtil.dismissLoadingDialog(context);
            rateEventDialog(state.errorMessage);
          }
        },
        builder: (context, state) {
          return SingleChildScrollView(
            child: Column(
              children: [
                Stack(
                  // alignment: Alignment.topLeft,
                  children: [
                    ColorFiltered(
                      colorFilter: ColorFilter.mode(
                        Colors.black.withOpacity(0.45),
                        BlendMode.srcOver,
                      ),
                      child: BuzzMapCacheImage(
                          width: double.infinity,
                          height: 349.h,
                          boxFit: BoxFit.cover,
                          memCacheHeight: 1000,
                          memCacheWidth: 1000,
                          imgUrl: eventModel!.eventImage),
                    ),
                    Positioned(
                      top: 40.h,
                      left: 0.w,
                      right: 300.w,
                      child: const CustomBackButton(),
                    ),
                  ],
                ),
                9.h.verticalSpace,
                EventDetailsWidget(eventModel: eventModel!),
                50.h.verticalSpace,
              ],
            ),
          );
        },
      ),
    );
  }

  addedToBookmark() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const AddedToBookmarkWidget();
        });
  }

  removedFromBookmark() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const RemovedFromBookmarkWidget();
        });
  }

  rateEventDialog(message) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return RateEventDialogWidget(
            message: message,
          );
        });
  }
}
