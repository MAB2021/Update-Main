import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/models/rate_event.dart';
import 'package:buzz_map/modules/home/widgets/trending/all_trending/all_trending_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class RateEventWidget extends StatefulWidget {
  final EventModel eventModel;
  const RateEventWidget({super.key, required this.eventModel});

  @override
  State<RateEventWidget> createState() => _RateEventWidgetState();
}

class _RateEventWidgetState extends State<RateEventWidget> {
  EventModel get eventModel => widget.eventModel;
  TextEditingController commentController = TextEditingController();
  String comment = "";
  num ratingNumber = 0;

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Column(
      children: [
        const BottomSheetGreyContainer(),
        29.h.verticalSpace,
        AllTrendingItem(model: eventModel, index: -1),
        // Container(
        //   height: 150.h,
        //   width: double.infinity,
        //   decoration: BoxDecoration(
        //     borderRadius: BorderRadius.circular(10.r),
        //     border: Border.all(color: AppColors.buzzMapGrayLight[80]!),
        //   ),
        //   child: BuzzMapCacheImage(
        //       width: double.infinity,
        //       height: 77.h,
        //       boxFit: BoxFit.fitWidth,
        //       memCacheHeight: 800,
        //       memCacheWidth: 800,
        //       borderRadius: 10.r,
        //       imgUrl: eventModel.eventImage),
        // ),
        16.h.verticalSpace,
        // Text(
        //   eventModel.eventName,
        //   style: Theme.of(context).textTheme.titleMedium!.copyWith(
        //         fontSize: 20.sp,
        //         fontWeight: FontWeight.w700,
        //       ),
        //   textAlign: TextAlign.center,
        //   maxLines: 1,
        // ),
        16.h.verticalSpace,
        RatingBar.builder(
          initialRating: 2,
          minRating: 0,
          direction: Axis.horizontal,
          allowHalfRating: true,
          glow: false,
          itemCount: 5,
          itemSize: 32.w,
          unratedColor:
              isDarkMode ? AppColors.buzzMapWhite : AppColors.primaryColor,
          itemPadding: EdgeInsets.symmetric(horizontal: 12.w),
          itemBuilder: (context, _) =>
              const BuzzMapAssetImage(url: AssetResources.purpleStar),
          onRatingUpdate: (rating) {
            ratingNumber = rating;
            setState(() {});
          },
        ),
        23.h.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text(
                  S.current.addComment,
                  style: Theme.of(context).textTheme.displayMedium!.copyWith(
                        fontSize: 16.sp,
                      ),
                ),
                2.w.horizontalSpace,
                Text(
                  "*",
                  style: GoogleFonts.outfit(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: AppColors.red,
                  ),
                ),
              ],
            ),
            Text(
              S.current.maxWord,
              style: GoogleFonts.outfit(
                fontSize: 13.sp,
                fontWeight: FontWeight.w400,
                color: AppColors.buzzMapGrayLight[80],
              ),
            )
          ],
        ),
        7.h.verticalSpace,
        TextFormField(
          maxLines: 2,
          cursorColor: AdaptiveTheme.of(context).mode.isDark
              ? AppColors.lightInputFiledColor
              : AppColors.inputFiledColor,
          inputFormatters: [
            LengthLimitingTextInputFormatter(250),
          ],
          style: GoogleFonts.outfit(
            color: AdaptiveTheme.of(context).mode.isDark
                ? AppColors.buzzMapWhite
                : AppColors.primaryColor,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(
                8.r,
              ),
              borderSide: BorderSide(
                color: Theme.of(context).primaryColorDark,
                width: 1.w,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(
                8.r,
              ),
              borderSide: BorderSide(
                color: Theme.of(context).primaryColorDark,
                width: 1.w,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(
                8.r,
              ),
              borderSide: BorderSide(
                color: Theme.of(context).primaryColorDark,
                width: 1.w,
              ),
            ),
          ),
          onChanged: (value) {
            comment = value;
            setState(() {});
          },
        ),
        19.h.verticalSpace,
        const BuzzMapDivider(),
        16.h.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            BuzzMapButton(
              borderRadius: 10.r,
              height: 60.h,
              width: 153.w,
              color: Colors.transparent,
              borderColor: Theme.of(context).primaryColorDark,
              child: Text(
                S.current.cancel,
                style: GoogleFonts.outfit(
                  color: isDarkMode
                      ? AppColors.buzzMapWhite
                      : Colors.black.withOpacity(0.5),
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              onPressed: () {
                getIt<NavigationService>().back();
              },
            ),
            BuzzMapButton(
              borderRadius: 10.r,
              height: 60.h,
              width: 153.w,
              color: Theme.of(context).primaryColorDark,
              child: Text(
                S.current.rateNow,
                style: GoogleFonts.outfit(
                  color: AppColors.buzzMapWhite,
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
              onPressed: () {
                getIt<EventsCubit>().rateEvent(
                    rateEvent: RateEvent(
                  eventId: eventModel.eventId,
                  score: ratingNumber,
                  description: comment,
                ));
                getIt<NavigationService>().back();
              },
            )
          ],
        ),
      ],
    );
  }
}
