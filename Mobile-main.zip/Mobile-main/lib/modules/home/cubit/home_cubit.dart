import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/home/models/home_model.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  final HomeApiService apiService;

  HomeCubit({required this.apiService}) : super(HomeInitial());

  void getCategories() async {
    emit(GetCategoriesLoading());
    try {
      final response = await apiService.getCategories();
      if (response.isSuccessful && response.data['status'] == 200) {
        List<CategoryModel> categories = [];
        response.data['data']['categories'].forEach((category) {
          categories.add(CategoryModel.fromJson(category));
        });
        getIt.registerSingleton<List<CategoryModel>>(categories);
        emit(GetCategoriesSuccess(categories: categories));
      } else {
        emit(GetCategoriesFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetCategoriesFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetCategoriesFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void searchEvents({required String keyword, required int pageNumber}) async {
    emit(SearchEventsLoading());
    try {
      final response = await apiService.searchForEventsCategories(
          keyword: keyword, pageNumber: pageNumber);
      if (response.isSuccessful && response.data['status'] == 200) {
        List<EventModel> events = [];
        response.data['data'].forEach((event) {
          events.add(EventModel.fromJson(event));
        });
        emit(SearchEventsSuccess(
          events: events,
        ));
      } else {
        emit(SearchEventsFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(SearchEventsFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(SearchEventsFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void getEvents(
      {required String category,
      required int pageNumber,
      required bool isNearByLocation,
      required bool isTrending}) async {
    emit(GetEventsLoading());
    try {
      final response = await apiService.getEvents(
          category: category,
          pageNumber: pageNumber,
          isNearByLocation: isNearByLocation,
          isTrending: isTrending);
      if (response.isSuccessful && response.data['status'] == 200) {
        List<EventModel> events = [];
        isNearByLocation
            ? response.data['data']['nearby'].forEach((event) {
                events.add(EventModel.fromJson(event));
              })
            : response.data['data']['trending'].forEach((event) {
                events.add(EventModel.fromJson(event));
              });
        emit(GetEventsSuccess(events: events, categoryName: category));
      } else {
        emit(GetEventsFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetEventsFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetEventsFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void getHomeEvents({String? categoryName}) async {
    emit(GettingHomeData());
    try {
      final response = await apiService.getHomeEvents(category: categoryName);
      if (response.isSuccessful && response.data['status'] == 200) {
        HomeDataModel homeModel = HomeDataModel.fromJson(response.data['data']);
        emit(GetHomeDataSuccess(
            homeDataModel: homeModel, categoryName: categoryName));
      } else {
        emit(GetHomeDataFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetHomeDataFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetHomeDataFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
