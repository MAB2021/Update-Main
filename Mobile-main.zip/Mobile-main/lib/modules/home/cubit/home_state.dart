part of 'home_cubit.dart';

@immutable
abstract class HomeState extends Equatable {
  const HomeState();
  @override
  List<Object?> get props => [];
}

class HomeInitial extends HomeState {}

//Get categories

class GetCategoriesLoading extends HomeState {}

class GetCategoriesSuccess extends HomeState {
  final List<CategoryModel> categories;

  const GetCategoriesSuccess({required this.categories});
}

class GetCategoriesFailed extends HomeState {
  final String errorMessage;

  const GetCategoriesFailed({required this.errorMessage});
}

//Search events
class SearchEventsLoading extends HomeState {}

class SearchEventsSuccess extends HomeState {
  final List<EventModel> events;

  @override
  List<Object?> get props => [events];

  const SearchEventsSuccess({
    required this.events,
  });
}

class SearchEventsFailed extends HomeState {
  final String errorMessage;

  const SearchEventsFailed({required this.errorMessage});
}

//Get events

class GetEventsLoading extends HomeState {}

class GetEventsSuccess extends HomeState {
  final List<EventModel> events;
  final String categoryName;
  @override
  List<Object?> get props => [events, categoryName];
  const GetEventsSuccess({required this.events, required this.categoryName});
}

class GetEventsFailed extends HomeState {
  final String errorMessage;

  const GetEventsFailed({required this.errorMessage});
}

//Get home data

class GettingHomeData extends HomeState {}

class GetHomeDataSuccess extends HomeState {
  final HomeDataModel homeDataModel;
  final String? categoryName;

  @override
  List<Object?> get props => [homeDataModel, categoryName];

  const GetHomeDataSuccess({required this.homeDataModel, this.categoryName});
}

class GetHomeDataFailed extends HomeState {
  final String errorMessage;

  const GetHomeDataFailed({required this.errorMessage});
}
