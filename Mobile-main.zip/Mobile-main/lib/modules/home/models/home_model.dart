import 'dart:convert';

import 'package:buzz_map/shared/models/event_model.dart';

HomeDataModel homeDataModelFromJson(String str) =>
    HomeDataModel.fromJson(json.decode(str));

String homeDataModelToJson(HomeDataModel data) => json.encode(data.toJson());

class HomeDataModel {
  final List<EventModel> featured;
  final List<EventModel> trending;
  final List<EventModel> nearby;

  HomeDataModel({
    required this.featured,
    required this.trending,
    required this.nearby,
  });

  factory HomeDataModel.fromJson(Map<String, dynamic> json) => HomeDataModel(
        featured: List<EventModel>.from(
            json["featured"].map((x) => EventModel.fromJson(x))),
        trending: List<EventModel>.from(
            json["trending"].map((x) => EventModel.fromJson(x))),
        nearby: List<EventModel>.from(
            json["nearby"].map((x) => EventModel.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "featured": List<EventModel>.from(featured.map((x) => x.toJson())),
        "trending": List<EventModel>.from(trending.map((x) => x.toJson())),
        "nearby": List<EventModel>.from(nearby.map((x) => x.toJson())),
      };
}
