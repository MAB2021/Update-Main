import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/bookmark/routes/route.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/modules/home/models/home_model.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/modules/home/widgets/feature/feature_widget.dart';
import 'package:buzz_map/modules/home/widgets/location_field.dart';
import 'package:buzz_map/modules/home/widgets/search/search_input_text.dart';
import 'package:buzz_map/modules/home/widgets/trending/trending_interest_tab.dart';
import 'package:buzz_map/modules/home/widgets/trending/trending_list.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/modules/notification/routes/route.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/circle_with_bg_color.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomeRootWidget extends StatefulWidget {
  final bool isCurrent;
  const HomeRootWidget({super.key, required this.isCurrent});

  @override
  State<HomeRootWidget> createState() => _HomeRootWidgetState();
}

class _HomeRootWidgetState extends State<HomeRootWidget> {
  User get user => getIt<User>();
  TextEditingController searchController = TextEditingController();
  bool isLoading = false;
  bool isHomeCategoryLoading = false;
  List<CategoryModel> categories = [];
  HomeDataModel? homeDataModel;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      getHomePageData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Offstage(
      offstage: !widget.isCurrent,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: SafeArea(
          top: true,
          child: RefreshIndicator(
            onRefresh: () async {
              getHomePageData();
            },
            child: SingleChildScrollView(
              // padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: BlocConsumer(
                bloc: getIt<HomeCubit>(),
                listener: (context, state) {
                  if (state is GetCategoriesLoading) {
                    isHomeCategoryLoading = true;
                  } else if (state is GetCategoriesSuccess) {
                    isHomeCategoryLoading = false;
                    categories = state.categories;
                    categoryName.value = "all";
                    getIt<HomeCubit>().getHomeEvents(categoryName: "all");
                  } else if (state is GetCategoriesFailed) {
                    isHomeCategoryLoading = false;
                    NotificationMessage.showMessage(context,
                        message: state.errorMessage, isError: true);
                  } else if (state is GettingHomeData) {
                    isLoading = true;
                  } else if (state is GetHomeDataSuccess &&
                      state.categoryName == categoryName.value) {
                    homeDataModel = state.homeDataModel;
                    isLoading = false;
                  } else if (state is GetHomeDataFailed) {
                    isLoading = false;
                  }
                },
                builder: (context, state) {
                  return Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const LocationWidget(),
                            // Text(
                            //   user.firstName,
                            //   style: GoogleFonts.outfit(
                            //       fontSize: 18.sp,
                            //       color: AppColors.buzzMapWhite,
                            //       fontWeight: FontWeight.w600),
                            // ),
                            const Spacer(),
                            CircleCustomButton(
                                imageUrl: isDarkMode
                                    ? AssetResources.whiteBell
                                    : AssetResources.blackBell,
                                onPressed: () {
                                  getIt<NavigationService>().to(
                                      routeName:
                                          NotificationRoutes.notificationRoot);
                                }),
                            10.w.horizontalSpace,
                            CircleCustomButton(
                                imageUrl: isDarkMode
                                    ? AssetResources.whiteBookmark
                                    : AssetResources.blackBookmark,
                                onPressed: () {
                                  getIt<NavigationService>().to(
                                      routeName: BookmarkRoutes.bookmarkRoot);
                                })
                          ],
                        ),
                      ),
                      24.h.verticalSpace,

                      GestureDetector(
                        onTap: () => getIt<NavigationService>()
                            .to(routeName: HomeRoutes.search),
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20.w),
                          child: const SearchInputText(),
                        ),
                      ),
                      19.h.verticalSpace,
                      FeatureWidget(
                          eventModel: homeDataModel?.featured ?? [],
                          isLoading: homeDataModel?.featured.isEmpty ?? true
                              ? isLoading
                              : false),
                      TrendingListWidget(
                        title: "Trending",
                        isTrending: true,
                        eventModel: homeDataModel?.trending ?? [],
                        isFetching: isLoading,
                        isNearByLocation: false,
                        categories: categories,
                      ),
                      TrendingListWidget(
                        title: "Nearby Your Location",
                        isTrending: false,
                        eventModel: homeDataModel?.nearby ?? [],
                        isFetching: homeDataModel?.nearby.isEmpty ?? true
                            ? isLoading
                            : false,
                        isNearByLocation: true,
                        categories: categories,
                      ),
                      // const TrendingListWidget(
                      //   title: "Newest Event",
                      //   isTrending: false,
                      //   eventModel: homeDataModel.,
                      // ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  getHomePageData() {
    if (userCurrentPosition.value == null) {
      getCurrentPosition();
    } else {
      getIt<HomeCubit>().getCategories();
    }
  }

  Future<void> getCurrentPosition() async {
    Position position = await determinePosition(
        getIt<NavigationService>().navigatorKey.currentContext!);
    getIt<LocationCubit>().findCoordinateAddress(
        LatLng(position.latitude, position.longitude), false);
    userCurrentPosition.value = LatLng(position.latitude, position.longitude);
    getIt<HomeCubit>().getCategories();
  }
}
