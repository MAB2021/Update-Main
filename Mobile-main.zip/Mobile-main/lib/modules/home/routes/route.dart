class HomeRoutes {
  static const String homeRoot = 'home';
  static const String featured = 'featured';
  static const String trending = 'trending';
  static const String search = 'search';
  static const String eventDetail = 'eventDetail';
}
