import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class HomeApiService {
  final HttpService http;

  HomeApiService({required this.http});

  Future<Response> getCategories() async {
    return http.getRequest(AppURL.categories);
  }

  Future<Response> searchForEventsCategories(
      {required String keyword, required int pageNumber}) async {
    return http.getRequest(
      // "${AppURL.events}$category&page=$pageNumber&keyword=$keyword&is_guest=1",
      "events?latitude=${userCurrentPosition.value!.latitude}&longitude=${userCurrentPosition.value!.longitude}&page=$pageNumber&keyword=$keyword&is_guest=1&extend=1",
      // queryParameters: {
      //   "latitude": userCurrentPosition.value!.latitude,
      //   "longitude": userCurrentPosition.value!.longitude,
      //   "keyword": keyword,
      //   "page": pageNumber
      // }
    );
  }

  Future<Response> getEvents(
      {required String category,
      required int pageNumber,
      required bool isNearByLocation,
      required bool isTrending}) async {
    return http.getRequest(AppURL.home, queryParameters: {
      "latitude": userCurrentPosition.value!.latitude,
      "longitude": userCurrentPosition.value!.longitude,
      "is_guest": 0,
      "trendingCategory": isTrending && category == "all" ? "" : category,
      "nearbyCategory":
          isNearByLocation ? (category == "all" ? "" : category) : "",
      "page": pageNumber,
    });
  }

  Future<Response> getHomeEvents({String? category}) async {
    return http.getRequest(AppURL.home, queryParameters: {
      "latitude": userCurrentPosition.value!.latitude,
      "longitude": userCurrentPosition.value!.longitude,
      "is_guest": 0,
      "trendingCategory": category == "all" ? "" : category,
      "nearbyCategory": "",
      "page": 1
    });
  }
}
