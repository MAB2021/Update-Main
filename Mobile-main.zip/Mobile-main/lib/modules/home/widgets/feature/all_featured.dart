import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/home/widgets/feature/feature_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FeaturedScreen extends StatefulWidget {
  final List<EventModel> eventModel;
  const FeaturedScreen({super.key, required this.eventModel});

  @override
  State<FeaturedScreen> createState() => _FeaturedScreenState();
}

class _FeaturedScreenState extends State<FeaturedScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
       backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leadingWidth: 150.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(text: S.current.featured),
        ),
      ),
      body: ListView.separated(
        itemCount: widget.eventModel.length,
        shrinkWrap: true,
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        separatorBuilder: (BuildContext context, int index) {
          return 14.h.verticalSpace;
        },
        itemBuilder: (BuildContext context, int index) {
          return FeatureItemWidget(
            eventModel: widget.eventModel[index],
          );
        },
      ),
    );
  }
}
