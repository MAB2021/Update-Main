import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class FeatureItemWidget extends StatelessWidget {
  final EventModel eventModel;
  const FeatureItemWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        getIt<NavigationService>()
            .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          "eventModel": eventModel,
        });
      },
      child: Container(
        height: 200.h,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
          color: AppColors.inputFiledColor,
        ),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10.r),
              child: ColorFiltered(
                colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.45),
                  BlendMode.srcOver,
                ),
                child: BuzzMapCacheImage(
                  width: double.infinity,
                  height: 200.h,
                  boxFit: BoxFit.cover,
                  showPlaceholder: true,
                  borderRadius: 10.r,
                  memCacheHeight: 1000,
                  memCacheWidth: 1000,
                  imgUrl: eventModel.eventImage,
                  errorWidget: BuzzMapCacheImage(
                      width: 142.w,
                      height: 150.h,
                      boxFit: BoxFit.cover,
                      memCacheHeight: null,
                      memCacheWidth: null,
                      imgUrl:
                          "https://www.bellanaija.com/wp-content/uploads/2013/05/Events.jpg"),
                ),
              ),
            ),
            TitleWidget(
              eventModel: eventModel,
            )
          ],
        ),
      ),
    );
  }
}

class TitleWidget extends StatelessWidget {
  final EventModel eventModel;
  const TitleWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 21.w, right: 21.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            eventModel.eventName,
            style: GoogleFonts.outfit(
              color: Colors.white,
              fontSize: 26.sp,
              fontWeight: FontWeight.w600,
            ),
            maxLines: 2,
          ),
          10.h.verticalSpace,
          // BuzzMapButton(
          //   height: 32.h,
          //   width: 128.w,
          //   borderRadius: 10.r,
          //   child: Text(
          //     S.current.bookNow,
          //     style: GoogleFonts.outfit(
          //       color: Colors.white,
          //       fontSize: 13.sp,
          //       fontWeight: FontWeight.w400,
          //     ),
          //   ),
          //   onPressed: () {
          //     getIt<NavigationService>()
          //         .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          //       "eventModel": eventModel,
          //     });
          //   },
          // ),
          10.h.verticalSpace,
        ],
      ),
    );
  }
}
