import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/modules/home/widgets/feature/feature_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/widgets/shimmer.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class FeatureWidget extends StatefulWidget {
  final List<EventModel> eventModel;
  final bool isLoading;
  const FeatureWidget(
      {super.key, required this.eventModel, required this.isLoading});

  @override
  State<FeatureWidget> createState() => _FeatureWidgetState();
}

class _FeatureWidgetState extends State<FeatureWidget> {
  int currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: () => getIt<NavigationService>().toWithParameters(
            routeName: HomeRoutes.featured,
            args: {
              "eventModel": widget.eventModel,
            },
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  S.current.featured,
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                // Text(
                //   S.current.seeAll,
                //   style: Theme.of(context).textTheme.titleMedium!.copyWith(
                //         fontSize: 14.sp,
                //         fontWeight: FontWeight.w700,
                //       ),
                // )
              ],
            ),
          ),
        ),
        10.h.verticalSpace,
        widget.isLoading || widget.eventModel.isEmpty
            ? Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: ShimmerWidget.rectangle(
                  height: 200.h,
                  width: double.infinity,
                  borderRadius: 10.4,
                ),
              )
            : CarouselSlider.builder(
                options: CarouselOptions(
                  height: 200.h,
                  aspectRatio: 16 / 9,
                  viewportFraction: 1,
                  autoPlay: true,
                  padEnds: true,
                  onPageChanged: (index, reason) {
                    setState(() {
                      currentIndex = index;
                    });
                  },
                ),
                itemCount: widget.eventModel.length,
                itemBuilder: (context, index, realIndex) {
                  EventModel eventModel = widget.eventModel[index];
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: FeatureItemWidget(
                      eventModel: eventModel,
                    ),
                  );
                },
              )
      ],
    );
  }
}
