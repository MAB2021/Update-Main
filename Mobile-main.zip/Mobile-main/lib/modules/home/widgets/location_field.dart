import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/location/routes/route.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class LocationWidget extends StatelessWidget {
  const LocationWidget({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return ValueListenableBuilder(
        valueListenable: userCurrentAddress,
        builder: (context, value, child) {
          return GestureDetector(
            onTap: () => getIt<NavigationService>()
                .to(routeName: LocationRoutes.searchLocation),
            child: Row(
              children: [
                BuzzMapAssetImage(
                    url: isDarkMode
                        ? AssetResources.location
                        : AssetResources.darkLocation,
                    width: 24.w,
                    height: 24.h),
                5.w.horizontalSpace,
                ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: 130.w,
                  ),
                  child: Text(
                    value ?? 'Location',
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontSize: 18.sp,
                        ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                BuzzMapAssetImage(
                    url: !isDarkMode
                        ? AssetResources.editIcon
                        : AssetResources.darkEditIcon,
                    width: 24.w,
                    height: 24.h),
              ],
            ),
          );
        });
  }
}
