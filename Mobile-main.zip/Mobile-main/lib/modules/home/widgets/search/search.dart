import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/modules/home/widgets/search/search_input_text.dart';
import 'package:buzz_map/modules/home/widgets/search/search_item.dart';
import 'package:buzz_map/modules/home/widgets/shimmer/trending_item_shimmer.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/widgets/lottie_loader.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/empty_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen>
    with TickerProviderStateMixin {
  late TabController tabController;
  final ScrollController _scrollController = ScrollController();
  TextEditingController searchController = TextEditingController();
  List<CategoryModel> categories = getIt<List<CategoryModel>>();
  List<EventModel> searchResultEvents = [];
  bool isLoading = false;
  String searchQuery = "";
  int pageNumber = 1;
  bool isLoadingMore = false;
  @override
  void initState() {
    // _scrollController.addListener(_scrollListener);
    super.initState();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      // User has scrolled to the end of the list
      loadMoreEvents();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        centerTitle: false,
        leadingWidth: 200.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(text: S.current.search),
        ),
      ),
      body: BlocConsumer(
        bloc: getIt<HomeCubit>(),
        listener: (context, state) {
          if (state is SearchEventsLoading) {
            isLoading = true;
          } else if (state is SearchEventsSuccess) {
            isLoading = false;
            searchResultEvents = state.events;
            // if (pageNumber == 1) {
            //   searchResultEvents = state.events;
            // } else {
            //   searchResultEvents.addAll(state.events);
            // }

            // setState(() {
            //   pageNumber++;
            //   isLoadingMore = false;
            // });
          } else if (state is SearchEventsFailed) {
            isLoading = false;
            isLoadingMore = false;
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  SearchInputText(
                    searchController: searchController,
                    isEnabled: true,
                  ),
                  30.h.verticalSpace,
                  Row(
                    children: [
                      Text(
                        S.current.searchResults,
                        style: GoogleFonts.outfit(
                            fontSize: 16.sp,
                            color: isDarkMode
                                ? AppColors.buzzMapWhite
                                : AppColors.primaryColor,
                            fontWeight: FontWeight.w600),
                      ),
                      const Spacer(),
                      Text(
                        S.current.found(searchResultEvents.isEmpty
                            ? 0
                            : searchResultEvents.length),
                        style: GoogleFonts.outfit(
                            fontSize: 14.sp,
                            color: isDarkMode
                                ? AppColors.buzzMapWhite
                                : AppColors.primaryColor,
                            fontWeight: FontWeight.w700),
                      )
                    ],
                  ),
                  isLoading && !isLoadingMore
                      ? const TrendingItemShimmer()
                      : searchResultEvents.isEmpty
                          ? EmptyStateWidget(
                              imageUrl: AssetResources.noEvents,
                              title: S.current.noResultsFound,
                              subTitle: S.current.pleaseTryAnotherKeyword)
                          : ListView.separated(
                              itemCount: searchResultEvents.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              padding: EdgeInsets.only(top: 23.h, bottom: 40.h),
                              separatorBuilder:
                                  (BuildContext context, int index) {
                                return 15.h.verticalSpace;
                              },
                              itemBuilder: (BuildContext context, int index) {
                                EventModel eventModel =
                                    searchResultEvents[index];
                                return SearchResultItemWidget(
                                  eventModel: eventModel,
                                  index: index,
                                );
                              },
                            ),
                  isLoadingMore
                      ? const LottieLoader()
                      : const SizedBox.shrink(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  searchEvents() {
    getIt<HomeCubit>().searchEvents(
        keyword: searchController.text.trim(), pageNumber: pageNumber);
  }

  loadMoreEvents() {
    getIt<HomeCubit>().searchEvents(
        keyword: searchController.text.trim(), pageNumber: pageNumber);
    setState(() {
      isLoadingMore = true;
    });
  }
}
