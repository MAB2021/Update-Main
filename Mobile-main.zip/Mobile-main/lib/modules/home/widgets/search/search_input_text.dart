import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/debouncer.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SearchInputText extends StatefulWidget {
  final TextEditingController? searchController;
  final bool isEnabled;
  final int pageNumber = 1;
  const SearchInputText({
    super.key,
    this.searchController,
    this.isEnabled = false,
  });

  @override
  State<SearchInputText> createState() => _SearchInputTextState();
}

class _SearchInputTextState extends State<SearchInputText> {
  Debouncer debounce = Debouncer(duration: const Duration(milliseconds: 500));
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return InputText(
      enabled: widget.isEnabled,
      isFilled: true,
      isHomepageSearch: true,
      controller: widget.searchController,
      onChanged: (value) {
        debounce.run(() {
          if (value.isNotEmpty) {
            getIt<HomeCubit>()
                .searchEvents(keyword: value, pageNumber: widget.pageNumber);
          }
        });
        setState(() {});
      },
      onEditingComplete: () {
        if (widget.searchController!.text.isNotEmpty) {
          getIt<HomeCubit>().searchEvents(
              keyword: widget.searchController!.text,
              pageNumber: widget.pageNumber);
        }
      },
      textPlaceholder: S.current.search, // S.current.searchIn(categoryName),
      inputBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6.r),
        borderSide: BorderSide.none,
      ),
      prefixWidget: Padding(
        padding: EdgeInsets.only(left: 14.w, right: 16.w),
        child: BuzzMapAssetImage(
            url: isDarkMode ? AssetResources.search : AssetResources.darkSearch,
            width: 24.w,
            height: 24.w),
      ),
      textInputAction: TextInputAction.search,
    
    );
  }
}
