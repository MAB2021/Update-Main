import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/bookmark/widgets/bookmark_item.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/events/bookmark.dart';
import 'package:buzz_map/shared/widgets/events/event_category_tag.dart';
import 'package:buzz_map/shared/widgets/events/event_location.dart';
import 'package:buzz_map/shared/widgets/events/network_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SearchResultItemWidget extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const SearchResultItemWidget(
      {super.key, required this.eventModel, required this.index});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return InkWell(
      onTap: () {
        getIt<NavigationService>()
            .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          "eventModel": eventModel,
        });
      },
      child: Container(
        // height: 316.01.h,
        width: double.infinity,
        decoration: BoxDecoration(
            color:
                isDarkMode ? AppColors.primaryColor : AppColors.buzzMapWhite),
        child: Column(
          // alignment: Alignment.topCenter,
          children: [
            EventDateAndBackgroundWidget(
              eventModel: eventModel,
            ),
            EventWidget(
              eventModel: eventModel,
              index: index,
            ),
          ],
        ),
      ),
    );
  }
}

class EventWidget extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const EventWidget({super.key, required this.eventModel, required this.index});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 18.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          10.h.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 180.w,
                child: Text(
                  eventModel.eventName,
                  style: Theme.of(context).textTheme.displayMedium,
                  maxLines: 2,
                ),
              ),
              if (eventModel.heatMap != null)
                Align(
                  alignment: Alignment.centerRight,
                  child: NetworkSignalIndicator(
                      signalStrength: eventModel.heatMap!),
                ),
            ],
          ),
          10.h.verticalSpace,
          EventCategoryTagWidget(
            name: eventModel.eventCategory,
          ),
          14.h.verticalSpace,
          EventLocation(
            eventModel: eventModel,
            index: index,
          ),
          10.h.verticalSpace,
        ],
      ),
    );
  }
}

class EventLocation extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const EventLocation({
    super.key,
    required this.eventModel,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        EventAddressWidget(
          address: eventModel.eventAddress,
        ),
        AddAndRemoveBookmarkWidget(
            eventModel: eventModel,
            index: index,
            widgetIdentifier: "searchEvent"),
      ],
    );
  }
}
