import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/modules/home/widgets/shimmer/trending_item_shimmer.dart';
import 'package:buzz_map/modules/home/widgets/trending/all_trending/all_trending_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/empty_state.dart';
import 'package:buzz_map/shared/widgets/lottie_loader.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AllTrendingScreen extends StatefulWidget {
  final bool isNearByLocation;
  const AllTrendingScreen({super.key, this.isNearByLocation = false});

  @override
  State<AllTrendingScreen> createState() => _AllTrendingScreenState();
}

class _AllTrendingScreenState extends State<AllTrendingScreen>
    with TickerProviderStateMixin {
  late TabController tabController;
  late HomeCubit homeCubit;
  List<CategoryModel> categories = [
    CategoryModel(
        id: 1, categoryName: "All", icon: "all", slug: "all", isActive: true),
  ];
  final ScrollController _scrollController = ScrollController();
  List<EventModel> events = [];
  bool isLoading = false;
  bool isLoadingEvents = false;
  bool isLoadingMore = false;
  int pageNumber = 1;
  String categoryName = "all";

  @override
  void initState() {
    homeCubit = getIt<HomeCubit>();
    categories.addAll(
      getIt<List<CategoryModel>>(),
    );
    tabController = TabController(length: categories.length, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      getEvents();
    });
    _scrollController.addListener(_scrollListener);
    super.initState();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      // User has scrolled to the end of the list
      loadMoreEvents();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leadingWidth: 250.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(
              text: widget.isNearByLocation
                  ? S.current.nearByYourLocation
                  : S.current.trending),
        ),
      ),
      body: SafeArea(
        top: true,
        bottom: false,
        child: RefreshIndicator(
          onRefresh: () async {
            events.clear();
            getEvents();
          },
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            controller: _scrollController,
            child: Column(
              children: [
                TabBar(
                    controller: tabController,
                    isScrollable: true,
                    padding: EdgeInsets.only(top: 24.w, left: 10.w, right: 0.w),
                    enableFeedback: false,
                    splashBorderRadius: BorderRadius.zero,
                    onTap: (value) {
                      FocusScope.of(context).requestFocus(FocusNode());
                      // get data based on business type
                      events.clear();
                      categoryName = categories[value].slug == "all"
                          ? "all"
                          : categories[value].categoryName;
                      getEvents();
                    },
                    tabs: categories
                        .map(
                          (e) => Tab(text: e.categoryName),
                        )
                        .toList(),
                    tabAlignment: TabAlignment.start),
                // const TrendingInterestTabWidget(),
                BlocConsumer(
                  bloc: homeCubit,
                  listener: (context, state) {
                    if (state is GetEventsLoading) {
                      isLoadingEvents = true;
                    } else if (state is GetEventsSuccess &&
                        state.categoryName == categoryName) {
                      isLoadingEvents = false;
                      events.addAll(state.events);
                      setState(() {
                        pageNumber++;
                        isLoadingMore = false;
                      });
                    } else if (state is GetEventsFailed) {
                      isLoadingEvents = false;
                      isLoadingMore = false;
                      NotificationMessage.showMessage(context,
                          message: state.errorMessage, isError: true);
                    }
                  },
                  builder: (context, state) {
                    return isLoadingEvents && !isLoadingMore
                        ? const TrendingItemShimmer()
                        : events.isEmpty
                            ? EmptyStateWidget(
                                imageUrl: AssetResources.sad,
                                title: S.current.youHaveNoEvents)
                            : ListView.separated(
                                itemCount: events.length,
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                padding:
                                    EdgeInsets.only(top: 23.h, bottom: 40.h),
                                separatorBuilder:
                                    (BuildContext context, int index) {
                                  return 15.h.verticalSpace;
                                },
                                itemBuilder: (BuildContext context, int index) {
                                  EventModel eventModel = events[index];
                                  return AllTrendingItem(
                                    model: eventModel,
                                    index: index,
                                  );
                                },
                              );
                  },
                ),
                isLoadingMore ? const LottieLoader() : const SizedBox.shrink(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  loadMoreEvents() {
    homeCubit.getEvents(
        category: categoryName,
        pageNumber: pageNumber,
        isNearByLocation: widget.isNearByLocation,
        isTrending: !widget.isNearByLocation);
    setState(() {
      isLoadingMore = true;
    });
  }

  getEvents() {
    homeCubit.getEvents(
        category: categoryName,
        pageNumber: 1,
        isNearByLocation: widget.isNearByLocation,
        isTrending: !widget.isNearByLocation);
  }
}
