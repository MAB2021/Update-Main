import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/events/bookmark.dart';
import 'package:buzz_map/shared/widgets/events/event_category_tag.dart';
import 'package:buzz_map/shared/widgets/events/event_date.dart';
import 'package:buzz_map/shared/widgets/events/event_location.dart';
import 'package:buzz_map/shared/widgets/events/network_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AllTrendingItem extends StatelessWidget {
  final EventModel model;
  final int index;
  const AllTrendingItem({super.key, required this.model, required this.index});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return GestureDetector(
      onTap: () {
        getIt<NavigationService>()
            .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          "eventModel": model,
        });
      },
      child: Container(
        height: 150.h,
        width: double.infinity,
        decoration: BoxDecoration(
          color: isDarkMode
              ? AppColors.primaryColor
              : AppColors.buzzMapGrayLight[90],
          borderRadius: BorderRadius.circular(10.r),
        ),
        child: Row(
          children: [
            EventDateAndBackgroundWidget(
              model: model,
            ),
            8.w.horizontalSpace,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                10.h.verticalSpace,
                SizedBox(
                  width: 170.w,
                  child: Text(
                    model.eventName,
                    maxLines: 2,
                    style: Theme.of(context).textTheme.displayMedium!.copyWith(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ),
                5.h.verticalSpace,
                SizedBox(
                  width: 170.w,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      EventCategoryTagWidget(name: model.eventCategory),
                      if (model.heatMap != null)
                        NetworkSignalIndicator(signalStrength: model.heatMap!),
                    ],
                  ),
                ),
                22.h.verticalSpace,
                EventLocation(
                  name: model.eventAddress,
                  eventModel: model,
                  index: index,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class EventDateAndBackgroundWidget extends StatelessWidget {
  final EventModel model;
  const EventDateAndBackgroundWidget({super.key, required this.model});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(10.r),
        bottomLeft: Radius.circular(10.r),
      ),
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          BuzzMapCacheImage(
            width: 142.w,
            height: 150.h,
            boxFit: BoxFit.cover,
            memCacheHeight: null,
            memCacheWidth: null,
            imgUrl: model.eventImage,
            errorWidget: BuzzMapCacheImage(
                width: 142.w,
                height: 150.h,
                boxFit: BoxFit.cover,
                memCacheHeight: null,
                memCacheWidth: null,
                imgUrl:
                    "https://www.bellanaija.com/wp-content/uploads/2013/05/Events.jpg"),
          ),
          EventDateWidget(
            date: formatStringDate(model.eventStartDate.toString()),
          ),
        ],
      ),
    );
  }
}

class EventLocation extends StatelessWidget {
  final String name;
  final EventModel eventModel;
  final int index;
  const EventLocation({
    super.key,
    required this.name,
    required this.eventModel,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 170.w,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          EventAddressWidget(
            address: eventModel.eventAddress,
          ),
          const Spacer(),
          AddAndRemoveBookmarkWidget(
            eventModel: eventModel,
            index: index,
            widgetIdentifier: "allTrending",
          )
        ],
      ),
    );
  }
}
