import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

ValueNotifier<String> categoryName = ValueNotifier<String>("all");

class TrendingInterestTabWidget extends StatefulWidget {
  const TrendingInterestTabWidget({super.key});

  @override
  State<TrendingInterestTabWidget> createState() =>
      _TrendingInterestTabWidgetState();
}

class _TrendingInterestTabWidgetState extends State<TrendingInterestTabWidget>
    with TickerProviderStateMixin {
  List<CategoryModel> categories = [
    CategoryModel(
        id: 1, categoryName: "All", icon: "all", slug: "all", isActive: true),
  ];
  late TabController tabController;

  @override
  void initState() {
    categories.addAll(
      getIt<List<CategoryModel>>(),
    );
    tabController = TabController(length: categories.length, vsync: this);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return TabBar(
      controller: tabController,
      isScrollable: true,
      padding: EdgeInsets.only(top: 24.w, left: 10.w, right: 0.w),
      enableFeedback: false,
      splashBorderRadius: BorderRadius.zero,
      onTap: (value) {
        FocusScope.of(context).requestFocus(FocusNode());
        categoryName.value = categories[value].slug == "all"
            ? "all"
            : categories[value].categoryName;
        getIt<HomeCubit>().getHomeEvents(
          categoryName: categories[value].slug == "all"
              ? "all"
              : categories[value].categoryName,
        );
      },
      tabs: categories
          .map(
            (e) => Tab(text: e.categoryName),
          )
          .toList(),
    );
  }
}
