import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/events/bookmark.dart';
import 'package:buzz_map/shared/widgets/events/event_date.dart';
import 'package:buzz_map/shared/widgets/events/event_location.dart';
import 'package:buzz_map/shared/widgets/events/network_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TrendingItemWidget extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const TrendingItemWidget(
      {super.key, required this.eventModel, required this.index});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return GestureDetector(
      onTap: () {
        getIt<NavigationService>()
            .toWithParameters(routeName: HomeRoutes.eventDetail, args: {
          "eventModel": eventModel,
        });
      },
      child: Container(
        width: 198.w,
        decoration: BoxDecoration(
            border: Border.all(
              color: isDarkMode ? Colors.white.withOpacity(0.10) : Colors.white,
              width: 1.w,
            ),
            color: isDarkMode
                ? AppColors.primaryColor
                : AppColors.buzzMapGrayLight[90]),
        child: Column(
          children: [
            EventDateAndBackgroundWidget(
              eventModel: eventModel,
            ),
            EventWidget(
              eventModel: eventModel,
              index: index,
            ),
          ],
        ),
      ),
    );
  }
}

class EventDateAndBackgroundWidget extends StatelessWidget {
  final EventModel eventModel;
  const EventDateAndBackgroundWidget({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.topRight,
      children: [
        BuzzMapCacheImage(
          width: double.infinity,
          height: 132.h,
          boxFit: BoxFit.fill,
          memCacheHeight: 800,
          memCacheWidth: 800,
          // borderRadius: 10.r,
          imgUrl: eventModel.eventImage,
          errorWidget: BuzzMapCacheImage(
              width: 142.w,
              height: 150.h,
              boxFit: BoxFit.cover,
              memCacheHeight: null,
              memCacheWidth: null,
              imgUrl:
                  "https://www.bellanaija.com/wp-content/uploads/2013/05/Events.jpg"),
        ),
        EventDateWidget(
          date: formatStringDate(eventModel.eventStartDate.toString()),
        ),
      ],
    );
  }
}

class EventWidget extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const EventWidget({super.key, required this.eventModel, required this.index});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 6.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          10.h.verticalSpace,
          if (eventModel.heatMap != null)
            NetworkSignalIndicator(signalStrength: eventModel.heatMap!),
          // Visibility(
          //   visible: eventModel.heatMap != null,
          //   child:  NetworkSignalIndicator(signalStrength: 3),
          //   // EventHeatmapWidget(
          //   //   eventModel: eventModel,
          //   // ),
          // ),
          11.h.verticalSpace,
          Text(eventModel.eventName,
              style: Theme.of(context).textTheme.displayMedium, maxLines: 2),
          10.h.verticalSpace,
          14.h.verticalSpace,
          EventLocation(
            eventModel: eventModel,
            index: index,
          ),
          10.h.verticalSpace,
        ],
      ),
    );
  }
}

class EventLocation extends StatelessWidget {
  final EventModel eventModel;
  final int index;
  const EventLocation({
    super.key,
    required this.eventModel,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        EventAddressWidget(
          address: eventModel.eventAddress,
        ),
        AddAndRemoveBookmarkWidget(
            eventModel: eventModel, index: index, widgetIdentifier: "home"),
      ],
    );
  }
}
