import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/modules/home/widgets/trending/trending_interest_tab.dart';
import 'package:buzz_map/modules/home/widgets/trending/trending_item.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/widgets/shimmer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TrendingListWidget extends StatefulWidget {
  final String title;
  final bool isTrending;
  final bool isFetching;
  final bool isNearByLocation;
  final List<EventModel> eventModel;
  final List<CategoryModel> categories;

  const TrendingListWidget(
      {super.key,
      required this.title,
      required this.isTrending,
      required this.eventModel,
      required this.isFetching,
      this.isNearByLocation = false,
      required this.categories});

  @override
  State<TrendingListWidget> createState() => _TrendingListWidgetState();
}

class _TrendingListWidgetState extends State<TrendingListWidget> {
  List<EventModel> events = [];
  bool isLoading = false;
  bool isLoadingEvents = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        24.h.verticalSpace,
        InkWell(
          onTap: () {
            getIt<NavigationService>().toWithParameters(
                routeName: HomeRoutes.trending,
                args: {'isNearByLocation': widget.isNearByLocation});
          },
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  widget.title,
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  S.current.seeAll,
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w700,
                      ),
                )
              ],
            ),
          ),
        ),
        Visibility(
          visible: widget.isTrending && widget.categories.isNotEmpty,
          child: const TrendingInterestTabWidget(),
        ),
        24.h.verticalSpace,
        widget.isFetching || widget.eventModel.isEmpty
            ? SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    4,
                    (index) => Padding(
                      padding: EdgeInsets.only(
                          right: 16.w, left: index == 0 ? 20.w : 0.w),
                      child: ShimmerWidget.rectangle(
                        height: 209.h,
                        width: 190.w,
                        borderRadius: 16.r,
                      ),
                    ),
                  ),
                ),
              )
            : SizedBox(
                height: 300.h,
                child: ListView.builder(
                  itemCount: widget.eventModel.length,
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: EdgeInsets.only(
                          right: 16.w, left: index == 0 ? 20.w : 0.w),
                      child: TrendingItemWidget(
                        eventModel: widget.eventModel[index],
                        index: index,
                      ),
                    );
                  },
                ),
              ),
      ],
    );
  }
}
