'`r Sys.Date()`'

- TODO: Created the initial setup of the Interest feature/module
