import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/home/cubit/home_cubit.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

part 'interest_state.dart';

class InterestCubit extends Cubit<InterestState> {
  final InterestApiService apiService;

  InterestCubit({required this.apiService}) : super(InterestInitial());

  void getCategories() async {
    emit(GetCategoriesLoading());
    try {
      final response = await apiService.getCategories();
      if (response.isSuccessful && response.data['status'] == 200) {
        List<CategoryModel> categories = [];
        response.data['data']['categories'].forEach((category) {
          categories.add(CategoryModel.fromJson(category));
        });
        emit(GetCategoriesSuccess(categories: categories));
      } else {
        emit(GetCategoriesFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetCategoriesFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetCategoriesFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void addInterest({required UpdateProfileModel updateProfileModel}) async {
    emit(AddingInterest());
    try {
      final response = await apiService.updateInterest(
          updateProfileModel: updateProfileModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        User userModel = getIt<User>();
        getIt<LocalStorageUtils>()
            .saveObject<User>(AppConstants.userObject, userModel);
        getIt.registerSingleton<User>(userModel);
        getCurrentPosition();
        emit(AddInterestSuccess());
      } else {
        emit(AddInterestFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(AddInterestFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(AddInterestFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  Future<void> getCurrentPosition() async {
    Position position = await determinePosition(
        getIt<NavigationService>().navigatorKey.currentContext!);
    getIt<LocationCubit>().findCoordinateAddress(
        LatLng(position.latitude, position.longitude), true);
    userCurrentPosition.value = LatLng(position.latitude, position.longitude);
    getIt<HomeCubit>().getCategories();
    getIt<EventsCubit>().getEvents(pageNumber: 1);
  }
}
