part of 'interest_cubit.dart';

@immutable
abstract class InterestState {}

class InterestInitial extends InterestState {}

class GetCategoriesLoading extends InterestState {}

class GetCategoriesSuccess extends InterestState {
  final List<CategoryModel> categories;

  GetCategoriesSuccess({required this.categories});
}

class GetCategoriesFailed extends InterestState {
  final String errorMessage;

  GetCategoriesFailed({required this.errorMessage});
}

class AddingInterest extends InterestState {}

class AddInterestSuccess extends InterestState {
  AddInterestSuccess();
}

class AddInterestFailed extends InterestState {
  final String errorMessage;

  AddInterestFailed({required this.errorMessage});
}
