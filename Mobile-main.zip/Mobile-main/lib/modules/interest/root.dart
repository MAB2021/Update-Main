import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:buzz_map/modules/interest/cubit/interest_cubit.dart';
import 'package:buzz_map/modules/interest/widgets/interest/interest_group.dart';
import 'package:buzz_map/modules/interest/widgets/interest/shimmer/interest_group_shimmer.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class InterestScreen extends StatefulWidget {
  const InterestScreen({super.key});

  @override
  State<InterestScreen> createState() => _InterestScreenState();
}

class _InterestScreenState extends State<InterestScreen> {
  List<CategoryModel> categories = [];
  List<CategoryModel> selectedInterests = [];
  bool isLoadingCategories = true;

  @override
  void initState() {
    getIt<InterestCubit>().getCategories();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<InterestCubit>(),
        listener: (context, state) {
          if (state is GetCategoriesLoading) {
            isLoadingCategories = true;
          } else if (state is GetCategoriesSuccess) {
            isLoadingCategories = false;
            categories = state.categories;
          } else if (state is GetCategoriesFailed) {
            isLoadingCategories = false;
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          } else if (state is AddingInterest) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is AddInterestSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            getIt<NavigationService>().to(routeName: RootRoutes.home);
            // getIt<NavigationService>()
            //     .to(routeName: LocationRoutes.selectLocation);
          } else if (state is AddInterestFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            bottom: false,
            child: RefreshIndicator(
              onRefresh: () async {
                getIt<InterestCubit>().getCategories();
              },
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        // const CustomBackButton(),
                        Text(S.current.selectYourInterest,
                            style: Theme.of(context).textTheme.bodyLarge),
                      ],
                    ),
                    44.h.verticalSpace,
                    Container(
                      child: isLoadingCategories
                          ? const InterestGroupShimmer()
                          : InterestGroup(
                              categories: categories,
                              onSelected: (category) {
                                if (selectedInterests.contains(category)) {
                                  selectedInterests.remove(category);
                                } else {
                                  selectedInterests.add(category);
                                }

                                setState(() {});
                              },
                            ),
                    ),
                    24.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: selectedInterests.isNotEmpty
                          ? () {
                              debugPrint(
                                selectedInterests
                                    .map((e) => e.categoryName)
                                    .toList()
                                    .toString(),
                              );
                              getIt<InterestCubit>().addInterest(
                                updateProfileModel: UpdateProfileModel(
                                    interests: selectedInterests
                                        .map((e) => e.id)
                                        .toList(),
                                    generalNotification: false,
                                    sound: false,
                                    appUpdates: true),
                              );
                            }
                          : null,
                      textColor: Colors.white,
                      child: Text(
                        S.current.next,
                        style: GoogleFonts.outfit(
                          color: Colors.white,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    24.h.verticalSpace,
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
