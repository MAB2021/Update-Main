class InterestRoutes{
    static const String interestRoot = 'interest';
}