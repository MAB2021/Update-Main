import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class InterestApiService {
  final HttpService http;

  InterestApiService({required this.http});

  Future<Response> getCategories() async {
    return http.getRequest(AppURL.categories);
  }

  Future<Response> updateInterest(
      {required UpdateProfileModel updateProfileModel}) async {
    return http.post(AppURL.updateProfile, data: updateProfileModel.toJson());
  }
}
