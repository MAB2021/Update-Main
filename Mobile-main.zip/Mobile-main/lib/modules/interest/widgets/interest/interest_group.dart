import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/modules/interest/widgets/interest/interest_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class InterestGroup extends StatefulWidget {
  final List<CategoryModel> categories;
  final Function(CategoryModel) onSelected;

  const InterestGroup(
      {super.key, required this.categories, required this.onSelected});

  @override
  State<InterestGroup> createState() => _InterestGroupState();
}

class _InterestGroupState extends State<InterestGroup> {
  List<CategoryModel> selectedCategories = [];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 24.w,
          crossAxisSpacing: 17.5.w,
          childAspectRatio: 1,
        ),
        itemCount: widget.categories.length,
        itemBuilder: (_, int index) {
          bool isSelected =
              selectedCategories.contains(widget.categories[index]);
          return GestureDetector(
            onTap: () {
              if (isSelected) {
                selectedCategories.remove(widget.categories[index]);
              } else {
                selectedCategories.add(widget.categories[index]);
              }
              widget.onSelected(widget.categories[index]);
              setState(() {});
            },
            child: InterestItem(
              categoryModel: widget.categories[index],
              isSelected: isSelected,
            ),
          );
        });
  }
}
