import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class InterestItem extends StatefulWidget {
  final CategoryModel categoryModel;
  final bool isSelected;

  const InterestItem(
      {super.key, required this.categoryModel, required this.isSelected});

  @override
  State<InterestItem> createState() => _InterestItemState();
}

class _InterestItemState extends State<InterestItem> {
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Container(
      height: 150.h,
      width: 150.w,
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: widget.isSelected
            ? Theme.of(context).primaryColorDark
            : !isDarkMode
                ? AppColors.lightInputFiledColor
                : Colors.white,
        borderRadius: BorderRadius.circular(20.r),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          BuzzMapCacheImage(
            imgUrl: widget.categoryModel.icon,
            height: 50.h,
            width: 50.w,
            color: widget.isSelected
                ? Colors.white
                : Theme.of(context).primaryColorDark,
            memCacheHeight: 800,
            memCacheWidth: 800,
          ),
          22.h.verticalSpace,
          Text(
            widget.categoryModel.categoryName,
            style: Theme.of(context).textTheme.titleMedium!.copyWith(
                  fontWeight: FontWeight.w600,
                  color: isDarkMode && widget.isSelected
                      ? Colors.white
                      : isDarkMode && !widget.isSelected
                          ? AppColors.primaryColor
                          : !isDarkMode && !widget.isSelected
                              ? AppColors.primaryColor
                              : Colors.white,
                ),
          ),
        ],
      ),
    );
  }
}
