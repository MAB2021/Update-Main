import 'package:buzz_map/shared/widgets/shimmer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class InterestGroupShimmer extends StatelessWidget {
  const InterestGroupShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 24.w,
          crossAxisSpacing: 17.5.w,
          childAspectRatio: 1,
        ),
        itemCount: 6,
        itemBuilder: (_, int index) {
          return ShimmerWidget.rectangle(
            height: 150.h,
            width: 150.w,
            borderRadius: 20.r,
          );
        });
  }
}
