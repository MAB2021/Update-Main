import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:dio/dio.dart';
import 'package:equatable/equatable.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/location/models/address_model.dart';
import 'package:buzz_map/modules/location/models/place_coordinate.dart';
import 'package:buzz_map/modules/location/models/prediction.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/models/geo_location.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/api_service.dart';

part 'location_state.dart';

class LocationCubit extends Cubit<LocationState> {
  final LocationApiService apiService;

  LocationCubit({required this.apiService}) : super(LocationInitial());
  Future<AddressBook?> findCoordinateAddress(
      LatLng latLng, bool isFromInterestScreen) async {
    try {
      emit(FetchingCoordinateAddress());
      var res = await apiService.getFormattedAddress(latLng);
      if (res.isSuccessful) {
        var data = res.data;
        if (data["status"] == "OK") {
          var results = data["results"] as List;
          var coordObject = results[0];

          PlaceCoordinate placeCoordinate =
              PlaceCoordinate.fromJson(coordObject);
          // UserAddress Business Logic
          AddressBook userAddress = AddressBook();
          userAddress.address = formatAddress(placeCoordinate.formattedAddress);
          userCurrentAddress.value = userAddress.address;
          userCurrentPosition.value = latLng;
          userCurrentCountry.value = placeCoordinate.addressComponents
              .firstWhere((element) => element.types.contains("country"))
              .shortName;
          assignAddressValue(
              userAddress: userAddress, placeCoordinate: placeCoordinate);
          if (isFromInterestScreen) {
            updateLocation(
              address: userCurrentAddress.value!,
              geoLocation: GeoLocation(
                latitude: userCurrentPosition.value!.latitude,
                longitude: userCurrentPosition.value!.longitude,
              ),
            );
          }

          emit(FetchedCoordinateAddress(userAddress));
          return userAddress;
        }
      }
    } catch (ex) {
      debugPrint(ex.toString());
    }
    return null;
  }

  Future<PlaceCoordinate?> getCoordinate(String address) async {
    emit(FetchingCoordinate());
    try {
      var res = await apiService.getCoordinate(address);
      if (res.isSuccessful) {
        var data = res.data;
        if (data["status"] == "OK") {
          var results = data["results"] as List;
          var coordObject = results[0];

          PlaceCoordinate placeCoordinate =
              PlaceCoordinate.fromJson(coordObject);
          // UserAddress Business Logic
          AddressBook userAddress = AddressBook();
          userCurrentCountry.value = placeCoordinate.addressComponents
              .firstWhere((element) => element.types.contains("country"))
              .shortName;
          String? cityName = placeCoordinate.addressComponents
              .firstWhereOrNull((element) =>
                  element.types.contains("neighborhood") ||
                  element.types.contains("administrative_area_level_2") ||
                  element.types.contains("locality"))
              ?.longName;

          assignAddressValue(
              userAddress: userAddress, placeCoordinate: placeCoordinate);

          emit(FetchedCoordinate(
              coordinate: placeCoordinate,
              addressBook: userAddress,
              cityName: cityName));

          return placeCoordinate;
        }
      }
    } catch (ex) {
      debugPrint(ex.toString());
    }

    return null;
  }

  Future<List<Prediction>?> fetchPlaces(String placeName) async {
    emit(FetchingPlaces());

    try {
      var res = await apiService.getPlace(placeName);
      if (res.isSuccessful) {
        var data = res.data;
        if (data["status"] == "OK") {
          var predictions = data["predictions"] as List;
          List<Prediction> placePredictions =
              predictions.map((e) => Prediction.fromJson(e)).toList();

          emit(FetchedPlaces(predictions: placePredictions));
          return placePredictions;
        }
      } else {
        debugPrint("failed");
        return null;
      }
    } catch (ex) {
      debugPrint(ex.toString());
    }
    return null;
  }

  void assignAddressValue(
      {required AddressBook userAddress,
      required PlaceCoordinate placeCoordinate}) {
    userAddress.location = GeoLocation(
        longitude: placeCoordinate.latLng.longitude,
        latitude: placeCoordinate.latLng.latitude);
    userAddress.address = placeCoordinate.formattedAddress;
    userAddress.country = placeCoordinate.addressComponents
        .firstWhere((element) => element.types.contains("country"))
        .shortName;
  }

  Future<void> getEvents() async {
    emit(GetEventsLoading());
    debugPrint("Get Events");
    try {
      final response = await apiService.getEvents();
      if (response.isSuccessful && response.data['status'] == 200) {
        List<EventModel> events = [];
        response.data['data'].forEach((event) {
          events.add(EventModel.fromJson(event));
        });
        emit(GetEventsSuccess(events: events));
      } else {
        emit(GetEventsFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetEventsFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetEventsFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  // Update Location

  void updateLocation(
      {required String address, required GeoLocation geoLocation}) async {
    emit(UpdateLocationState());
    try {
      final response = await apiService.updateLocation(
          address: address, geoLocation: geoLocation);
      if (response.isSuccessful && response.data['status'] == 200) {
        getIt<ProfileCubit>().getProfile();
        emit(const UpdateLocationSuccess());
      } else {
        emit(UpdateLocationFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdateLocationFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdateLocationFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
