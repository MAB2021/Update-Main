part of 'location_cubit.dart';

@immutable
abstract class LocationState extends Equatable {
  const LocationState();

  @override
  List<Object> get props => [];
}

class LocationInitial extends LocationState {}

class MyLocationInitialState extends LocationState {}

class LocationServiceDisAbled extends LocationState {}

class LocationPermissionDisAbled extends LocationState {}

class LocationServiceError extends LocationState {}

class LocationPermissionDeniedForever extends LocationState {}

class LocationEnabled extends LocationState {
  final AddressBook? currentAddress;
  const LocationEnabled({required this.currentAddress});
}

class FetchingPlaces extends LocationState {}

class FetchedPlaces extends LocationState {
  final List<Prediction> predictions;
  const FetchedPlaces({required this.predictions});
}

class FetchingCoordinate extends LocationState {}

class FetchedCoordinate extends LocationState {
  final AddressBook? addressBook;
  final PlaceCoordinate? coordinate;
  final String? cityName;
  const FetchedCoordinate({this.addressBook, this.coordinate, this.cityName});
}

class FetchingCoordinateAddress extends LocationState {}

class FetchedCoordinateAddress extends LocationState {
  final AddressBook addressBook;
  const FetchedCoordinateAddress(this.addressBook);
}

//Get events

class GetEventsLoading extends LocationState {}

class GetEventsSuccess extends LocationState {
  final List<EventModel> events;

  const GetEventsSuccess({required this.events});
}

class GetEventsFailed extends LocationState {
  final String errorMessage;

  const GetEventsFailed({required this.errorMessage});
}

//Update Location state

class UpdateLocationState extends LocationState {}

class UpdateLocationSuccess extends LocationState {
  const UpdateLocationSuccess();
}

class UpdateLocationFailed extends LocationState {
  final String errorMessage;
  const UpdateLocationFailed({required this.errorMessage});
}
