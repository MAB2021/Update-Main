import 'dart:convert';
import 'package:equatable/equatable.dart';
import 'package:buzz_map/shared/models/geo_location.dart';
import '../../../shared/models/base.dart';

List<AddressBook> addressBookFromJson(String str) => List<AddressBook>.from(
    json.decode(str).map((x) => AddressBook.fromJson(x)));

String addressBookToJson(List<AddressBook> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

// ignore: must_be_immutable
class AddressBook extends BaseModel implements Equatable {
  String? id;
  String? address;
  AddressType? type;
  String? details;
  GeoLocation? location;
  String? status;
  String? createdAt;
  String? updatedAt;
  int? v;
  bool? isDefault;
  String? country;

  AddressBook(
      {this.id,
      this.address,
      this.type,
      this.details,
      this.location,
      this.status,
      this.createdAt,
      this.updatedAt,
      this.v,
      this.isDefault,
      this.country});

  AddressBook.fromJson(Map<String, dynamic> json)
      : id = json['_id'] as String?,
        address = json['address'] as String?,
        type = (json["type"] == "Home"
            ? AddressType.home
            : json["type"] == "work"
                ? AddressType.work
                : AddressType.others),
        details = json['details'] as String?,
        location = (json['location'] as Map<String, dynamic>?) != null
            ? GeoLocation.fromJson(json['location'] as Map<String, dynamic>)
            : null,
        status = json['status'] as String?,
        createdAt = json['createdAt'] as String?,
        updatedAt = json['updatedAt'] as String?,
        isDefault = json['default'] as bool?,
        v = json['__v'] as int?,
        country = json['country'] as String?;

  @override
  Map<String, dynamic> toJson() => {
        '_id': id,
        'address': address,
        'type': toEnumString(type!),
        'details': details,
        'location': location?.toJson(),
        'status': status,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
        '__v': v,
        'id': id,
        'default': isDefault,
        'country': country
      };

  @override
  List<Object?> get props => [address, location, status, id];

  @override
  bool? get stringify => true;

  static AddressType toEnum(String type) {
    if (type == "HOME") return AddressType.home;
    if (type == "WORK") return AddressType.work;
    return AddressType.others;
  }

  static String toEnumString(AddressType type) {
    if (type == AddressType.home) return "Home";
    if (type == AddressType.work) return "work";
    return "other";
  }
}

enum AddressType { home, work, others }

extension AddressTypeEnum on AddressType {
  String get title {
    if (this == AddressType.home) return "Home";
    if (this == AddressType.work) return "Work";
    return "Others";
  }

  String get backendValue {
    if (this == AddressType.home) return "Home";
    if (this == AddressType.work) return "work";
    return "other";
  }

  /// This return Title for Add address label
}
