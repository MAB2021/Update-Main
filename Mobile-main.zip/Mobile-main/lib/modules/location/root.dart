import 'dart:async';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart' as eventCubit;
import 'package:buzz_map/modules/home/widgets/trending/all_trending/all_trending_item.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/models/address_model.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/services.dart';

class LocationRootWidget extends StatefulWidget {
  final bool isCurrent;
  const LocationRootWidget({super.key, required this.isCurrent});

  @override
  State<LocationRootWidget> createState() => _LocationRootWidgetState();
}

class _LocationRootWidgetState extends State<LocationRootWidget>
    with WidgetsBindingObserver {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  late CameraPosition initialCameraPosition;

  AddressBook? addressBook;
  String? _mapStyle;
  Set<Marker> markers = {};
  bool isLoading = false;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _loadMapStyle();
    _initializeCameraPosition();

    if (userCurrentPosition.value == null) {
      getCurrentPosition();
    }
  }

  Future<void> _loadMapStyle() async {
    _mapStyle = await rootBundle.loadString('assets/map_style.txt');
  }

  void _initializeCameraPosition() {
    final position = userCurrentPosition.value;
    initialCameraPosition = CameraPosition(
      target: LatLng(
        position?.latitude ?? 37.42796133580664,
        position?.longitude ?? -122.08574965596,
      ),
      zoom: 14.4746,
    );
  }

  void _onCameraMove(CameraPosition position) {
    userCurrentPosition.value =
        LatLng(position.target.latitude, position.target.longitude);
  }

  void _onCameraIdle() {
    _debounceFetchData();
  }

  void _onMapTap(LatLng coordinate) {
    userCurrentPosition.value =
        LatLng(coordinate.latitude, coordinate.longitude);
    _debounceFetchData();
  }

  void _debounceFetchData() {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 50), () {
      if (!isLoading) {
        setState(() {
          isLoading = true;
        });
        _fetchData();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;

    return Offstage(
      offstage: !widget.isCurrent,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          centerTitle: false,
          leading: const SizedBox.shrink(),
          leadingWidth: 10,
          title: Text(
            S.current.eventAroundYou,
            style: Theme.of(context).textTheme.titleLarge!.copyWith(
                  fontSize: 18.sp,
                ),
          ),
        ),
        body: BlocConsumer<LocationCubit, LocationState>(
          bloc: getIt<LocationCubit>(),
          listener: (context, state) {
            if (state is FetchedCoordinateAddress) {
              addressBook = state.addressBook;
              userCurrentAddress.value = addressBook?.address;
              userCurrentCountry.value = addressBook?.country;

              _controller.future.then((controller) {
                controller.animateCamera(
                  CameraUpdate.newLatLng(
                    LatLng(addressBook!.location!.latitude,
                        addressBook!.location!.longitude),
                  ),
                );
              });

              getIt<eventCubit.EventsCubit>().getEvents(pageNumber: 1);
            } else if (state is FetchedCoordinate) {
              addressBook = state.addressBook;
              setState(() {});
            } else if (state is GetEventsLoading) {
            } else if (state is GetEventsSuccess) {
              _updateMarkers(state.events);
            }
          },
          builder: (context, state) {
            return Stack(
              children: [
                ValueListenableBuilder<String?>(
                  valueListenable: userCurrentAddress,
                  builder: (context, value, child) {
                    return GoogleMap(
                      mapType: MapType.normal,
                      myLocationButtonEnabled: false,
                      initialCameraPosition: initialCameraPosition,
                      markers: markers,
                      onMapCreated: (controller) {
                        _controller.complete(controller);

                        if (isDarkMode && _mapStyle != null) {
                          controller.setMapStyle(_mapStyle);
                        }
                      },
                      onCameraMove: _onCameraMove,
                      onCameraIdle: _onCameraIdle,
                      onTap: _onMapTap,
                    );
                  },
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  void _updateMarkers(List<EventModel> events) async {
    final Set<Marker> newMarkers = events.map((event) {
      return Marker(
        markerId: MarkerId(event.eventId),
        position: LatLng(event.eventLatitude, event.eventLongitude),
        onTap: () {
          showModalBottomSheet(
            context: context,
            builder: (context) => ReusableBottomSheet(
              minHeight: 300,
              initHeight: 300,
              maxHeight: 400,
              content: Column(
                children: [
                  37.h.verticalSpace,
                  AllTrendingItem(
                    model: event,
                    index: events.indexOf(event),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }).toSet();

    setState(() {
      markers = newMarkers;
    });
  }

  Future<void> getCurrentPosition() async {
    Position position = await determinePosition(
        getIt<NavigationService>().navigatorKey.currentContext!);
    userCurrentPosition.value = LatLng(position.latitude, position.longitude);
    await getIt<LocationCubit>()
        .findCoordinateAddress(userCurrentPosition.value!, false);
    await getIt<LocationCubit>().getEvents();
    _controller.future.then((controller) {
      controller.animateCamera(
        CameraUpdate.newLatLng(userCurrentPosition.value!),
      );
    });
  }

  Future<void> _fetchData() async {
    try {
      getIt<LocationCubit>().getEvents();
    } catch (e) {
      debugPrint('Error fetching data: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }
}
