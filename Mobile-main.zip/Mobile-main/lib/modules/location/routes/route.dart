class LocationRoutes {
  static const String locationRoot = 'location';
  static const String selectLocation = 'selectLocation';
  static const String searchLocation = 'searchLocation';
}
