import 'package:buzz_map/shared/models/geo_location.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class LocationApiService {
  final HttpService http;

  LocationApiService({required this.http});

  Future<Response> getCoordinate(String address) {
    // "https://maps.googleapis.com/maps/api/geocode/json?address=Ikeja,%20Nigeria&key="
    return HttpService(baseUrl: "", hasAuthorization: false).getRequest(
        "https://maps.googleapis.com/maps/api/geocode/json?address=$address&key=${AppConfig.mapApiKey}");
  }

  Future<Response> getPlace(String placeName) {
    return HttpService(baseUrl: "", hasAuthorization: false).getRequest(
        "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=${AppConfig.mapApiKey}");
  }

  Future<Response> getFormattedAddress(LatLng latLng) async {
    return HttpService(baseUrl: "", hasAuthorization: false).getRequest(
        "https://maps.googleapis.com/maps/api/geocode/json?latlng=${latLng.latitude},${latLng.longitude}&key=${AppConfig.mapApiKey}");
  }

  Future<Response> getDirection(
      LatLng startPosition, LatLng endPosition) async {
    return HttpService(baseUrl: "").getRequest(
        "https://maps.googleapis.com/maps/api/directions/json?origin=${startPosition.latitude},${startPosition.longitude}&destination=${endPosition.latitude},${endPosition.longitude}&key=${AppConfig.mapApiKey}");
  }

  Future<Response> getEvents() async {
    return http.getRequest(AppURL.upcomingEvent, queryParameters: {
      "latitude": userCurrentPosition.value!.latitude,
      "longitude": userCurrentPosition.value!.longitude,
      "is_guest": 0,
      "page": 1
    });
    // return http.getRequest("${AppURL.events}$category", queryParameters: {
    //   "latitude": userCurrentPosition.value!.latitude,
    //   "longitude": userCurrentPosition.value!.longitude,
    // });
  }

  Future<Response> updateLocation(
      {required String address, required GeoLocation geoLocation}) async {
    return http.post(AppURL.updateProfile,
        data: {"town": address, "location": geoLocation.toJson()});
  }
}
