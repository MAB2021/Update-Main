import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomMarkerWidget extends StatelessWidget {
  final String imageUr;
  final String distance;
  final String? userCountry;

  const CustomMarkerWidget({
    super.key,
    required this.imageUr,
    required this.distance,
    this.userCountry,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 25.r,
          child: BuzzMapCacheImage(
            imgUrl: imageUr,
            height: 50.h,
            width: 50.w,
            borderRadius: 50.r,
            memCacheHeight: 150,
            memCacheWidth: 150,
          ),
        ),
        10.h.verticalSpace,
        Container(
          alignment: Alignment.center,
          height: 20.h,
          width: 50.w,
          decoration: BoxDecoration(
            color: AppColors.inputFiledColor,
            borderRadius: BorderRadius.circular(81.r),
            border: Border.all(
                color: Theme.of(context).primaryColorDark, width: 1.w),
          ),
          child: Text(
            convertDistance(distance, userCountry),
            style: GoogleFonts.outfit(
              color: Colors.white,
              fontSize: 10.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ],
    );
  }

  //If location is US, convert distance in km to miles
  String convertDistance(String distance, String? location) {
    if (location == "US" ||
        location == "United States" ||
        location == "United States of America" ||
        location == "USA") {
      return "${convertKmToMiles(double.parse(distance)).toStringAsFixed(2)} mi";
    }
    return "$distance km";
  }

  //Convert distance in km to miles
  double convertKmToMiles(double km) {
    return km * 0.621371;
  }
}
