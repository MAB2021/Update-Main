import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SearchAddressInputText extends StatefulWidget {
  final TextEditingController? searchController;
  final bool isEnabled;
  final String? categoryName;
  final int pageNumber = 1;
  const SearchAddressInputText(
      {super.key,
      this.searchController,
      this.isEnabled = false,
      this.categoryName});

  @override
  State<SearchAddressInputText> createState() => _SearchAddressInputTextState();
}

class _SearchAddressInputTextState extends State<SearchAddressInputText> {
  bool showCloseIcon = false;
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return InputText(
      enabled: widget.isEnabled,
      isFilled: true,
      isHomepageSearch: true,
      controller: widget.searchController,
      onChanged: (value) {
        getIt<LocationCubit>().fetchPlaces(
          value,
        );
        if (value.isEmpty) {
          showCloseIcon = false;
        } else {
          showCloseIcon = true;
        }
        setState(() {});
      },
      textPlaceholder: S.current.location, // S.current.searchIn(categoryName),
      inputBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6.r),
        borderSide: BorderSide.none,
      ),
      prefixWidget: Padding(
        padding: EdgeInsets.only(left: 14.w, right: 16.w),
        child: BuzzMapAssetImage(
            url: isDarkMode
                ? AssetResources.location
                : AssetResources.darkLocation,
            width: 24.w,
            height: 24.w),
      ),
      suffixIcon: GestureDetector(
        onTap: () {
          widget.searchController?.clear();
          setState(() {
            showCloseIcon = false;
          });
        },
        child: Visibility(
          visible: showCloseIcon,
          child: Icon(
            Icons.close,
            color: AppColors.buzzMapWhite,
          ),
        ),
      ),
      textInputAction: TextInputAction.search,
    );
  }
}
