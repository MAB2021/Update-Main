import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/models/prediction.dart';
import 'package:buzz_map/modules/location/widgets/search_address_input_field.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/models/geo_location.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SearchLocationScreen extends StatefulWidget {
  const SearchLocationScreen({super.key});

  @override
  State<SearchLocationScreen> createState() => _SearchLocationScreenState();
}

class _SearchLocationScreenState extends State<SearchLocationScreen> {
  final TextEditingController _controller = TextEditingController();
  List<Prediction>? predictionPlaces;
  bool fetchingCoordinate = false;
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        centerTitle: false,
        leadingWidth: 200.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(text: S.current.location),
        ),
      ),
      body: BlocConsumer(
        bloc: getIt<LocationCubit>(),
        listener: (context, state) {
          if (state is FetchedPlaces) {
            predictionPlaces = state.predictions;
          } else if (state is FetchingCoordinate) {
            DialogUtil.showLoadingDialog(context);
            fetchingCoordinate = true;
          } else if (state is FetchedCoordinate) {
            // DialogUtil.dismissLoadingDialog(context);
            fetchingCoordinate = false;
            userCurrentPosition.value = state.coordinate?.latLng;
            userCurrentAddress.value = state.coordinate?.formattedAddress;
            // getIt<NavigationService>().back();
            getIt<LocationCubit>().updateLocation(
                address: userCurrentAddress.value ?? "",
                geoLocation: GeoLocation(
                  latitude: userCurrentPosition.value?.latitude ?? 0.0,
                  longitude: userCurrentPosition.value?.longitude ?? 0.0,
                ));
          } else if (state is UpdateLocationState) {
            // DialogUtil.showLoadingDialog(context);
            fetchingCoordinate = false;
          } else if (state is UpdateLocationSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            fetchingCoordinate = false;
            getIt<NavigationService>().clearAllTo(routeName: RootRoutes.home);
          } else if (state is UpdateLocationFailed) {
            DialogUtil.dismissLoadingDialog(context);
            fetchingCoordinate = false;
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  14.h.verticalSpace,
                  SearchAddressInputText(
                    searchController: _controller,
                    isEnabled: true,
                    categoryName: S.current.location,
                  ),
                  ListView.separated(
                    itemCount: predictionPlaces?.length ?? 0,
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    physics: const NeverScrollableScrollPhysics(),
                    separatorBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 5.w, vertical: 5.h),
                        child: BuzzMapDivider(
                          dividerColor: AppColors.buzzMapGrayLight[20],
                        ),
                      );
                    },
                    itemBuilder: (BuildContext context, int index) {
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: BuzzMapAssetImage(
                            url: isDarkMode
                                ? AssetResources.location
                                : AssetResources.darkLocation,
                            width: 24.w,
                            height: 24.w),
                        title: Text(predictionPlaces?[index].description ?? '',
                            style: Theme.of(context).textTheme.titleSmall),
                        onTap: () {
                          onTap(predictionPlaces?[index]);
                        },
                        trailing: BuzzMapAssetImage(
                            url: AssetResources.arrowUp,
                            width: 24.w,
                            height: 24.w),
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void onTap(prediction) {
    _controller.text = prediction.description;

    getIt<LocationCubit>().getCoordinate(prediction.description);
  }
}
