import 'dart:async';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/home/widgets/search/search_input_text.dart';
import 'package:buzz_map/modules/location/cubit/location_cubit.dart';
import 'package:buzz_map/modules/location/models/address_model.dart';
import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter/services.dart' show rootBundle;

class SelectLocationScreen extends StatefulWidget {
  const SelectLocationScreen({super.key});

  @override
  State<SelectLocationScreen> createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen>
    with WidgetsBindingObserver {
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(
        userCurrentPosition.value != null
            ? userCurrentPosition.value!.latitude
            : 37.42796133580664,
        userCurrentPosition.value != null
            ? userCurrentPosition.value!.longitude
            : -122.08574965596),
    zoom: 14.4746,
  );

  AddressBook? addressBook;
  String? _mapStyle;

  @override
  void initState() {
    rootBundle.loadString('assets/map_style.txt').then((string) {
      _mapStyle = string;
    });
    if (userCurrentAddress.value == null || userCurrentAddress.value == "") {
      getCurrentPosition();
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leadingWidth: 250.w,
        leading: Padding(
          padding: EdgeInsets.only(left: 20.w),
          child: BackButtonWithTitle(text: S.current.selectYourLocation),
        ),
      ),
      body: BlocConsumer(
        bloc: getIt<LocationCubit>(),
        listener: (context, state) {
          if (state is FetchingCoordinateAddress) {
            // DialogUtil.showLoadingDialog(context);
          } else if (state is FetchedCoordinateAddress) {
            addressBook = state.addressBook;
            _controller.future.then((controller) {
              controller.animateCamera(
                CameraUpdate.newLatLng(
                  LatLng(addressBook!.location!.latitude,
                      addressBook!.location!.longitude),
                ),
              );
            });
            // DialogUtil.dismissLoadingDialog(context);
          }
        },
        builder: (context, state) {
          return Stack(
            children: [
              GoogleMap(
                mapType: MapType.normal,
                myLocationButtonEnabled: false,
                initialCameraPosition: _kGooglePlex,
                onMapCreated: (GoogleMapController controller) {
                  _controller.complete(controller);
                  controller.setMapStyle(_mapStyle);
                },
              ),
              Container(
                height: 124.h,
                margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 25.h),
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    17.h.verticalSpace,
                    Text(
                      userCurrentAddress.value ?? "Lagos,Nigeria",
                      style: GoogleFonts.outfit(
                        fontSize: 16.sp,
                        color: AppColors.buzzMapWhite,
                      ),
                      maxLines: 1,
                    ),
                    15.h.verticalSpace,
                    const SearchInputText()
                  ],
                ),
              ),
              Positioned(
                bottom: 75.h,
                left: 20.w,
                right: 20.w,
                child: BuzzMapButton(
                  text: S.current.addMyLocation,
                  onPressed: () {},
                ),
              )
            ],
          );
        },
      ),
    );
  }

  Future<void> getCurrentPosition() async {
    Position position = await determinePosition(
        getIt<NavigationService>().navigatorKey.currentContext!);
    getIt<LocationCubit>().findCoordinateAddress(
        LatLng(position.latitude, position.longitude), false);
    userCurrentPosition.value = LatLng(position.latitude, position.longitude);
    _controller.future.then((controller) {
      controller.animateCamera(
        CameraUpdate.newLatLng(
          LatLng(position.latitude, position.longitude),
        ),
      );
    });
  }
}
