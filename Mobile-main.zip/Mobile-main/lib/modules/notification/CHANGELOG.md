'`r Sys.Date()`'

- TODO: Created the initial setup of the Notification feature/module
