import 'dart:io';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:buzz_map/shared/notifications/firebase_notification_manager.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'notification_state.dart';

class NotificationCubit extends Cubit<NotificationState> {
  final NotificationApiService apiService;

  NotificationCubit({required this.apiService}) : super(NotificationInitial());

  void addDeviceToken() async {
    emit(PushNotificationUpdateLoading());

    String token = (await FirebaseNotificationManager().deviceToken)!;
    try {
      var os = Platform.isAndroid ? "Android" : "iOS";

      var body = {
        "token": token,
        "device": os,
      };
      var res = await apiService.addDeviceToken(body);
      if (res.isSuccessful) {
        // Add to local storage that device token has been map to user.
        getIt<LocalStorageUtils>().write(AppConstants.deviceTokenAdded, "true");
      }
      emit(PushNotificationUpdateSuccess());
    } catch (_) {
      emit(PushNotificationUpdateFailed());
    }
  }

  Future<void> removeDeviceToken() async {
    emit(RemoveNotificationUpdateLoading());
    try {
      var os = Platform.isAndroid ? "Android" : "iOS";
      var body = {
        "device": os,
      };
      var res = await apiService.removeDeviceToken(body);
      if (res.isSuccessful) {
        getIt<LocalStorageUtils>().delete(AppConstants.deviceTokenAdded);
      }
      emit(RemoveNotificationUpdateSuccess());
    } catch (_) {
      emit(RemoveNotificationUpdateFailed());
    }
  }
}
