part of 'notification_cubit.dart';

@immutable
abstract class NotificationState {}

class NotificationInitial extends NotificationState {}

//Add device token
class PushNotificationUpdateLoading extends NotificationState {}

class PushNotificationUpdateSuccess extends NotificationState {}

class PushNotificationUpdateFailed extends NotificationState {}

//Remove device token

class RemoveNotificationUpdateLoading extends NotificationState {}

class RemoveNotificationUpdateSuccess extends NotificationState {}

class RemoveNotificationUpdateFailed extends NotificationState {}