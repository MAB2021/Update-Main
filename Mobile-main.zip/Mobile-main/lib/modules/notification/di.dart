import 'package:get_it/get_it.dart';
import './services/api_service.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'cubit/notification_cubit.dart';
import 'package:buzz_map/configs/app_configs.dart';


void setupNotification(GetIt ioc){
  ioc.registerSingleton<NotificationCubit>(NotificationCubit(
    apiService: NotificationApiService(
      http: HttpService(baseUrl: AppURL.baseUrl,hasAuthorization: true),
    ),
  ));
}