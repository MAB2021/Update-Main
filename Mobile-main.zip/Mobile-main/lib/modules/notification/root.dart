import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/notification/widgets/notification_item.dart';
import 'package:buzz_map/shared/widgets/back_button_with_title.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: const SizedBox.shrink(),
        leadingWidth: 0.w,
        centerTitle: false,
        title: BackButtonWithTitle(text: S.current.notification),
      ),
      body: ListView.separated(
        itemCount: 10,
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        separatorBuilder: (BuildContext context, int index) {
          return const NotificationItemWidget();
        },
        itemBuilder: (BuildContext context, int index) {
          return 16.h.verticalSpace;
        },
      ),
      //     Center(
      //   child: EmptyStateWidget(
      //       topPadding: 0,
      //       imageUrl: AssetResources.notificationWhiteBell,
      //       title: S.current.youHaveNoNotifications),
      // ),
    );
  }
}
