class NotificationRoutes {
  static const String notificationRoot = 'notification';
}
