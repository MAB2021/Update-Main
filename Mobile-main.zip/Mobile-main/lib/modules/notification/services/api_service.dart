import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:dio/dio.dart';

class NotificationApiService {
  final HttpService http;

  NotificationApiService({required this.http});

  Future<Response> addDeviceToken(body) async {
    return http.post(AppURL.createDeviceToken, data: body);
  }

  Future<Response> removeDeviceToken(body) async {
    return http.put(AppURL.removeDeviceToken, data: body);
  }
}
