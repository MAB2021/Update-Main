import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NotificationItemWidget extends StatelessWidget {
  const NotificationItemWidget({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return ListTile(
      tileColor: isDarkMode ? AppColors.primaryColor : Colors.white,
      minLeadingWidth: 68.w,
      dense: false,
      visualDensity: VisualDensity.standard,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color:
              isDarkMode ? Colors.white.withOpacity(0.10) : Colors.transparent,
          width: 1.w,
        ),
        borderRadius: BorderRadius.circular(16.r),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 0.w, vertical: 18.5.h),
      leading: Container(
        height: 68.h,
        width: 68.w,
        decoration: BoxDecoration(
            shape: BoxShape.circle, color: AppColors.secondaryColor),
        child: const BuzzMapAssetImage(url: AssetResources.discount),
      ),
      title: Text(
        '30% Special Discount!',
        style: Theme.of(context)
            .textTheme
            .displayMedium!
            .copyWith(fontWeight: FontWeight.w700),
      ),
      subtitle: Text('Special promotion only valid today',
          style: Theme.of(context).textTheme.bodySmall),
    );
  }
}
