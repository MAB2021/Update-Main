import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';

class OnboardingItem {
  final String title;
  final String subtitle;
  final String image;

  OnboardingItem({
    required this.title,
    required this.subtitle,
    required this.image,
  });
}

class OnboardingItems {
  static List<OnboardingItem> loadOnboardItem() {
    return <OnboardingItem>[
      OnboardingItem(
        title: S.current.exploringUpcomingAndNearbyEvent,
        subtitle:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque aliquam bibendum metus, sit amet fermentum purus sollicitudin vel. Pellentesque vitae lacinia justo. Cras nec arcu nec leo dignissim tincidunt.",
        image: AssetResources.onboarding_one,
      ),
      OnboardingItem(
        title: S.current.expandYourNetwork,
        subtitle:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque aliquam bibendum metus, sit amet fermentum purus sollicitudin vel. Pellentesque vitae lacinia justo. Cras nec arcu nec leo dignissim tincidunt.",
        image: AssetResources.onboarding_two,
      ),
      OnboardingItem(
        title: S.current.easilyAddEventsToYourCalendar,
        subtitle:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque aliquam bibendum metus, sit amet fermentum purus sollicitudin vel. Pellentesque vitae lacinia justo. Cras nec arcu nec leo dignissim tincidunt.",
        image: AssetResources.onboarding_three,
      ),
      OnboardingItem(
        title: S.current.findYouFavouriteEvents,
        subtitle: S.current.discoverExcitingEvents,
        image: AssetResources.onboarding_four,
      ),
    ];
  }
}
