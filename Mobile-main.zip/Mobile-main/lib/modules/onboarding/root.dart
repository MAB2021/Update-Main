import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/routes/route.dart';
import 'package:buzz_map/modules/onboarding/models/onboarding_model.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class OnboardingRootScreen extends StatefulWidget {
  const OnboardingRootScreen({super.key});

  @override
  State<OnboardingRootScreen> createState() => _OnboardingRootScreenState();
}

class _OnboardingRootScreenState extends State<OnboardingRootScreen> {
  int _currentIndex = 0;
  int totalPages = OnboardingItems.loadOnboardItem().length;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        top: true,
        bottom: true,
        child: Stack(
          fit: StackFit.loose,
          // alignment: Alignment.topCenter,
          children: [
            CarouselSlider.builder(
              options: CarouselOptions(
                height: MediaQuery.of(context).size.height,
                padEnds: false,
                viewportFraction: 1,
                aspectRatio: 1,
                onPageChanged: (index, reason) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
              ),
              itemCount: totalPages,
              itemBuilder: (context, index, realIndex) {
                OnboardingItem item =
                    OnboardingItems.loadOnboardItem()[_currentIndex];
                return Column(
                  children: [
                    BuzzMapAssetImage(
                      width: 441.w,
                      height: 382.63.h,
                      url: item.image,
                      fit: BoxFit.scaleDown,
                    ),
                  ],
                );
              },
            ),
            BottomWidget(
              item: OnboardingItems.loadOnboardItem()[_currentIndex],
              currentIndex: _currentIndex,
              totalPages: totalPages,
              onNextPressed: () {
                setState(() {
                  if (_currentIndex < totalPages - 1) {
                    _currentIndex++;
                  }
                });
              },
            )
          ],
        ),
      ),
    );
  }
}

class BottomWidget extends StatelessWidget {
  final OnboardingItem item;
  final int currentIndex;
  final int totalPages;
  final VoidCallback onNextPressed;

  const BottomWidget(
      {super.key,
      required this.item,
      required this.currentIndex,
      required this.totalPages,
      required this.onNextPressed});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Column(
        children: [
          const Spacer(
            flex: 6,
          ),
          Text(
            item.title,
            style: Theme.of(context).textTheme.displayMedium!.copyWith(
                  fontSize: 26.sp,
                ),
            textAlign: TextAlign.center,
          ),
          20.h.verticalSpace,
          Text(
            item.subtitle,
            style: Theme.of(context).textTheme.titleSmall,
            textAlign: TextAlign.center,
          ),
          currentIndex == totalPages - 1
              ? Column(
                  children: [
                    40.h.verticalSpace,
                    BuzzMapButton(
                      text: S.current.signUp,
                      onPressed: () {
                        goToSignUpScreen();
                      },
                      textColor: Colors.white,
                      borderColor: Colors.transparent,
                    ),
                  ],
                )
              : BuzzMapButton(
                  text: S.current.skip,
                  onPressed: () {
                    goToLoginScreen();
                  },
                  color: Colors.transparent,
                  textColor:
                      isDarkMode ? Colors.white : AppColors.secondaryColor,
                  borderColor: Colors.transparent,
                ),
          currentIndex == totalPages - 1
              ? BuzzMapButton(
                  text: S.current.loginNow,
                  onPressed: () {
                    goToLoginScreen();
                  },
                  color: Colors.transparent,
                  textColor:
                      isDarkMode ? Colors.white : AppColors.secondaryColor,
                  borderColor: Colors.transparent,
                )
              : BuzzMapButton(
                  text: S.current.next,
                  onPressed: () {
                    onNextPressed();
                  },
                  textColor: Colors.white,
                  borderColor: Colors.transparent,
                ),
          // const Spacer(),
        ],
      ),
    );
  }

  void goToLoginScreen() {
    getIt<LocalStorageUtils>().write(AppConstants.isUserFirstTime, 'true');
    getIt<NavigationService>().pushReplace(routeName: LoginRoutes.loginRoot);
  }

  void goToSignUpScreen() {
    getIt<LocalStorageUtils>().write(AppConstants.isUserFirstTime, 'true');
    getIt<NavigationService>().pushReplace(routeName: SignUpRoutes.signUpRoot);
  }
}
