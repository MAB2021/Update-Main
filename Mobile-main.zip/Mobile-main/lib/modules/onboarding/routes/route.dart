class OnboardingRoutes {
  static const String onboardingRoot = 'onboarding';
}
