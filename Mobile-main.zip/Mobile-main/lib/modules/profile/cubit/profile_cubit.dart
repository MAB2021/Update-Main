import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:buzz_map/modules/profile/models/interest.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'package:buzz_map/shared/utils/storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../services/api_service.dart';

part 'profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  final ProfileApiService apiService;

  ProfileCubit({required this.apiService}) : super(ProfileInitial());

  void getProfile() async {
    emit(GetProfileLoading());
    try {
      final response = await apiService.getUserProfile();
      if (response.isSuccessful && response.data['status'] == 200) {
        User userModel = User.fromJson(response.data['data']["user"]);
        getIt<LocalStorageUtils>()
            .saveObject<User>(AppConstants.userObject, userModel);
        getIt.registerSingleton<User>(userModel);
        List<Interest> interests = List<Interest>.from(response.data['data']
                ["interests"]
            .map((x) => Interest.fromJson(x)));
        getIt.registerSingleton<List<Interest>>(interests);
        emit(GetProfileSuccess(
          user: userModel,
          interests: interests,
        ));
      } else {
        emit(GetProfileFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(GetProfileFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(GetProfileFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  void updateProfilePicture({
    required String imageUrl,
  }) async {
    emit(UpdateProfileImageLoading());
    try {
      final response = await apiService.updateProfilePicture(
        imageUrl: imageUrl,
      );

      if (response.isSuccessful && response.data['status'] == 200) {
        emit(UpdateProfileImageSuccess());
      } else {
        emit(UpdateProfileImageFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdateProfileImageFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdateProfileImageFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Update profile details
  void updateProfileDetails(
      {required String firstName,
      required String lastName,
      required String phoneNumber,
      required String countryCode,
      required String dialCode}) async {
    emit(UpdateUserProfileLoading());
    try {
      final response = await apiService.updateUserProfileDetails(
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phoneNumber,
        countryCode: countryCode,
        dialCode: dialCode,
      );
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(UpdateUserProfileSuccess());
      } else {
        emit(UpdateUserProfileFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdateUserProfileFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdateUserProfileFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }

  //Update User notification  setting
  void updateUserNotification(
      {required UpdateProfileModel updateProfileModel}) async {
    emit(UpdatingNotificationSettings());
    try {
      final response = await apiService.updateProfileDetails(
          updateProfileModel: updateProfileModel);
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(UpdateNotificationSettingsSuccess());
      } else {
        emit(UpdateNotificationSettingsFailed(
            errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(UpdateNotificationSettingsFailed(
            errorMessage: networkErrorHandler(e)));
      } else {
        emit(UpdateNotificationSettingsFailed(
            errorMessage: S.current.anErrorOccurred));
      }
    }
  }
  //Change password

  void changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    emit(ChangePasswordLoading());
    try {
      final response = await apiService.changePassword(
        oldPassword: oldPassword,
        newPassword: newPassword,
      );
      if (response.isSuccessful && response.data['status'] == 200) {
        emit(ChangePasswordSuccess());
      } else {
        emit(ChangePasswordFailed(errorMessage: response.data['message']));
      }
    } catch (e) {
      if (e is DioException) {
        emit(ChangePasswordFailed(errorMessage: networkErrorHandler(e)));
      } else {
        emit(ChangePasswordFailed(errorMessage: S.current.anErrorOccurred));
      }
    }
  }
}
