part of 'profile_cubit.dart';

@immutable
abstract class ProfileState {}

class ProfileInitial extends ProfileState {}

//Get Profile
class GetProfileLoading extends ProfileState {}

class GetProfileSuccess extends ProfileState {
  final User user;
  final List<Interest> interests;

  GetProfileSuccess({required this.user, required this.interests});
}

class GetProfileFailed extends ProfileState {
  final String errorMessage;

  GetProfileFailed({required this.errorMessage});
}

//Update Profile Image
class UpdateProfileImageLoading extends ProfileState {}

class UpdateProfileImageSuccess extends ProfileState {}

class UpdateProfileImageFailed extends ProfileState {
  final String errorMessage;

  UpdateProfileImageFailed({required this.errorMessage});
}

//Update User profile
class UpdateUserProfileLoading extends ProfileState {}

class UpdateUserProfileSuccess extends ProfileState {}

class UpdateUserProfileFailed extends ProfileState {
  final String errorMessage;

  UpdateUserProfileFailed({required this.errorMessage});
}

//Update User notification  setting
class UpdatingNotificationSettings extends ProfileState {}

class UpdateNotificationSettingsSuccess extends ProfileState {}

class UpdateNotificationSettingsFailed extends ProfileState {
  final String errorMessage;

  UpdateNotificationSettingsFailed({required this.errorMessage});
}

//Change password

class ChangePasswordLoading extends ProfileState {}

class ChangePasswordSuccess extends ProfileState {
  ChangePasswordSuccess();
}

class ChangePasswordFailed extends ProfileState {
  final String errorMessage;

  ChangePasswordFailed({required this.errorMessage});
}
