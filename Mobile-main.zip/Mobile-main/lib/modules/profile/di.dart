import 'package:get_it/get_it.dart';
import './services/api_service.dart';
import 'package:buzz_map/shared/network/network_request.dart';
import 'cubit/profile_cubit.dart';
import 'package:buzz_map/configs/app_configs.dart';

void setupProfile(GetIt ioc) {
  ioc.registerSingleton<ProfileCubit>(
    ProfileCubit(
      apiService: ProfileApiService(
        http: HttpService(baseUrl: AppURL.baseUrl, hasAuthorization: true),
      ),
    ),
  );
}
