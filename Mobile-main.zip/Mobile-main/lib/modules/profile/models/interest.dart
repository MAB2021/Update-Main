import 'package:buzz_map/modules/auth/sign_up/models/category_model.dart';

class Interest {
  final CategoryModel category;

  Interest({
    required this.category,
  });

  factory Interest.fromJson(Map<String, dynamic> json) => Interest(
        category: CategoryModel.fromJson(json["category"]),
      );

  Map<String, dynamic> toJson() => {
        "category": category.toJson(),
      };
}
