import 'package:buzz_map/shared/models/base.dart';
import 'package:buzz_map/shared/models/geo_location.dart';

class User extends BaseModel {
  final int id;
  final String firstName;
  final String lastName;
  final String email;
  final String phoneNumber;
  final bool isActive;
  final String userType;
  bool generalNotification;
  bool sound;
  bool appUpdates;
  final String fullName;
  final String town;
  final GeoLocation? geoLocation;
  final String? imageUrl;
  final String? dialCode;
  final String? countryCode;

  User({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phoneNumber,
    required this.isActive,
    required this.userType,
    required this.generalNotification,
    required this.sound,
    required this.appUpdates,
    required this.fullName,
    required this.town,
    required this.geoLocation,
    this.imageUrl = "",
    this.dialCode = "",
    this.countryCode = "",
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        phoneNumber: json["phone_number"],
        isActive: json["is_active"],
        userType: json["user_type"],
        generalNotification: json["general_notification"],
        sound: json["sound"],
        appUpdates: json["app_updates"],
        fullName: json["first_name"] + " " + json["last_name"],
        town: json["town"],
        geoLocation: json["location"] == null ||
                json["geo_location"] is String ||
                json["location"] == ""
            ? null
            : GeoLocation.fromJson(json["location"]),
        imageUrl: json["image_url"],
        dialCode: json["dial_code"],
        countryCode: json["country_code"],
      );

  @override
  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "phone_number": phoneNumber,
        "is_active": isActive,
        "user_type": userType,
        "general_notification": generalNotification,
        "sound": sound,
        "app_updates": appUpdates,
        "full_name": fullName,
        "town": town,
        "location": geoLocation?.toJson(),
        "image_url": imageUrl,
        "dial_code": dialCode,
        "country_code": countryCode
      };
}
