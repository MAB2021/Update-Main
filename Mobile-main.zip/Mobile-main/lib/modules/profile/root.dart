import 'dart:io';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/modules/profile/models/interest.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/modules/profile/routes/route.dart';
import 'package:buzz_map/modules/profile/widgets/clickable_list_tile.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/utils/logout.dart';
import 'package:buzz_map/shared/utils/photo_bottom_sheet.dart';
import 'package:buzz_map/shared/utils/upload_image.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/cached_image.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfileRootWidget extends StatefulWidget {
  final bool isCurrent;
  const ProfileRootWidget({super.key, required this.isCurrent});

  @override
  State<ProfileRootWidget> createState() => _ProfileRootWidgetState();
}

class _ProfileRootWidgetState extends State<ProfileRootWidget> {
  @override
  Widget build(BuildContext context) {
    return Offstage(offstage: !widget.isCurrent, child: const ProfileScreen());
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User? userProfileModel;
  List<Interest> interests = [];
  double fileMaxSize = 2048;
  double? fileSize;
  String? uploadUrl;
  String? imagePath;
  @override
  void initState() {
    super.initState();
    if (getIt.isRegistered<User>()) {
      userProfileModel = getIt<User>();
    }
    if (getIt.isRegistered<List<Interest>>()) {
      interests = getIt<List<Interest>>();
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ProfileCubit>(),
        listener: (context, state) {
          if (state is GetProfileLoading) {
            // DialogUtil.showLoadingDialog(context);
          } else if (state is GetProfileSuccess) {
            // DialogUtil.dismissLoadingDialog(context);
            userProfileModel = state.user;
            interests = state.interests;
          } else if (state is GetProfileFailed) {
            // DialogUtil.dismissLoadingDialog(context);
            // NotificationMessage.showMessage(
            //   context,
            //   message: state.errorMessage,
            //   isError: true,
            // );
          } else if (state is UpdateProfileImageSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            getIt<ProfileCubit>().getProfile();
            NotificationMessage.showMessage(
              context,
              message: S.current.profilePictureUploaded,
              isError: false,
            );
          } else if (state is UpdateProfileImageFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(
              context,
              message: state.errorMessage,
              isError: true,
            );
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      S.current.profile,
                      style: Theme.of(context).textTheme.titleLarge!.copyWith(
                            fontSize: 18.sp,
                          ),
                      textAlign: TextAlign.start,
                    ),
                  ),
                  56.h.verticalSpace,
                  Stack(
                    children: [
                      Container(
                        height: 100.h,
                        width: 100.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.buzzMapWhite,
                          border: Border.all(color: Colors.black),
                        ),
                        child: BuzzMapCacheImage(
                          imgUrl: userProfileModel?.imageUrl ?? "",
                          height: 100.h,
                          width: 100.w,
                          borderRadius: 100.r,
                          errorWidget: Center(
                            child: Text(
                              "${userProfileModel?.firstName[0] ?? ""}${userProfileModel?.lastName[0] ?? ""}",
                              style: GoogleFonts.outfit(
                                color: Colors.black,
                                fontSize: 20.sp,
                                fontWeight: FontWeight.w400,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10,
                        right: 10.w,
                        child: GestureDetector(
                          onTap: () async {
                            showPhotoDialogBottomSheet(
                                context: context,
                                onCompleted: (file) async {
                                  getIt<NavigationService>().back();
                                  DialogUtil.showLoadingDialog(context);
                                  String path = file.path;
                                  double size = File(path).lengthSync() / 1024;
                                  if (size > fileMaxSize) {
                                    // ignore: use_build_context_synchronously
                                    NotificationMessage.showMessage(context,
                                        message: S.current.fileTooLarge(
                                          fileMaxSize ~/ 1024,
                                        ),
                                        isError: true);
                                    return;
                                  } else {
                                    fileSize = size;
                                    imagePath = path;

                                    DialogUtil.showLoadingDialog(context);
                                    var selectedImageUrl =
                                        await UploadImage.uploadImage(
                                            imagePath: path);

                                    getIt<ProfileCubit>().updateProfilePicture(
                                        imageUrl: selectedImageUrl!);
                                  }
                                });
                          },
                          child: BuzzMapAssetImage(
                            url: userProfileModel?.imageUrl == null ||
                                    userProfileModel?.imageUrl == ""
                                ? AssetResources.blackCamera
                                : AssetResources.whiteCamera,
                          ),
                        ),
                      )
                    ],
                  ),
                  20.h.verticalSpace,
                  Text(
                    userProfileModel?.fullName ?? "",
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontSize: 20.sp,
                        ),
                  ),
                  28.h.verticalSpace,
                  Row(
                    children: [
                      Text(S.current.interests,
                          style: Theme.of(context).textTheme.titleMedium),
                      10.w.horizontalSpace,
                      BuzzMapAssetImage(
                        url: isDarkMode
                            ? AssetResources.edit
                            : AssetResources.darkEdit,
                        height: 24.h,
                        width: 24.w,
                      )
                    ],
                  ),
                  10.h.verticalSpace,
                  SizedBox(
                    width: double.infinity,
                    child: Wrap(
                      runSpacing: 10.h,
                      // spacing: 10.w,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      children: List.generate(
                        interests.length,
                        (index) => Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 15.w,
                            vertical: 8.h,
                          ),
                          margin: EdgeInsets.only(right: 10.w, bottom: 10.h),
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            borderRadius: BorderRadius.circular(81.r),
                            border: Border.all(
                              color: Theme.of(context).primaryColorDark,
                            ),
                          ),
                          child: Text(
                            interests[index].category.categoryName,
                            style: Theme.of(context).textTheme.titleSmall,
                          ),
                        ),
                      ),
                    ),
                  ),
                  46.h.verticalSpace,
                  ClickableListTile(
                      title: S.current.editProfile,
                      leadingIcon: isDarkMode
                          ? AssetResources.editProfile
                          : AssetResources.darkEditProfile,
                      onPressed: onEditProfile),
                  ClickableListTile(
                      title: S.current.notification,
                      leadingIcon: isDarkMode
                          ? AssetResources.notification
                          : AssetResources.darkNotification,
                      onPressed: onNotification),
                  ClickableListTile(
                      title: S.current.security,
                      leadingIcon: isDarkMode
                          ? AssetResources.security
                          : AssetResources.darkSecurity,
                      onPressed: onSecurity),
                  ClickableListTile(
                      title: S.current.privacyPolicy,
                      leadingIcon: isDarkMode
                          ? AssetResources.privacyPolicy
                          : AssetResources.darkPrivacyPolicy,
                      onPressed: () {
                        getIt<NavigationService>().toWithParameters(
                            routeName: RootRoutes.websiteScreen,
                            args: {
                              'url': AppURL.privacyPolicy,
                              'pageTitle': S.current.privacyPolicy
                            });
                      }),
                  ClickableListTile(
                      title: S.current.helpCenter,
                      leadingIcon: isDarkMode
                          ? AssetResources.helpCenter
                          : AssetResources.darkHelpCenter,
                      onPressed: () {}),
                  // Row(
                  //   children: [
                  //     Text(
                  //       S.current.lightMode,
                  //       maxLines: 2,
                  //       textAlign: TextAlign.center,
                  //       style:
                  //           Theme.of(context).textTheme.titleMedium!.copyWith(
                  //                 fontWeight: FontWeight.w600,
                  //               ),
                  //     ),
                  //     const Spacer(),
                  //     Switch.adaptive(
                  //       value: !AdaptiveTheme.of(context).mode.isDark,
                  //       onChanged: (value) {
                  //         if (value) {
                  //           AdaptiveTheme.of(context).setLight();
                  //         } else {
                  //           AdaptiveTheme.of(context).setDark();
                  //         }
                  //       },
                  //       activeColor: Theme.of(context).primaryColorDark,
                  //     ),
                  //   ],
                  // ),
                  // 18.h.verticalSpace,
                  // BuzzMapDivider(
                  //   height: 1.h,
                  // ),
                  // 18.h.verticalSpace,
                  InkWell(
                    onTap: () => showModalBottomSheet(
                      context: context,
                      builder: (context) => ReusableBottomSheet(
                        content: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const BottomSheetGreyContainer(),
                            8.h.verticalSpace,
                            Center(
                              child: Text(
                                S.current.logout.capitalize(),
                                style: GoogleFonts.outfit(
                                  color: AppColors.logoutColor,
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w700,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            17.h.verticalSpace,
                            BuzzMapDivider(
                              height: 1.h,
                              dividerColor: AppColors.buzzMapGrayLight[20],
                            ),
                            9.h.verticalSpace,
                            Text(
                              S.current.areYourSureYouWantToLogout,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall!
                                  .copyWith(
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.w700,
                                  ),
                            ),
                            23.h.verticalSpace,
                            Row(
                              children: [
                                BuzzMapButton(
                                    borderRadius: 30.r,
                                    height: 53.h,
                                    width: 156.w,
                                    color: AppColors.buzzMapGrayLight[20],
                                    child: Text(
                                      S.current.cancel,
                                      style: GoogleFonts.outfit(
                                        color: AppColors.buzzMapWhite,
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    onPressed: () {
                                      getIt<NavigationService>().back();
                                    }),
                                10.w.horizontalSpace,
                                BuzzMapButton(
                                    borderRadius: 30.r,
                                    height: 53.h,
                                    width: 156.w,
                                    color: Theme.of(context).primaryColorDark,
                                    child: Text(
                                      S.current.yesLogout,
                                      style: GoogleFonts.outfit(
                                        color: AppColors.buzzMapWhite,
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    onPressed: () {
                                      LogoutUtil.logOutToSignIn();
                                    }),
                              ],
                            )
                          ],
                        ),
                        minHeight: 225, // Customize the minimum height
                        initHeight: 225, // Customize the initial height
                        maxHeight: 600.0, // Customize the maximum height
                      ),
                    ),
                    child: Row(
                      children: [
                        BuzzMapAssetImage(
                          url: AssetResources.logout,
                          width: 20.w,
                          height: 20.h,
                        ),
                        11.w.horizontalSpace,
                        Text(
                          S.current.logout,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            color: AppColors.logoutColor,
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void onEditProfile() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.editProfileScreen);
  }

  void onNotification() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.notificationScreen);
  }

  void onSecurity() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.securityScreen);
  }
}
