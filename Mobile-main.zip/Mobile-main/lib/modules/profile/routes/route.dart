class ProfileRoutes {
  static const String profileRoot = 'profile';
  static const String settingScreen = 'settingScreen';
  static const String editProfileScreen = 'editProfileScreen';
  static const String notificationScreen = 'notificationScreen';
  static const String securityScreen = 'securityScreen';
  static const String changePasswordScreen = 'changePasswordScreen';
}
