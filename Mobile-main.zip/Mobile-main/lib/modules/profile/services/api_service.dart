import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:dio/dio.dart';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/shared/network/network_request.dart';

class ProfileApiService {
  final HttpService http;

  ProfileApiService({required this.http});

  Future<Response> getUserProfile() async {
    return http.getRequest(AppURL.getUser);
  }

  Future<Response> updateProfilePicture({required String imageUrl}) async {
    return http.post(AppURL.updateProfile, data: {
      "image_url": imageUrl,
    });
  }

  Future<Response> updateProfileDetails(
      {required UpdateProfileModel updateProfileModel}) async {
    return http.post(AppURL.updateProfile, data: updateProfileModel.toJson());
  }

  Future<Response> updateUserProfileDetails(
      {required String firstName,
      required String lastName,
      required String phoneNumber,
      required String countryCode,
      required String dialCode}) async {
    return http.post(AppURL.updateProfile, data: {
      "first_name": firstName,
      "last_name": lastName,
      "phone_number": phoneNumber,
      "country_code": countryCode,
      "dial_code": dialCode
    });
  }

  //change password
  Future<Response> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    return http.post(AppURL.changePassword, data: {
      "old_password": oldPassword,
      "new_password": newPassword,
    });
  }
}
