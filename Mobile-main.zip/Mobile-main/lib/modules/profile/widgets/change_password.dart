import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _oldPasswordController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool isFormValid = false;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ProfileCubit>(),
        listener: (context, state) {
          if (state is ChangePasswordLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is ChangePasswordSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(context,
                message: "Password updated successfully", isError: false);
            getIt<NavigationService>()
                .clearAllTo(routeName: LoginRoutes.loginRoot);
          } else if (state is ChangePasswordFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          }
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    Row(
                      children: [
                        const CustomBackButton(),
                        Text(
                          S.current.settings,
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
                    20.h.verticalSpace,
                    BuzzMapDivider(
                      height: 1.h,
                    ),
                    17.h.verticalSpace,
                    InputText(
                      controller: _oldPasswordController,
                      labelText: S.current.oldPassword,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validatePassword(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.password,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _newPasswordController,
                      labelText: S.current.newPassword,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validatePassword(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.password,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _confirmPasswordController,
                      labelText: S.current.confirmNewPassword,
                      keyboardType: TextInputType.visiblePassword,
                      validator: (value) => Validator.validateConfirmPassword(
                          value, _newPasswordController.text),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.password,
                      ),
                    ),
                    30.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: isFormValid ? () => submit() : null,
                      textColor: Colors.white,
                      child: Text(
                        S.current.update,
                        style: GoogleFonts.outfit(
                          color: Colors.white,
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  submit() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      getIt<ProfileCubit>().changePassword(
          oldPassword: _oldPasswordController.text,
          newPassword: _newPasswordController.text);
    }
  }

  checkFormValid() {
    setState(() {
      if (_formKey.currentState!.validate()) {
        isFormValid = true;
      } else {
        isFormValid = false;
      }
    });
  }
}
