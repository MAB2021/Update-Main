import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ClickableListTile extends StatelessWidget {
  final String title;
  final String leadingIcon;
  final Function onPressed;
  const ClickableListTile(
      {super.key,
      required this.leadingIcon,
      required this.onPressed,
      required this.title});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return GestureDetector(
      onTap: () {
        onPressed();
      },
      behavior: HitTestBehavior.translucent,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  BuzzMapAssetImage(
                    url: leadingIcon,
                    width: 20.w,
                    height: 20.h,
                  ),
                  11.w.horizontalSpace,
                  Text(
                    title,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
              BuzzMapAssetImage(
                url: isDarkMode
                    ? AssetResources.arrow
                    : AssetResources.blackArrow,
                width: 18.w,
                height: 18.h,
              ),
            ],
          ),
          18.h.verticalSpace,
          BuzzMapDivider(
            height: 1.h,
          ),
          18.h.verticalSpace,
        ],
      ),
    );
  }
}
