import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_button_loader.dart';
import 'package:buzz_map/shared/utils/custom_style.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/utils/validator.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:fl_country_code_picker/fl_country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  User? userProfileModel;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  bool isFormValid = false;
  bool isLoading = false;
  String? selectedCountry;
  String selectedCountryCode = "+234";
  String? selectedCountryFlag;
  String? selectedCountryPackage;
  String? countryCode = "NG";

  @override
  void initState() {
    super.initState();
    if (getIt.isRegistered<User>()) {
      userProfileModel = getIt<User>();
      _fullNameController.text = userProfileModel!.fullName;
      _phoneNumberController.text = removeDialCode(
        userProfileModel!.phoneNumber,
        userProfileModel!.dialCode ?? "",
      );
      _emailController.text = userProfileModel!.email;
      selectedCountryCode = userProfileModel!.dialCode!;
    }
  }

  @override
  Widget build(BuildContext context) {
    final countryPicker = FlCountryCodePicker(
      localize: true,
      showDialCode: true,
      showSearchBar: true,
      title: Padding(
        padding: EdgeInsets.only(left: 16.w, top: 10.h, bottom: 10.h),
        child: Text(
          "Select a country",
          style: Theme.of(context)
              .textTheme
              .titleMedium
              ?.copyWith(fontWeight: FontWeight.w500),
        ),
      ),
      searchBarTextStyle: Theme.of(context).textTheme.headlineSmall,
      countryTextStyle: Theme.of(context).textTheme.titleMedium,
      dialCodeTextStyle: Theme.of(context).textTheme.titleMedium,
      searchBarDecoration: InputDecoration(
        // prefixIconConstraints: BoxConstraints(maxHeight: 40.w),

        labelStyle: Theme.of(context).textTheme.labelSmall,
        hintText: "Select a country",
        hintStyle: Theme.of(context).textTheme.displaySmall,
        isDense: true,
        filled: true,
        fillColor: !AdaptiveTheme.of(context).mode.isDark
            ? AppColors.lightInputFiledColor
            : AppColors.primaryColor,
        border: AppStyles.focusedBorder,
        focusedBorder: AppStyles.focusedBorder,
        disabledBorder: AppStyles.focusBorder,
        enabledBorder: AppStyles.focusBorder,
        errorBorder: AppStyles.focusErrorBorder,
        focusedErrorBorder: AppStyles.focusErrorBorder,
      ),
    );
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ProfileCubit>(),
        listener: (context, state) {
          if (state is UpdateUserProfileLoading) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is UpdateUserProfileSuccess) {
            getIt<ProfileCubit>().getProfile();
          } else if (state is UpdateUserProfileFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          } else if (state is GetProfileLoading) {
          } else if (state is GetProfileSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            getIt<ProfileCubit>().getProfile();
            NotificationMessage.showMessage(context,
                message: "Profile updated successfully ", isError: false);
            userProfileModel = state.user;
          } else if (state is GetProfileFailed) {}
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Form(
                key: _formKey,
                autovalidateMode: AutovalidateMode.disabled,
                child: Column(
                  children: [
                    Row(
                      children: [
                        const CustomBackButton(),
                        Text(
                          S.current.editProfile,
                          style:
                              Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontSize: 18.sp,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
                    20.h.verticalSpace,
                    BuzzMapDivider(
                      height: 1.h,
                    ),
                    17.h.verticalSpace,
                    InputText(
                      controller: _fullNameController,
                      labelText: S.current.fullName,
                      keyboardType: TextInputType.name,
                      validator: (value) => Validator.validateFullName(value),
                      textInputAction: TextInputAction.next,
                      onChanged: (value) => checkFormValid(),
                      isFilled: true,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.user,
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _phoneNumberController,
                      labelText: S.current.phoneNumber,
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.next,
                      isFilled: true,
                      enabled: false,
                      prefixWidget: GestureDetector(
                        onTap: () async {
                          // Show the country code picker when tapped.
                          final picked = await countryPicker.showPicker(
                              scrollToDeviceLocale: true,
                              backgroundColor:
                                  Theme.of(context).scaffoldBackgroundColor,
                              context: context);
                          // Null check
                          if (picked != null) {
                            setState(() {
                              selectedCountry = picked.name;
                              selectedCountryCode = picked.dialCode;
                              selectedCountryFlag = picked.flagUri;
                              selectedCountryPackage = picked.flagImagePackage;
                              countryCode = picked.code;
                            });
                          }
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: 22.h, horizontal: 10.w),
                          child: Text(
                            selectedCountryCode,
                            style: Theme.of(context).textTheme.displayMedium,
                          ),
                        ),
                      ),
                    ),
                    20.h.verticalSpace,
                    InputText(
                      controller: _emailController,
                      labelText: S.current.emailAddress,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      isFilled: true,
                      enabled: false,
                      prefixWidget: const BuzzMapAssetImage(
                        url: AssetResources.message,
                      ),
                    ),
                    30.h.verticalSpace,
                    BuzzMapButton(
                      onPressed: () => submit(),
                      textColor: Colors.white,
                      child: isLoading
                          ? const CustomButtonLoader()
                          : Text(
                              S.current.update,
                              style: GoogleFonts.outfit(
                                color: Colors.white,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  submit() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      getIt<ProfileCubit>().updateProfileDetails(
        firstName: _fullNameController.text.trim().split(" ").first,
        lastName: _fullNameController.text.trim().split(" ").last,
        phoneNumber: "$selectedCountryCode${_phoneNumberController.text}",
        countryCode: countryCode!,
        dialCode: selectedCountryCode,
      );
    }
  }

  checkFormValid() {
    setState(() {
      if (_formKey.currentState!.validate()) {
        isFormValid = true;
      } else {
        isFormValid = false;
      }
    });
  }

  String removeDialCode(String phoneNumber, String dialCode) {
    return phoneNumber.startsWith(dialCode)
        ? phoneNumber.replaceFirst(dialCode, '')
        : phoneNumber;
  }
}
