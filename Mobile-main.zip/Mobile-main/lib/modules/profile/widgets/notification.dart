import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/auth/sign_up/models/update_profile_model.dart';
import 'package:buzz_map/modules/profile/cubit/profile_cubit.dart';
import 'package:buzz_map/modules/profile/models/interest.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  User userProfileModel = getIt<User>();
  List<Interest> interest = [];
  bool isGeneralNotificationActive = false;
  bool isSoundNotificationActive = false;
  bool isAppUpdateActive = false;

  @override
  void initState() {
    isGeneralNotificationActive = userProfileModel.generalNotification;
    isSoundNotificationActive = userProfileModel.sound;
    isAppUpdateActive = userProfileModel.appUpdates;
    if (getIt.isRegistered<List<Interest>>()) {
      interest = getIt<List<Interest>>();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: BlocConsumer(
        bloc: getIt<ProfileCubit>(),
        listener: (context, state) {
          if (state is UpdatingNotificationSettings) {
            DialogUtil.showLoadingDialog(context);
          } else if (state is UpdateNotificationSettingsSuccess) {
            getIt<ProfileCubit>().getProfile();
          } else if (state is UpdateNotificationSettingsFailed) {
            DialogUtil.dismissLoadingDialog(context);
            NotificationMessage.showMessage(context,
                message: state.errorMessage, isError: true);
          } else if (state is GetProfileSuccess) {
            DialogUtil.dismissLoadingDialog(context);
            userProfileModel = state.user;
            userProfileModel.generalNotification = isGeneralNotificationActive;
            userProfileModel.sound = isSoundNotificationActive;
            userProfileModel.appUpdates = isAppUpdateActive;
            assignNotificationValue();
          } else if (state is GetProfileFailed) {}
        },
        builder: (context, state) {
          return SafeArea(
            top: true,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: Column(
                children: [
                  Row(
                    children: [
                      const CustomBackButton(),
                      Text(
                        S.current.notification,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                    ],
                  ),
                  20.h.verticalSpace,
                  BuzzMapDivider(
                    height: 1.h,
                  ),
                  39.h.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        S.current.generalNotification,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      Switch.adaptive(
                        value: isGeneralNotificationActive,
                        onChanged: (value) {
                          setState(() {
                            isGeneralNotificationActive = value;
                          });
                          getIt<ProfileCubit>().updateUserNotification(
                            updateProfileModel: UpdateProfileModel(
                                generalNotification:
                                    isGeneralNotificationActive,
                                sound: isSoundNotificationActive,
                                appUpdates: isSoundNotificationActive),
                          );
                        },
                        activeColor: AppColors.secondaryColor,
                      ),
                    ],
                  ),
                  10.h.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        S.current.sounds,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      Switch.adaptive(
                        value: isSoundNotificationActive,
                        onChanged: (value) {
                          setState(() {
                            isSoundNotificationActive = value;
                          });
                          getIt<ProfileCubit>().updateUserNotification(
                            updateProfileModel: UpdateProfileModel(
                                generalNotification:
                                    isGeneralNotificationActive,
                                sound: isSoundNotificationActive,
                                appUpdates: isSoundNotificationActive),
                          );
                        },
                        activeColor: AppColors.secondaryColor,
                      ),
                    ],
                  ),
                  10.h.verticalSpace,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        S.current.appUpdates,
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      Switch.adaptive(
                        value: isAppUpdateActive,
                        onChanged: (value) {
                          setState(() {
                            isAppUpdateActive = value;
                          });
                          getIt<ProfileCubit>().updateUserNotification(
                            updateProfileModel: UpdateProfileModel(
                                generalNotification:
                                    isGeneralNotificationActive,
                                sound: isSoundNotificationActive,
                                appUpdates: isSoundNotificationActive),
                          );
                        },
                        activeColor: AppColors.secondaryColor,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  assignNotificationValue() {
    isGeneralNotificationActive = userProfileModel.generalNotification;
    isSoundNotificationActive = userProfileModel.sound;
    isAppUpdateActive = userProfileModel.appUpdates;
  }
}
