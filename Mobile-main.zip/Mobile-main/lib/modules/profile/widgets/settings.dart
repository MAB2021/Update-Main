import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/profile/routes/route.dart';
import 'package:buzz_map/modules/profile/widgets/clickable_list_tile.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:buzz_map/shared/utils/logout.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/button.dart';
import 'package:buzz_map/shared/widgets/custom_back_button.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/buzz_map_divider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({super.key});

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        top: true,
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            children: [
              Row(
                children: [
                  const CustomBackButton(),
                  Text(
                    S.current.settings,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
              20.h.verticalSpace,
              BuzzMapDivider(
                height: 1.h,
              ),
              18.h.verticalSpace,
              ClickableListTile(
                  title: S.current.editProfile,
                  leadingIcon: isDarkMode
                      ? AssetResources.editProfile
                      : AssetResources.darkEditProfile,
                  onPressed: onEditProfile),
              ClickableListTile(
                  title: S.current.notification,
                  leadingIcon: isDarkMode
                      ? AssetResources.notification
                      : AssetResources.darkNotification,
                  onPressed: onNotification),
              ClickableListTile(
                  title: S.current.security,
                  leadingIcon: isDarkMode
                      ? AssetResources.security
                      : AssetResources.darkSecurity,
                  onPressed: onSecurity),
              ClickableListTile(
                  title: S.current.privacyPolicy,
                  leadingIcon: isDarkMode
                      ? AssetResources.privacyPolicy
                      : AssetResources.darkPrivacyPolicy,
                  onPressed: () {}),
              ClickableListTile(
                  title: S.current.helpCenter,
                  leadingIcon: isDarkMode
                      ? AssetResources.helpCenter
                      : AssetResources.darkHelpCenter,
                  onPressed: () {}),
              Row(
                children: [
                  Text(
                    S.current.lightMode,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const Spacer(),
                  Switch.adaptive(
                    value: !AdaptiveTheme.of(context).mode.isDark,
                    onChanged: (value) {
                      if (value) {
                        AdaptiveTheme.of(context).setLight();
                      } else {
                        AdaptiveTheme.of(context).setDark();
                      }
                    },
                    activeColor: Theme.of(context).primaryColorDark,
                  ),
                ],
              ),
              18.h.verticalSpace,
              BuzzMapDivider(
                height: 1.h,
              ),
              18.h.verticalSpace,
              InkWell(
                onTap: () => showModalBottomSheet(
                  context: context,
                  builder: (context) => ReusableBottomSheet(
                    content: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const BottomSheetGreyContainer(),
                        8.h.verticalSpace,
                        Center(
                          child: Text(
                            S.current.logout.capitalize(),
                            style: GoogleFonts.outfit(
                              color: AppColors.logoutColor,
                              fontSize: 20.sp,
                              fontWeight: FontWeight.w700,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        17.h.verticalSpace,
                        BuzzMapDivider(
                          height: 1.h,
                          dividerColor: AppColors.buzzMapGrayLight[20],
                        ),
                        9.h.verticalSpace,
                        Text(
                          S.current.areYourSureYouWantToLogout,
                          style:
                              Theme.of(context).textTheme.titleSmall!.copyWith(
                                    fontSize: 20.sp,
                                    fontWeight: FontWeight.w700,
                                  ),
                        ),
                        23.h.verticalSpace,
                        Row(
                          children: [
                            BuzzMapButton(
                                borderRadius: 30.r,
                                height: 53.h,
                                width: 156.w,
                                color: AppColors.buzzMapGrayLight[20],
                                child: Text(
                                  S.current.cancel,
                                  style: GoogleFonts.outfit(
                                    color: AppColors.buzzMapWhite,
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                                onPressed: () {
                                  getIt<NavigationService>().back();
                                }),
                            10.w.horizontalSpace,
                            BuzzMapButton(
                                borderRadius: 30.r,
                                height: 53.h,
                                width: 156.w,
                                color: Theme.of(context).primaryColorDark,
                                child: Text(
                                  S.current.yesLogout,
                                  style: GoogleFonts.outfit(
                                    color: AppColors.buzzMapWhite,
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                onPressed: () {
                                  LogoutUtil.logOutToSignIn();
                                }),
                          ],
                        )
                      ],
                    ),
                    minHeight: 225, // Customize the minimum height
                    initHeight: 225, // Customize the initial height
                    maxHeight: 600.0, // Customize the maximum height
                  ),
                ),
                child: Row(
                  children: [
                    BuzzMapAssetImage(
                      url: AssetResources.logout,
                      width: 20.w,
                      height: 20.h,
                    ),
                    11.w.horizontalSpace,
                    Text(
                      S.current.logout,
                      maxLines: 2,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.outfit(
                        color: AppColors.logoutColor,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onEditProfile() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.editProfileScreen);
  }

  void onNotification() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.notificationScreen);
  }

  void onSecurity() {
    getIt<NavigationService>().to(routeName: ProfileRoutes.securityScreen);
  }
}
