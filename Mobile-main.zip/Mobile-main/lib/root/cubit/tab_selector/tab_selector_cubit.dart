import 'package:buzz_map/root/model/tab_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class TabSelectorCubit extends Cubit<Tabs> {
  TabSelectorCubit() : super(Tabs.home);

  Future<void> selectTab(Tabs tab) async {
    emit(tab);
  }
}
