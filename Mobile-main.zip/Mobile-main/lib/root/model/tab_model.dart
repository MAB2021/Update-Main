import '../../generated/l10n.dart';

enum Tabs { home, events, location, calendar, profile }

extension TabExt on Tabs {
  String get name {
    switch (this) {
      case Tabs.home:
        return S.current.home;
      case Tabs.events:
        return S.current.events;
      case Tabs.location:
        return S.current.location;
      case Tabs.calendar:
        return S.current.calendar;
      case Tabs.profile:
        return S.current.profile;

      default:
        return "";
    }
  }
}
