class RootRoutes {
  static const initial = "/";
  static const home = "home";
  static const websiteScreen = "websiteScreen";
}
