import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/onboarding/routes/route.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../configs/app_configs.dart';
import '../shared/utils/storage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late bool isFirstTime;

  @override
  void initState() {
    isUserFirstTime().then((value) => isFirstTime = value);
    super.initState();
    _animationController =
        AnimationController(vsync: this, duration: const Duration(seconds: 4));

    _animationController.forward();
    _animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        getIt<NavigationService>().pushReplace(
            routeName: (isFirstTime)
                ? OnboardingRoutes.onboardingRoot
                : getIt.isRegistered<User>()
                    ? RootRoutes.home
                    : LoginRoutes.loginRoot);
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<bool> isUserFirstTime() async {
    var firstTime =
        await getIt<LocalStorageUtils>().read(AppConstants.isUserFirstTime);
    return firstTime == null;
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Scaffold(
      backgroundColor: isDarkMode
          ? AppColors.darkSecondaryColor
          : AppColors.lightScaffoldBackgroundColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 71.w),
        child: Center(
          child: BuzzMapAssetImage(
              url: isDarkMode
                  ? AssetResources.buzzmapLogo
                  : AssetResources.lightBuzzmapLogo,
              height: 104.72.h,
              width: 335.w,
              fit: BoxFit.scaleDown),
        ),
      ),
    );
  }
}
