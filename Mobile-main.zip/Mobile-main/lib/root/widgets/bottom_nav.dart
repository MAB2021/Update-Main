import 'dart:io';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/modules/calendar/cubit/calendar_cubit.dart';
import 'package:buzz_map/modules/calendar/root.dart';
import 'package:buzz_map/modules/events/cubit/events_cubit.dart';
import 'package:buzz_map/modules/events/root.dart';
import 'package:buzz_map/modules/home/root.dart';
import 'package:buzz_map/modules/location/root.dart';
import 'package:buzz_map/modules/profile/root.dart';
import 'package:buzz_map/root/cubit/tab_selector/tab_selector_cubit.dart';
import 'package:buzz_map/root/model/tab_model.dart';
import 'package:buzz_map/root/widgets/nav_bar_icon.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

ValueNotifier<LatLng?> userCurrentPosition = ValueNotifier(null);
ValueNotifier<String?> userCurrentAddress = ValueNotifier(null);
ValueNotifier<String?> userCurrentCountry = ValueNotifier(null);

class RootScreen extends StatefulWidget {
  final Tabs? currentTab;

  const RootScreen({super.key, this.currentTab});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  @override
  void initState() {
    getIt<TabSelectorCubit>().selectTab(widget.currentTab ?? Tabs.home);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TabSelectorCubit, Tabs>(
      bloc: getIt<TabSelectorCubit>(),
      builder: (context, state) {
        return Scaffold(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          body: Stack(
            children: [
              HomeRootWidget(
                isCurrent: state == Tabs.home,
                key: Key(Tabs.home.name),
              ),
              EventsRootWidget(
                isCurrent: state == Tabs.events,
                key: Key(Tabs.events.name),
              ),
              LocationRootWidget(
                isCurrent: state == Tabs.location,
                key: Key(Tabs.location.name),
              ),
              CalendarRootWidget(
                isCurrent: state == Tabs.calendar,
                key: Key(Tabs.calendar.name),
              ),
              ProfileRootWidget(
                isCurrent: state == Tabs.profile,
                key: Key(Tabs.profile.name),
              ),
            ],
          ),
          extendBody: false,
          bottomNavigationBar: Container(
            height: Platform.isIOS ? 85.h : 80.h,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
            ),
            padding: EdgeInsets.only(left: 18.w, right: 18.w, bottom: 15.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                InkWell(
                  onTap: () => getIt<TabSelectorCubit>().selectTab(Tabs.home),
                  child: NavBarItem(
                      label: S.of(context).home,
                      activeIcon: AssetResources.activeHome,
                      inactiveIcon: AssetResources.inactiveHome,
                      lightActiveIcon: AssetResources.lightActiveHome,
                      lightInactiveIcon: AssetResources.lightInactiveHome,
                      isActive: state == Tabs.home),
                ),
                InkWell(
                  onTap: () {
                    getIt<TabSelectorCubit>().selectTab(Tabs.events);
                    getIt<EventsCubit>().getCategories();
                  },
                  // {
                  //   // ,
                  //   // showExchangeModal(getIt<NavigationService>()
                  //   //     .navigatorKey
                  //   //     .currentContext!);
                  // },
                  child: NavBarItem(
                      label: S.of(context).events,
                      activeIcon: AssetResources.activeEvent,
                      inactiveIcon: AssetResources.inactiveEvent,
                      lightActiveIcon: AssetResources.lightActiveEvent,
                      lightInactiveIcon: AssetResources.lightInactiveEvent,
                      isActive: state == Tabs.events),
                ),
                InkWell(
                  onTap: () {
                    getIt<TabSelectorCubit>().selectTab(Tabs.location);
                  },
                  child: NavBarItem(
                      label: S.of(context).location,
                      activeIcon: AssetResources.activeLocation,
                      inactiveIcon: AssetResources.inactiveLocation,
                      lightActiveIcon: AssetResources.lightActiveLocation,
                      lightInactiveIcon: AssetResources.lightInactiveLocation,
                      isActive: state == Tabs.location),
                ),
                InkWell(
                  onTap: () {
                    getIt<CalendarCubit>().getEvents(DateTime.now(),
                        DateTime.now().add(const Duration(days: 30 * 13)));
                    getIt<TabSelectorCubit>().selectTab(Tabs.calendar);
                  },
                  child: NavBarItem(
                      label: S.of(context).settings,
                      activeIcon: AssetResources.activeCalendar,
                      inactiveIcon: AssetResources.inactiveCalendar,
                      lightActiveIcon: AssetResources.lightActiveCalendar,
                      lightInactiveIcon: AssetResources.lightInactiveCalendar,
                      isActive: state == Tabs.calendar),
                ),
                InkWell(
                  onTap: () =>
                      getIt<TabSelectorCubit>().selectTab(Tabs.profile),
                  child: NavBarItem(
                      label: S.of(context).profile,
                      activeIcon: AssetResources.activeProfile,
                      inactiveIcon: AssetResources.inactiveProfile,
                      lightActiveIcon: AssetResources.lightActiveProfile,
                      lightInactiveIcon: AssetResources.lightInactiveProfile,
                      isActive: state == Tabs.profile),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
