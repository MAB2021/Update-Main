import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NavBarItem extends StatefulWidget {
  final String label;
  final bool hasPending;
  final String activeIcon;
  final String inactiveIcon;
  final String lightActiveIcon;
  final String lightInactiveIcon;
  final bool isActive;
  const NavBarItem({
    Key? key,
    required this.label,
    required this.isActive,
    this.hasPending = false,
    required this.activeIcon,
    required this.inactiveIcon,
    required this.lightActiveIcon,
    required this.lightInactiveIcon,
  }) : super(key: key);

  @override
  State<NavBarItem> createState() => _NavBarItemState();
}

class _NavBarItemState extends State<NavBarItem> {
  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
      child: BuzzMapAssetImage(
        url: !isDarkMode
            ? widget.isActive
                ? widget.lightActiveIcon
                : widget.lightInactiveIcon
            : widget.isActive
                ? widget.activeIcon
                : widget.inactiveIcon,
        width: 24.w,
        height: 24.h,
      ),
    );
  }
}
