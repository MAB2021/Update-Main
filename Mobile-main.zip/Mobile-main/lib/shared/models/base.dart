abstract class BaseModel {
  Map<String, dynamic> toJson();
  static fromJson() {}
}
