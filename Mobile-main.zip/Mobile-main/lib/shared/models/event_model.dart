import 'dart:convert';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';

EventModel eventModelFromJson(String str) =>
    EventModel.fromJson(json.decode(str));

String eventModelToJson(EventModel data) => json.encode(data.toJson());

class EventModel {
  final String eventName;
  final String eventId;
  final String eventDescription;
  final DateTime eventStartDate;
  final double eventLongitude;
  final double eventLatitude;
  final String eventAddress;
  final String eventImage;
  final String? eventInfo;
  final String eventCategory;
  final num ratings;
  final int attending;
  final bool isActive;
  final num id;
  bool isBookmarked;
  final num? heatMap;
  final num distance;
  final bool hideTime;

  EventModel({
    required this.eventName,
    required this.eventId,
    required this.eventDescription,
    required this.eventStartDate,
    required this.eventLongitude,
    required this.eventLatitude,
    required this.eventAddress,
    required this.eventImage,
    this.eventInfo,
    required this.eventCategory,
    required this.ratings,
    required this.attending,
    required this.isActive,
    required this.id,
    required this.isBookmarked,
    this.heatMap = 0,
    this.distance = 0,
    this.hideTime = false,
  });

  factory EventModel.fromJson(Map<String, dynamic> json) => EventModel(
        eventName: json["event_name"],
        eventId: json["event_id"],
        eventDescription: json["event_description"],
        eventStartDate: DateTime.parse(json["event_start_date"]),
        eventLongitude: json["event_longitude"].toDouble(),
        eventLatitude: json["event_latitude"].toDouble(),
        eventAddress: json["event_address"],
        eventImage: json["event_image"],
        eventInfo: json["event_info"],
        eventCategory: json["event_category"],
        ratings: json["ratings"].toDouble(),
        attending: json["attending"],
        isActive: json["is_active"],
        id: json["id"],
        isBookmarked: json["is_bookmarked"] ?? true,
        heatMap: (json["heat_map"] == 0.0 || json["heat_map"] == null)
            ? null
            : json["heat_map"],
        distance: json["distance"] ?? 0,
        hideTime: json["hide_time"] ?? false,
      );

  Map<String, dynamic> toJson() => {
        "event_name": eventName,
        "event_id": eventId,
        "event_description": eventDescription,
        "event_start_date":
            "${eventStartDate.year.toString().padLeft(4, '0')}-${eventStartDate.month.toString().padLeft(2, '0')}-${eventStartDate.day.toString().padLeft(2, '0')}",
        "event_longitude": eventLongitude,
        "event_latitude": eventLatitude,
        "event_address": eventAddress,
        "event_image": eventImage,
        "event_info": eventInfo ?? eventDescription,
        "event_category": eventCategory,
        "ratings": ratings,
        "attending": attending,
        "is_active": isActive,
        "is_bookmarked": true,
      };

  Color getEventHitMapColor(num heatMap) {
    if (heatMap <= 39) {
      return AppColors.green;
    } else if (heatMap > 39 && heatMap <= 75) {
      return Colors.amber;
    } else {
      return AppColors.red;
    }
  }
}
