import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class NavigationService {
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  Future to({required String routeName}) {
    return navigatorKey.currentContext!.pushNamed(routeName);
  }

  Future toWithParameters({required String routeName, required Object args}) {
    return navigatorKey.currentContext!.pushNamed(routeName, extra: args);
  }

  void pushReplace({required String routeName, Object? args}) {
    return navigatorKey.currentContext!
        .pushReplacementNamed(routeName, extra: args);
  }

  void pushNamedAndRemoveUntil({required String routeName, Object? args}) {
    return navigatorKey.currentContext!.goNamed(routeName, extra: args);
  }

  void back() {
    return navigatorKey.currentContext!.pop();
  }

  void backWithParameters({required Object args}) {
    return navigatorKey.currentContext!.pop(args);
  }

  void clearAllTo({required String routeName}) {
    while (navigatorKey.currentContext!.canPop()) {
      navigatorKey.currentContext!.pop();
    }
    navigatorKey.currentContext!.pushReplacementNamed(routeName);
  }

  void clearAllToWithParameters(
      {required String routeName, required Object args}) {
    while (navigatorKey.currentContext!.canPop()) {
      navigatorKey.currentContext!.pop();
    }
    navigatorKey.currentContext!.pushReplacementNamed(routeName, extra: args);
  }
}
