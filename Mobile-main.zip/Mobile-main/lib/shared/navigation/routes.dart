// ignore: prefer_function_declarations_over_variables
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/auth/forgot_password/root.dart';
import 'package:buzz_map/modules/auth/forgot_password/routes/route.dart';
import 'package:buzz_map/modules/auth/forgot_password/widgets/otp_verification.dart';
import 'package:buzz_map/modules/auth/forgot_password/widgets/reset_password.dart';
import 'package:buzz_map/modules/auth/login/root.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/root.dart';
import 'package:buzz_map/modules/auth/sign_up/routes/route.dart';
import 'package:buzz_map/modules/auth/sign_up/widgets/otp_verification.dart';
import 'package:buzz_map/modules/bookmark/root.dart';
import 'package:buzz_map/modules/bookmark/routes/route.dart';
import 'package:buzz_map/modules/events/routes/route.dart';
import 'package:buzz_map/modules/events/widgets/create_event/create_event.dart';
import 'package:buzz_map/modules/events/widgets/create_event/event_address.dart';
import 'package:buzz_map/modules/home/routes/route.dart';
import 'package:buzz_map/modules/events/widgets/event_details.dart';
import 'package:buzz_map/modules/home/widgets/feature/all_featured.dart';
import 'package:buzz_map/modules/home/widgets/search/search.dart';
import 'package:buzz_map/modules/home/widgets/trending/all_trending/all_trending.dart';
import 'package:buzz_map/modules/interest/root.dart';
import 'package:buzz_map/modules/interest/routes/route.dart';
import 'package:buzz_map/modules/location/routes/route.dart';
import 'package:buzz_map/modules/location/widgets/search_location.dart';
import 'package:buzz_map/modules/location/widgets/select_location.dart';
import 'package:buzz_map/modules/notification/root.dart';
import 'package:buzz_map/modules/notification/routes/route.dart';
import 'package:buzz_map/modules/onboarding/root.dart';
import 'package:buzz_map/modules/onboarding/routes/route.dart';
import 'package:buzz_map/modules/profile/root.dart';
import 'package:buzz_map/modules/profile/routes/route.dart';
import 'package:buzz_map/modules/profile/widgets/change_password.dart';
import 'package:buzz_map/modules/profile/widgets/edit_profile.dart';
import 'package:buzz_map/modules/profile/widgets/notification.dart';
import 'package:buzz_map/modules/profile/widgets/security.dart';
import 'package:buzz_map/modules/profile/widgets/settings.dart';
import 'package:buzz_map/root/route/route.dart';
import 'package:buzz_map/root/splash_screen.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/widgets/website_launcher.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final GoRouter goRouter = GoRouter(
  navigatorKey: getIt<NavigationService>().navigatorKey,
  initialLocation: RootRoutes.initial,
  routes: <RouteBase>[
    GoRoute(
      path: RootRoutes.initial,
      name: RootRoutes.initial,
      // ,
      builder: (BuildContext context, GoRouterState state) {
        return const SplashScreen();
      },
      routes: <RouteBase>[
        GoRoute(
          path: RootRoutes.home,
          name: RootRoutes.home,
          builder: (_, state) {
            return const RootScreen();
          },
        ),
        GoRoute(
          path: OnboardingRoutes.onboardingRoot,
          name: OnboardingRoutes.onboardingRoot,
          builder: (_, state) {
            return const OnboardingRootScreen();
          },
        ),
        GoRoute(
          path: LoginRoutes.loginRoot,
          name: LoginRoutes.loginRoot,
          builder: (_, state) {
            return const LoginScreen();
          },
        ),
        GoRoute(
          path: SignUpRoutes.signUpRoot,
          name: SignUpRoutes.signUpRoot,
          builder: (_, state) {
            return const SignUpScreen();
          },
        ),
        GoRoute(
          path: SignUpRoutes.otpVerificationScreen,
          name: SignUpRoutes.otpVerificationScreen,
          builder: (_, state) {
            Map? args = state.extra as Map;
            return OTPVerificationScreen(
              signUpModel: args['signUpModel'],
            );
          },
        ),
        GoRoute(
          path: InterestRoutes.interestRoot,
          name: InterestRoutes.interestRoot,
          builder: (_, state) {
            return const InterestScreen();
          },
        ),
        GoRoute(
          path: ForgotPasswordRoutes.forgotPasswordRoot,
          name: ForgotPasswordRoutes.forgotPasswordRoot,
          builder: (_, state) {
            return const ForgotPasswordScreen();
          },
        ),
        GoRoute(
          path: ForgotPasswordRoutes.forgotPasswordOtpVerification,
          name: ForgotPasswordRoutes.forgotPasswordOtpVerification,
          builder: (_, state) {
            Map? args = state.extra as Map?;
            return ForgotPasswordOTPVerificationScreen(
              forgotPasswordModel: args?['forgotPasswordModel'],
            );
          },
        ),
        GoRoute(
          path: ForgotPasswordRoutes.resetPassword,
          name: ForgotPasswordRoutes.resetPassword,
          builder: (_, state) {
            Map? args = state.extra as Map?;
            return ResetPasswordScreen(
              email: args?['email'],
              phoneNumber: args?['phoneNumber'],
            );
          },
        ),
        GoRoute(
          path: ProfileRoutes.profileRoot,
          name: ProfileRoutes.profileRoot,
          builder: (_, state) {
            return const ProfileScreen();
          },
        ),
        GoRoute(
          path: ProfileRoutes.settingScreen,
          name: ProfileRoutes.settingScreen,
          builder: (_, state) {
            return const SettingScreen();
          },
        ),
        GoRoute(
          path: ProfileRoutes.editProfileScreen,
          name: ProfileRoutes.editProfileScreen,
          builder: (_, state) {
            return const EditProfileScreen();
          },
        ),
        GoRoute(
          path: ProfileRoutes.notificationScreen,
          name: ProfileRoutes.notificationScreen,
          builder: (_, state) {
            return const NotificationSettingsScreen();
          },
        ),
        GoRoute(
          path: ProfileRoutes.securityScreen,
          name: ProfileRoutes.securityScreen,
          builder: (_, state) {
            return const SecurityScreen();
          },
        ),
        GoRoute(
          path: ProfileRoutes.changePasswordScreen,
          name: ProfileRoutes.changePasswordScreen,
          builder: (_, state) {
            return const ChangePasswordScreen();
          },
        ),
        GoRoute(
          path: NotificationRoutes.notificationRoot,
          name: NotificationRoutes.notificationRoot,
          builder: (_, state) {
            return const NotificationScreen();
          },
        ),
        GoRoute(
          path: BookmarkRoutes.bookmarkRoot,
          name: BookmarkRoutes.bookmarkRoot,
          builder: (_, state) {
            return const BookmarkRootScreen();
          },
        ),
        GoRoute(
          path: HomeRoutes.featured,
          name: HomeRoutes.featured,
          builder: (_, state) {
            Map? args = state.extra as Map?;
            return FeaturedScreen(
              eventModel: args?['eventModel'],
            );
          },
        ),
        GoRoute(
          path: HomeRoutes.trending,
          name: HomeRoutes.trending,
          builder: (_, state) {
            Map? args = state.extra as Map?;
            return AllTrendingScreen(
              isNearByLocation: args?['isNearByLocation'],
            );
          },
        ),
        GoRoute(
          path: HomeRoutes.search,
          name: HomeRoutes.search,
          builder: (_, state) {
            return const SearchScreen();
          },
        ),
        GoRoute(
          path: HomeRoutes.eventDetail,
          name: HomeRoutes.eventDetail,
          builder: (_, state) {
            Map? args = state.extra as Map?;
            return EventDetailScreen(
              eventModel: args?['eventModel'],
              eventId: args?['eventId'],
            );
          },
        ),
        GoRoute(
          path: LocationRoutes.selectLocation,
          name: LocationRoutes.selectLocation,
          builder: (_, state) {
            return const SelectLocationScreen();
          },
        ),
        GoRoute(
          path: LocationRoutes.searchLocation,
          name: LocationRoutes.searchLocation,
          builder: (_, state) {
            return const SearchLocationScreen();
          },
        ),
        GoRoute(
          path: EventsRoutes.createEventsRoot,
          name: EventsRoutes.createEventsRoot,
          builder: (_, state) {
            return const CreateEventScreen();
          },
        ),
        GoRoute(
          path: EventsRoutes.eventAddressSearchScreen,
          name: EventsRoutes.eventAddressSearchScreen,
          builder: (_, state) {
            return const EventAddressSearchScreen();
          },
        ),
        GoRoute(
          path: RootRoutes.websiteScreen,
          name: RootRoutes.websiteScreen,
          builder: (_, state) {
            Map? args = state.extra as Map;
            return WebsiteScreen(
              url: args['url'],
              pageTitle: args['pageTitle'],
            );
          },
        ),
      ],
    )
  ],
);
