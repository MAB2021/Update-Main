import 'package:buzz_map/shared/utils/debouncer.dart';
import 'package:buzz_map/shared/utils/logout.dart';
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import '../utils/storage.dart';

enum HeaderContentType { formType, jsonType }

class HeaderInterceptor extends Interceptor {
  final bool hasToken;
  final HeaderContentType contentType;
  final Dio dio;

  HeaderInterceptor({
    required this.hasToken,
    this.contentType = HeaderContentType.jsonType,
    required this.dio,
  });

  @override
  Future<void> onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    if (hasToken) {
      var token = "Bearer ${await UserTokenManager.getAccessToken()}";

      options.headers["Authorization"] = token;
    }
    options.headers["Content-Type"] = contentType == HeaderContentType.jsonType
        ? "application/json"
        : "multipart/form-data";
    return super.onRequest(options, handler);
  }

  @override
  onError(DioException err, ErrorInterceptorHandler handler) {
    UserTokenManager.getAccessToken().then((value) {
      if (value != null) {
        bool hasExpired = JwtDecoder.isExpired(value);
        if (hasExpired) {
          _redirectToLoginScreen();
        }
      }
    });
    super.onError(err, handler);
  }

  void _redirectToLoginScreen() {
    LogoutUtil.logOutToSignIn();
    if (GetIt.I.isRegistered<Debouncer>()) GetIt.I.unregister<Debouncer>();
  }
}
