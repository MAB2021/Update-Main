import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'model/notification_message.dart';

class LocalNotificationManager {
  /// Create a [AndroidNotificationChannel] for heads up notifications
  static const AndroidNotificationChannel _androidChannel =
      AndroidNotificationChannel(
    'high_importance_channel', // id
    'High Importance Notifications', // title
    // 'This channel is used for important notifications.', // description
    importance: Importance.high,
  );

  // static const iOSNotificationChannel

  static const _initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  static const _initializationSettingsIOs = DarwinInitializationSettings(
    requestSoundPermission: false,
    requestBadgePermission: false,
    requestAlertPermission: false,
    // onDidReceiveLocalNotification: onDidReceiveLocalNotification,
  );

  /// Initialize the [FlutterLocalNotificationsPlugin] package.
  static final FlutterLocalNotificationsPlugin
      _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  static void showNotification(NotificationMessage message) {
    _flutterLocalNotificationsPlugin.initialize(const InitializationSettings(
        android: _initializationSettingsAndroid,
        iOS: _initializationSettingsIOs));

    _flutterLocalNotificationsPlugin.show(
        0,
        message.title,
        message.body,
        NotificationDetails(
            android: AndroidNotificationDetails(
                _androidChannel.id, _androidChannel.name),
            iOS: const DarwinNotificationDetails(
              presentAlert: true,
              presentBadge: true,
              presentSound: true,
              badgeNumber: 1,
            )));
  }
}
