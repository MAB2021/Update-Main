import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'platform_specific_widget.dart';

class PlatformLoader
    extends PlatformWidget<CupertinoActivityIndicator, Widget> {
  final double radius;
  const PlatformLoader({super.key, this.radius = 20});

  @override
  Widget createAndroidWidget(BuildContext context) {
    return SizedBox(
      width: radius.r,
      height: radius.r,
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>((AppColors.secondaryColor)),
      ),
    );
  }

  @override
  CupertinoActivityIndicator createIosWidget(BuildContext context) {
    return CupertinoActivityIndicator(radius: (radius / 2).r);
  }
}
