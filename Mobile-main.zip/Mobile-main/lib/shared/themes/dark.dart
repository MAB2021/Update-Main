import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

ThemeData darkTheme = ThemeData.dark().copyWith(
  iconTheme: IconThemeData(size: 24.w, color: AppColors.primaryColor),
  scaffoldBackgroundColor: AppColors.primaryColor,
  primaryColor: AppColors.primaryColor,
  primaryColorDark: AppColors.secondaryColor,
  brightness: Brightness.light,
  visualDensity: VisualDensity.adaptivePlatformDensity,
  buttonTheme: ButtonThemeData(buttonColor: AppColors.primaryColor),
  tabBarTheme: TabBarTheme(
      labelPadding: EdgeInsets.symmetric(horizontal: 20.w),
      indicatorColor: AppColors.secondaryColor,
      indicatorSize: TabBarIndicatorSize.tab,
      indicator: BoxDecoration(
        borderRadius: BorderRadius.circular(81.r),
        color: AppColors.secondaryColor,
      ),
      dividerColor: Colors.transparent,
      splashFactory: NoSplash.splashFactory,
      unselectedLabelStyle: GoogleFonts.outfit(
        fontSize: 13.sp,
        fontWeight: FontWeight.w600,
        color: AppColors.buzzMapWhite,
      ),
      unselectedLabelColor: AppColors.buzzMapWhite,
      labelStyle: GoogleFonts.outfit(
        fontSize: 13.sp,
        fontWeight: FontWeight.w600,
        color: AppColors.buzzMapWhite,
      ),
      labelColor: AppColors.buzzMapWhite,
      tabAlignment: TabAlignment.start),
  textSelectionTheme:
      TextSelectionThemeData(cursorColor: AppColors.primaryColor),
  textTheme: TextTheme(
    titleLarge: GoogleFonts.outfit(
      fontSize: 32.sp,
      color: Colors.white,
      fontWeight: FontWeight.w800,
    ),
    titleMedium: GoogleFonts.outfit(
      fontSize: 16.sp,
      color: Colors.white,
      fontWeight: FontWeight.w400,
    ),
    titleSmall: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: Colors.white,
      fontWeight: FontWeight.w400,
    ),
    headlineLarge: GoogleFonts.outfit(
      fontSize: 20.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w700,
    ),
    headlineMedium: GoogleFonts.inter(
        fontSize: 20.sp,
        fontWeight: FontWeight.w700,
        color: AppColors.primaryColor),
    headlineSmall: GoogleFonts.outfit(
      color: Colors.white,
      fontSize: 13.sp,
    ),
    labelSmall: GoogleFonts.outfit(
      fontSize: 13.sp,
      color: Colors.white,
      fontWeight: FontWeight.w700,
    ),
    displayLarge: GoogleFonts.outfit(
      fontSize: 16.sp,
      color: Colors.white,
      fontWeight: FontWeight.w700,
    ),
    displayMedium: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: Colors.white,
      fontWeight: FontWeight.w600,
    ),
    displaySmall: GoogleFonts.outfit(
      fontSize: 13.sp,
      color: AppColors.buzzMapGrayLight[15],
      fontWeight: FontWeight.w500,
    ),
    bodyLarge: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: Colors.white,
      fontWeight: FontWeight.w600,
    ),
    bodyMedium: GoogleFonts.outfit(
      color: AppColors.secondaryColor,
      fontSize: 18.sp,
      fontWeight: FontWeight.w700,
    ),
    bodySmall: GoogleFonts.outfit(
      color: AppColors.buzzMapGrayLight[75],
      fontSize: 14.sp,
      fontWeight: FontWeight.w400,
    ),
  ),
  timePickerTheme: TimePickerThemeData(
    backgroundColor: AppColors.primaryColor, // Background color
    hourMinuteTextColor:
        AppColors.primaryColor, // Text color for hours and minutes
    dayPeriodBorderSide: BorderSide(
      color: AppColors.secondaryColor,
    ), // Border color for AM/PM
    dialHandColor: AppColors.primaryColor, // Color of the hour hand
    dialBackgroundColor: AppColors.secondaryColor,
    dialTextColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.secondaryColor
            : AppColors.primaryColor), // Text color on the clock dial
    hourMinuteColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.secondaryColor
            : AppColors.secondaryColor),
    hourMinuteTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),

    dayPeriodTextColor: AppColors.secondaryColor, // Text color for AM/PM
    dayPeriodTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),
    dialTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),

    dayPeriodColor: AppColors.primaryColor,
    entryModeIconColor: AppColors.secondaryColor,
    timeSelectorSeparatorColor:
        WidgetStateProperty.all(AppColors.secondaryColor),
    confirmButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    ),
    cancelButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.secondaryColor,
      hintStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.secondaryColor,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  datePickerTheme: DatePickerThemeData(
    backgroundColor: AppColors.primaryColor,
    surfaceTintColor: AppColors.primaryColor,
    headerBackgroundColor: AppColors.primaryColor,
    headerForegroundColor: AppColors.secondaryColor,
    dayBackgroundColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.secondaryColor
            : AppColors.primaryColor),
    dayForegroundColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.primaryColor
            : AppColors.secondaryColor),
    todayBackgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    todayForegroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
    yearBackgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    yearForegroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
    yearOverlayColor: WidgetStateProperty.all(AppColors.secondaryColor),
    rangeSelectionBackgroundColor: AppColors.buzzMapWhite,
    rangePickerBackgroundColor: AppColors.buzzMapWhite,
    rangePickerHeaderBackgroundColor: AppColors.buzzMapWhite,
    rangePickerHeaderForegroundColor: AppColors.primaryColor,
    rangePickerShadowColor: AppColors.primaryColor,
    confirmButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    ),
    cancelButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.secondaryColor),
    ),
    rangePickerHeaderHelpStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w500,
    ),
    rangePickerHeaderHeadlineStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w500,
    ),
    yearStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w500,
    ),
    headerHeadlineStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w500,
    ),
    headerHelpStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w500,
    ),
    dayStyle: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w400,
    ),
    weekdayStyle: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w400,
    ),
    inputDecorationTheme: InputDecorationTheme(
      hintStyle: GoogleFonts.outfit(
        fontSize: 14.sp,
        color: AppColors.secondaryColor,
        fontWeight: FontWeight.w400,
      ),
      labelStyle: GoogleFonts.outfit(
        fontSize: 14.sp,
        color: AppColors.secondaryColor,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  cupertinoOverrideTheme: CupertinoThemeData(
    primaryColor: AppColors.primaryColor,
    scaffoldBackgroundColor: AppColors.primaryColor,
    textTheme: CupertinoTextThemeData(
      dateTimePickerTextStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.buzzMapWhite,
        fontWeight: FontWeight.w400,
      ),
      pickerTextStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.buzzMapWhite,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  colorScheme: ColorScheme(
    brightness: Brightness.dark,
    primary: AppColors.primaryColor,
    onPrimary: AppColors.primaryColor,
    secondary: AppColors.primaryColor,
    onSecondary: AppColors.primaryColor,
    error: AppColors.errorRed,
    onError: AppColors.errorRed,
    surface: AppColors.primaryColor,
    onSurface: AppColors.primaryColor,
    primaryContainer: AppColors.primaryColor,
    onPrimaryContainer: AppColors.primaryColor,
    secondaryContainer: AppColors.primaryColor,
    onSecondaryContainer: AppColors.primaryColor,
  )
      .copyWith(surface: AppColors.primaryColor)
      .copyWith(error: AppColors.errorRed),
);
