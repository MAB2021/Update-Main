import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

ThemeData lightTheme = ThemeData.light().copyWith(
  iconTheme: IconThemeData(size: 24.w, color: AppColors.primaryColor),
  scaffoldBackgroundColor: AppColors.lightScaffoldBackgroundColor,
  primaryColor: AppColors.primaryColor,
  primaryColorDark: AppColors.darkSecondaryColor,
  brightness: Brightness.light,
  focusColor: AppColors.primaryColor,
  visualDensity: VisualDensity.adaptivePlatformDensity,
  tabBarTheme: TabBarTheme(
      labelPadding: EdgeInsets.symmetric(horizontal: 20.w),
      indicatorColor: AppColors.darkSecondaryColor,
      indicatorSize: TabBarIndicatorSize.tab,
      indicator: BoxDecoration(
        borderRadius: BorderRadius.circular(81.r),
        color: AppColors.darkSecondaryColor,
      ),
      dividerColor: Colors.transparent,
      splashFactory: NoSplash.splashFactory,
      unselectedLabelStyle: GoogleFonts.outfit(
        fontSize: 13.sp,
        fontWeight: FontWeight.w600,
        color: AppColors.primaryColor,
      ),
      unselectedLabelColor: AppColors.primaryColor,
      labelStyle: GoogleFonts.outfit(
        fontSize: 13.sp,
        fontWeight: FontWeight.w600,
        color: AppColors.buzzMapWhite,
      ),
      labelColor: AppColors.buzzMapWhite,
      tabAlignment: TabAlignment.start),
  textSelectionTheme:
      TextSelectionThemeData(cursorColor: AppColors.primaryColor),
  textTheme: TextTheme(
    titleLarge: GoogleFonts.outfit(
      fontSize: 32.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w800,
    ),
    titleMedium: GoogleFonts.outfit(
      fontSize: 16.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w400,
    ),
    titleSmall: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w400,
    ),
    headlineLarge: GoogleFonts.outfit(
      fontSize: 20.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w700,
    ),
    headlineMedium: GoogleFonts.outfit(
      fontSize: 20.sp,
      fontWeight: FontWeight.w700,
      color: AppColors.primaryColor,
    ),
    headlineSmall: GoogleFonts.outfit(
      color: Colors.black,
      fontSize: 13.sp,
    ),
    labelSmall: GoogleFonts.outfit(
      fontSize: 13.sp,
      color: AppColors.buzzMapGrayLight[15]!,
      fontWeight: FontWeight.w700,
    ),
    displayLarge: GoogleFonts.outfit(
      fontSize: 16.sp,
      color: AppColors.secondaryColor,
      fontWeight: FontWeight.w700,
    ),
    displayMedium: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w600,
    ),
    displaySmall: GoogleFonts.outfit(
      fontSize: 13.sp,
      color: AppColors.buzzMapGrayLight[85],
      fontWeight: FontWeight.w500,
    ),
    bodyLarge: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w600,
    ),
    bodyMedium: GoogleFonts.outfit(
      color: AppColors.primaryColor,
      fontSize: 18.sp,
      fontWeight: FontWeight.w700,
    ),
    bodySmall: GoogleFonts.outfit(
      color: AppColors.primaryColor,
      fontSize: 14.sp,
      fontWeight: FontWeight.w400,
    ),
  ),
  timePickerTheme: TimePickerThemeData(
    backgroundColor: AppColors.lightScaffoldBackgroundColor, // Background color
    hourMinuteTextColor:
        AppColors.buzzMapWhite, // Text color for hours and minutes
    dayPeriodBorderSide: BorderSide(
      color: AppColors.primaryColor,
    ), // Border color for AM/PM
    dialHandColor: AppColors.buzzMapWhite, // Color of the hour hand
    dialBackgroundColor: AppColors.primaryColor,
    dialTextColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.primaryColor
            : AppColors.buzzMapWhite), // Text color on the clock dial
    hourMinuteColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.primaryColor
            : AppColors.primaryColor),
    // hourMinuteColor: AppColors.primaryColor,
    hourMinuteTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),
    dayPeriodTextColor: AppColors.primaryColor, // Text color for AM/PM
    dayPeriodTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),
    dialTextStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.red,
      fontWeight: FontWeight.w600,
    ),
    dayPeriodColor: AppColors.buzzMapWhite,
    entryModeIconColor: AppColors.primaryColor,

    timeSelectorSeparatorColor: WidgetStateProperty.all(AppColors.primaryColor),
    confirmButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
    ),
    cancelButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
      foregroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.primaryColor,
      hintStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.primaryColor,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  datePickerTheme: DatePickerThemeData(
    dividerColor: AppColors.primaryColor,
    backgroundColor: AppColors.lightScaffoldBackgroundColor,
    surfaceTintColor: AppColors.lightScaffoldBackgroundColor,
    headerBackgroundColor: AppColors.lightScaffoldBackgroundColor,
    headerForegroundColor: AppColors.primaryColor,
    dayBackgroundColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.primaryColor
            : AppColors.buzzMapWhite),
    dayForegroundColor: WidgetStateColor.resolveWith((states) =>
        states.contains(WidgetState.selected)
            ? AppColors.buzzMapWhite
            : AppColors.primaryColor),
    todayBackgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    todayForegroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
    yearBackgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    yearForegroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
    yearOverlayColor: WidgetStateProperty.all(AppColors.primaryColor),
    rangePickerHeaderBackgroundColor: AppColors.primaryColor,
    rangePickerHeaderForegroundColor: AppColors.primaryColor,
    rangeSelectionBackgroundColor: AppColors.primaryColor,
    rangePickerBackgroundColor: AppColors.primaryColor,
    dayOverlayColor: WidgetStateProperty.all(AppColors.red),
    rangeSelectionOverlayColor: WidgetStateProperty.all(AppColors.primaryColor),
    rangePickerSurfaceTintColor: AppColors.primaryColor,
    confirmButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.primaryColor),
      foregroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
    ),
    cancelButtonStyle: ButtonStyle(
      backgroundColor: WidgetStateProperty.all(AppColors.buzzMapWhite),
      foregroundColor: WidgetStateProperty.all(AppColors.primaryColor),
    ),
    rangePickerShadowColor: AppColors.primaryColor,
    rangePickerHeaderHelpStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w500,
    ),
    rangePickerHeaderHeadlineStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w500,
    ),
    yearStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w500,
    ),
    dayStyle: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w400,
    ),
    weekdayStyle: GoogleFonts.outfit(
      fontSize: 14.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w400,
    ),
    headerHeadlineStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w500,
    ),
    headerHelpStyle: GoogleFonts.outfit(
      fontSize: 18.sp,
      color: AppColors.primaryColor,
      fontWeight: FontWeight.w500,
    ),
    inputDecorationTheme: InputDecorationTheme(
      hintStyle: GoogleFonts.outfit(
        fontSize: 14.sp,
        color: AppColors.primaryColor,
        fontWeight: FontWeight.w400,
      ),
      labelStyle: GoogleFonts.outfit(
        fontSize: 14.sp,
        color: AppColors.primaryColor,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  cupertinoOverrideTheme: CupertinoThemeData(
    primaryColor: AppColors.primaryColor,
    scaffoldBackgroundColor: AppColors.lightScaffoldBackgroundColor,
    textTheme: CupertinoTextThemeData(
      dateTimePickerTextStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.primaryColor,
        fontWeight: FontWeight.w400,
      ),
      pickerTextStyle: GoogleFonts.outfit(
        fontSize: 18.sp,
        color: AppColors.primaryColor,
        fontWeight: FontWeight.w400,
      ),
    ),
  ),
  colorScheme: ColorScheme(
          brightness: Brightness.light,
          primary: AppColors.lightScaffoldBackgroundColor,
          onPrimary: AppColors.lightScaffoldBackgroundColor,
          secondary: AppColors.lightScaffoldBackgroundColor,
          onSecondary: AppColors.lightScaffoldBackgroundColor,
          error: AppColors.errorRed,
          onError: AppColors.errorRed,
          surface: AppColors.lightScaffoldBackgroundColor,
          onSurface: AppColors.lightScaffoldBackgroundColor,
          primaryContainer: AppColors.lightScaffoldBackgroundColor,
          onPrimaryContainer: AppColors.lightScaffoldBackgroundColor,
          secondaryContainer: AppColors.lightScaffoldBackgroundColor,
          surfaceTint: AppColors.lightScaffoldBackgroundColor,
          onInverseSurface: AppColors.lightScaffoldBackgroundColor,
          onSecondaryContainer: AppColors.lightScaffoldBackgroundColor)
      .copyWith(surface: AppColors.lightScaffoldBackgroundColor)
      .copyWith(error: AppColors.errorRed),
);
