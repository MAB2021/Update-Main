// ignore_for_file: constant_identifier_names

class AssetResources {
  //!onboarding
  static const buzzmapLogo = "assets/images/onboarding/buzzmap.svg";
  static const lightBuzzmapLogo = "assets/images/onboarding/light_buzzmap.png";
  static const onboarding_one = "assets/images/onboarding/onboarding_one.png";
  static const onboarding_two = "assets/images/onboarding/onboarding_two.png";
  static const onboarding_three =
      "assets/images/onboarding/onboarding_three.png";
  static const onboarding_four = "assets/images/onboarding/onboarding_four.png";

  //!auth
  static const message = "assets/images/auth/message.svg";
  static const password = "assets/images/auth/password.svg";
  static const user = "assets/images/auth/user.svg";
  static const nigeria = "assets/images/auth/nigeria.svg";
  static const passwordVisible = "assets/images/auth/password_closed.svg";
  static const passwordNotVisible = "assets/images/auth/password_open.svg";
  static const darkPassword = "assets/images/auth/dark_password.svg";
  static const darkMessage = "assets/images/auth/dark_message.svg";
  static const darkPadlock = "assets/images/auth/dark_padlock.svg";
  static const whiteMessage = "assets/images/auth/white_message.svg";
  static const whitePadlock = "assets/images/auth/white_padlock.svg";

  //!profile
  static const settings = "assets/images/profile/settings.svg";
  static const darkSettings = "assets/images/profile/dark_setting.svg";
  static const editProfile = "assets/images/profile/user.svg";
  static const notification = "assets/images/profile/notification.svg";
  static const security = "assets/images/profile/security.svg";
  static const privacyPolicy = "assets/images/profile/privacy_policy.svg";
  static const helpCenter = "assets/images/profile/help_center.svg";
  static const blackArrow = "assets/images/profile/black_arrow.svg";
  static const arrow = "assets/images/profile/arrow.svg";
  static const edit = "assets/images/profile/pencil.svg";
  static const darkEdit = "assets/images/profile/dark_pencil.svg";
  static const logout = "assets/images/profile/logout.svg";
  static const blackCamera = "assets/images/profile/black_camera.svg";
  static const whiteCamera = "assets/images/profile/white_camera.svg";
  static const gallery = "assets/images/profile/gallery.svg";
  static const darkEditProfile = "assets/images/profile/dark_edit_profile.svg";
  static const darkNotification = "assets/images/profile/dark_notification.svg";
  static const darkSecurity = "assets/images/profile/dark_security.svg";
  static const darkPrivacyPolicy =
      "assets/images/profile/dark_privacy_policy.svg";
  static const darkHelpCenter = "assets/images/profile/dark_help_center.svg";

  //!navbar
  static const activeHome = "assets/images/bottom_nav/active/home.svg";
  static const activeEvent = "assets/images/bottom_nav/active/events.svg";
  static const activeLocation = "assets/images/bottom_nav/active/location.svg";
  static const activeCalendar = "assets/images/bottom_nav/active/calendar.svg";
  static const activeProfile = "assets/images/bottom_nav/active/profile.svg";
  static const inactiveHome = "assets/images/bottom_nav/inactive/home.svg";
  static const inactiveEvent = "assets/images/bottom_nav/inactive/events.svg";
  static const inactiveLocation =
      "assets/images/bottom_nav/inactive/location.svg";
  static const inactiveCalendar =
      "assets/images/bottom_nav/inactive/calendar.svg";
  static const inactiveProfile =
      "assets/images/bottom_nav/inactive/profile.svg";
  static const lightActiveHome =
      "assets/images/bottom_nav/active/light_home.svg";
  static const lightActiveEvent =
      "assets/images/bottom_nav/active/light_events.svg";
  static const lightActiveLocation =
      "assets/images/bottom_nav/active/light_location.svg";
  static const lightActiveCalendar =
      "assets/images/bottom_nav/active/light_calendar.svg";
  static const lightActiveProfile =
      "assets/images/bottom_nav/active/light_profile.svg";

  static const lightInactiveHome =
      "assets/images/bottom_nav/inactive/light_home.svg";
  static const lightInactiveEvent =
      "assets/images/bottom_nav/inactive/light_event.svg";
  static const lightInactiveLocation =
      "assets/images/bottom_nav/inactive/light_location.svg";
  static const lightInactiveCalendar =
      "assets/images/bottom_nav/inactive/light_calendar.svg";
  static const lightInactiveProfile =
      "assets/images/bottom_nav/inactive/light_profile.svg";

//!Shared
  static const backArrow = "assets/images/shared/back_arrow.svg";
  static const darkBackArrow = "assets/images/shared/dark_back_arrow.svg";
  static const noEvents = "assets/images/shared/no_events.svg";

  //!home
  static const whiteBell = "assets/images/home/white_bell.svg";
  static const blackBell = "assets/images/home/black_bell.svg";

  static const filter = "assets/images/home/filter.svg";
  static const location = "assets/images/home/location.svg";
  static const darkLocation = "assets/images/home/dark_location.svg";
  static const search = "assets/images/home/search.svg";
  static const darkSearch = "assets/images/home/dark_search.svg";
  static const sad = "assets/images/home/emoji-sad.svg";
  static const calendar = "assets/images/home/calendar.svg";
  static const purpleLocation = "assets/images/home/purple_location.svg";
  static const mapMarker = "assets/images/home/map_marker.png";
  static const shuffle = "assets/images/home/shuffle.svg";
  static const blackShuffle = "assets/images/home/black_shuffle.svg";
  static const purpleStar = "assets/images/home/purple_star.svg";
  static const editIcon = "assets/images/home/edit.svg";
  static const darkEditIcon = "assets/images/home/dark_edit.svg";
  static const arrowUp = "assets/images/home/arrow_up.svg";

  //!notifications
  static const card = "assets/images/notification/card.svg";
  static const discount = "assets/images/notification/discount.svg";
  static const blackLocation = "assets/images/notification/location.svg";
  static const wallet = "assets/images/notification/wallet.svg";
  static const notificationWhiteBell =
      "assets/images/notification/white_bell.svg";

//!Bookmark
  static const whiteBookmark = "assets/images/bookmark/white_bookmark.svg";
  static const blackBookmark = "assets/images/bookmark/black_bookmark.svg";
  static const emptyBookmark = "assets/images/bookmark/empty_bookmark.svg";
  static const plainBlackBookmark =
      "assets/images/bookmark/plain_black_bookmark.svg";
  static const plainWhiteBookmark =
      "assets/images/bookmark/plain_white_bookmark.svg";
  //!Event
  static const addEvent = "assets/images/event/add.svg";
  static const purpleAddEvent = "assets/images/event/purple_add.svg";
  static const dropDownIcon = "assets/images/event/grey_arrow_drown.svg";
}
