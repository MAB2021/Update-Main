import 'package:flutter/material.dart';

class AppColors {
  static Color lightScaffoldBackgroundColor = const Color(0xFFFEFEFE);
  static Color inputFieldBorderColor = const Color.fromARGB(0, 180, 174, 174);
  static Color inputErrorBorder = const Color.fromARGB(0, 204, 24, 12);
  static Map<int, Color> buzzMapGrayLight = const {
    10: Color(0xFF5A5D67),
    15: Color(0xFF686C73),
    20: Color(0xFF35383F),
    50: Color(0xFFF9F8FF),
    65: Color(0xFFF5F5F5),
    70: Color(0xFF424242),
    75: Color(0xFFE0E0E0),
    80: Color(0xFF808080),
    85: Color(0xFFA6A6A6),
    90: Color(0xFFF4F4F4),
    95: Color(0xFF979797)
  };
  static Color errorRed = const Color(0xFFFF3B30);
  static Color primaryColor = const Color(0XFF000302);
  static Color secondaryColor = const Color(0xFF731A5B);
  static Color darkSecondaryColor = const Color(0xFF731A5B);
  static Color inputFiledColor = const Color(0xFF1C2039);
  static Color lightInputFiledColor = const Color(0xFFFAFAFA);
  static Color buzzMapWhite = const Color(0XFFFFFFFF);
  static Color buzzMapGray = const Color(0xFF1C2144);
  static Color dividerColor = const Color(0xFF282C49);
  static Color logoutColor = const Color(0xFFFD3C4A);
  static Color buzzMapBottomNav = const Color(0xFF191E3E);
  static Color bottomSheet = const Color(0xFF181A20);
  static Color purple = const Color(0xFF380C72);
  static Color red = const Color(0xFFF6513B);
  static Color darkPurple = const Color(0xFF45539D);
  static Color green = const Color(0xFF4CAF50);
  static Color black = const Color(0xFF131313);
}
