import 'package:intl/intl.dart';
// ignore_for_file: unnecessary_null_comparison

extension CustomDoubleExtension on double {
  formatCurrency({String currencySymbol = '₦'}) {
    // return this == 0 ? '-' : '${currencySymbol ?? ''} ${money.format(this)}';
    return this == null
        ? '-'
        : ((currencySymbol != null ? ('$currencySymbol ') : '') +
            money.format(this));
  }
}

final money = NumberFormat("#,##0.00", "en_US");

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
  }

  String shortToLength(int length) {
    if (length > length) {
      return "${substring(0, length - 1)}...";
    }

    return this;
  }

  String get capitalizeFirstOfEach =>
      split(" ").map((str) => str.capitalize).join(" ");
}

extension IterableX<T> on Iterable<T> {
  T? firstWhereOrNull(bool Function(T) test) {
    T? firstItem;
    for (var item in this) {
      if (test(item)) {
        firstItem = item;
        break;
      }
    }
    return firstItem;
  }
}

String getDayOfMonthSuffix(int dayNum) {
  if (!(dayNum >= 1 && dayNum <= 31)) {
    throw Exception('Invalid day of month');
  }

  if (dayNum >= 11 && dayNum <= 13) {
    return 'th';
  }

  switch (dayNum % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
}

formatDate(DateTime date) {
  var suffix = "th";
  var digit = date.day % 10;
  if ((digit > 0 && digit < 4) && (date.day < 11 || date.day > 13)) {
    suffix = ["st", "nd", "rd"][digit - 1];
  }
  return DateFormat("EEEE, dd'$suffix' MMMM").format(date);
}

String formatStringDate(String inputDate) {
  DateTime dateTime =
      DateTime.parse(inputDate).toLocal(); // Convert to local time
  String formattedDate = DateFormat('d MMM, y').format(dateTime);
  String daySuffix = _getDaySuffix(dateTime.day);
  return formattedDate.replaceFirstMapped(RegExp(r'\b(\d+)\b'), (match) {
    return '${match.group(1)}$daySuffix';
  });
}

String formatDateTime(DateTime inputDateTime) {
  String formattedTime = DateFormat('hh:mm a').format(inputDateTime);
  return formattedTime;
}

String _getDaySuffix(int day) {
  if (day >= 11 && day <= 13) {
    return 'th';
  }
  switch (day % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
}

String formatDateString(String inputDate) {
  DateTime dateTime = DateTime.parse(inputDate);
  String monthAbbreviation = getMonthAbbreviation(dateTime.month);
  String daySuffix = _getDaySuffix(dateTime.day);
  String formattedDate =
      '$monthAbbreviation. ${dateTime.day}$daySuffix, ${dateTime.year}';
  return formattedDate;
}

String getMonthAbbreviation(int month) {
  switch (month) {
    case 1:
      return 'Jan';
    case 2:
      return 'Feb';
    case 3:
      return 'Mar';
    case 4:
      return 'Apr';
    case 5:
      return 'May';
    case 6:
      return 'Jun';
    case 7:
      return 'Jul';
    case 8:
      return 'Aug';
    case 9:
      return 'Sep';
    case 10:
      return 'Oct';
    case 11:
      return 'Nov';
    case 12:
      return 'Dec';
    default:
      return '';
  }
}

String formatTimeString(DateTime inputTime) {
  String formattedTime = DateFormat('h:mm:ssa')
      .format(inputTime); // Use "jm" pattern for 12-hour clock
  return formattedTime.toLowerCase(); // Convert to lowercase for "am" or "pm"
}

String convertDate(String dateString) {
  // Parse the original date string into a DateTime object
  DateTime dateTime = DateTime.parse(dateString);

  // Format the DateTime object into the desired string format
  String formattedDate = DateFormat('MMMM dd, yyyy').format(dateTime);

  return formattedDate;
}

String formatWeekDayTime(String dateTimeString) {
  DateTime dateTime = DateTime.parse(dateTimeString);
  
  // Format the date
  String formattedDate = DateFormat('EEEE, h:mma').format(dateTime);

  return formattedDate;
}