import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lottie/lottie.dart';
import '../../configs/app_startup.dart';
import '../navigation/navigation_service.dart';

class DialogUtil {
  static void showLoadingDialog(BuildContext context,
      {String? text, String? image}) {
    showGeneralDialog(
        barrierLabel:
            MaterialLocalizations.of(context).modalBarrierDismissLabel,
        barrierDismissible: false,
        transitionDuration: const Duration(milliseconds: 200),
        context: context,
        pageBuilder: (_, __, ___) {
          return Align(
            alignment: Alignment.center,
            child: Container(
              height: 72.h,
              width: 72.w,
              decoration: BoxDecoration(
                color: AppColors.buzzMapWhite,
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: LottieBuilder.asset("assets/json/loader.json"),
                  )
                ],
              ),
            ),
          );
        },
        transitionBuilder: (_, anim, __, child) {
          return SlideTransition(
            position: Tween(
              begin: const Offset(0, 1),
              end: const Offset(0, 0),
            ).animate(anim),
            child: child,
          );
        });
  }

  static void dismissLoadingDialog(BuildContext context) {
    Navigator.pop(context);
  }

  static void dismissWithNavigationService() {
    getIt<NavigationService>().back();
  }
}
