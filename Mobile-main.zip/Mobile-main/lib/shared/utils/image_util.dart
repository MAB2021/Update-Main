import 'dart:io';
import 'dart:math';
import 'package:flutter/foundation.dart';

class ImageUtil {
  Future<String> getFileSizeIfNeeded(String imagePath, int decimals) async {
    final File imageFile = File(imagePath);
    final int fileSizeInBytes = await imageFile.length();

    // Directly return the file size string
    return getSizeString(fileSizeInBytes, decimals);
  }

  String getSizeString(int bytes, int decimals) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (log(bytes) / log(1024)).floor();
    return '${(bytes / pow(1024, i)).toStringAsFixed(decimals)} ${suffixes[i]}';
  }

  Future<String> getFileSize(String filePath, int decimals) async {
    final File file = File(filePath);
    final int bytes = await file.length();
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = (log(bytes) / log(1024)).floor();
    debugPrint(
        '${(bytes / pow(1024, i)).toStringAsFixed(decimals)} ${suffixes[i]}');
    return '${(bytes / pow(1024, i)).toStringAsFixed(decimals)} ${suffixes[i]}';
  }
}
