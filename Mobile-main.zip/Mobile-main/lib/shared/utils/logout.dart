import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/auth/login/routes/route.dart';
import 'package:buzz_map/modules/profile/models/user.dart';
import 'package:buzz_map/root/widgets/bottom_nav.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/storage.dart';

class LogoutUtil {
  static logOutToSignIn() {
    clearUserData();
    getIt<NavigationService>().clearAllTo(routeName: LoginRoutes.loginRoot);
  }

  static sessionTimeOut() {
    clearUserData();
    getIt<NavigationService>().pushReplace(routeName: LoginRoutes.loginRoot);
  }

  static void clearUserData() async {
    // if (getIt.isRegistered<User>()) {
    //   getIt<SettingsCubit>().removeDeviceToken(getIt<User>().id!);
    // }

    userCurrentAddress.value = null;
    userCurrentPosition.value = null;
    userCurrentCountry.value = null;

    if (getIt.isRegistered<User>()) {
      getIt.unregister<User>();
    }
    getIt<LocalStorageUtils>().delete(AppConstants.userObject);
    Future.delayed(
        const Duration(seconds: 1), () => UserTokenManager.deleteAccessToken());
  }
}
