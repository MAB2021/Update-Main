// ignore_for_file: use_build_context_synchronously

import 'package:buzz_map/modules/location/utils/utils.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:map_launcher/map_launcher.dart';

openMapsSheet({
  required BuildContext context,
  required double longitude,
  required double latitude,
  required String address,
}) async {
  try {
    DialogUtil.showLoadingDialog(context);
    final availableMaps = await MapLauncher.installedMaps;
    var currentPosition = await determinePosition(context);
    DialogUtil.dismissLoadingDialog(context);

    showModalBottomSheet(
      context: context,
      builder: (_) {
        return SizedBox(
          height: 200.h,
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(vertical: 20.h),
            child: Column(
              children: [
                for (var map in availableMaps)
                  Theme(
                    data: ThemeData(
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                    ),
                    child: ListTile(
                      onTap: () => map.showDirections(
                          // originTitle: order.value?.addresses?[0].address,
                          destinationTitle: address,
                          origin: Coords(currentPosition.latitude,
                              currentPosition.longitude),
                          destination: Coords(latitude, longitude),
                          directionsMode: DirectionsMode.driving),
                      title: Text(
                        map.mapName,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(5.r),
                        child: BuzzMapAssetImage(
                          url: map.icon,
                          height: 30.w,
                          width: 30.w,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  } catch (e) {
    debugPrint(e.toString());
  }
}
