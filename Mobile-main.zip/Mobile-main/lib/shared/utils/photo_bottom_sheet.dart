import 'dart:io';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:image_picker/image_picker.dart';
import '../../generated/l10n.dart';

final picker = ImagePicker();

void showPhotoDialogBottomSheet(
    {required BuildContext context, required Function(File) onCompleted}) {
  showModalBottomSheet(
    useRootNavigator: true,
    isDismissible: true,
    isScrollControlled: true,
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.r), topRight: Radius.circular(20.r)),
    ),
    builder: (context) {
      bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SizedBox(
          height: 200.h,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              10.h.verticalSpace,
              const BottomSheetGreyContainer(),
              29.h.verticalSpace,
              GestureDetector(
                onTap: () => _openCamera(context, onCompleted),
                child: title(
                    context,
                    isDarkMode
                        ? AssetResources.whiteCamera
                        : AssetResources.blackCamera,
                    S.of(context).takePhoto),
              ),
              SizedBox(height: 40.h),
              GestureDetector(
                onTap: () => _openGallery(context, onCompleted),
                child: title(
                    context, AssetResources.gallery, S.of(context).openGallery),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Widget title(BuildContext context, String iconUrl, String title) => Row(
      children: [
        BuzzMapAssetImage(
          url: iconUrl,
        ),
        SizedBox(width: 10.w),
        Text(title, style: Theme.of(context).textTheme.titleSmall),
      ],
    );
void _openCamera(BuildContext context, Function(File) onCompleted) async {
  var picture = await picker.pickImage(
    source: ImageSource.camera,
  );
  if (picture == null) {
    if (context.mounted) {
      NotificationMessage.showMessage(context,
          message: S.of(context).noFileSelected, isError: true);
    }
  } else {
    onCompleted(File(picture.path));
  }
  getIt<NavigationService>().back();
}

void _openGallery(BuildContext context, Function(File) onCompleted) async {
  var picture = await picker.pickImage(source: ImageSource.gallery);
  if (picture == null) {
    if (context.mounted) {
      NotificationMessage.showMessage(context,
          message: S.of(context).noFileSelected, isError: true);
    }
  } else {
    onCompleted(File(picture.path));
  }
  getIt<NavigationService>().back();
}
