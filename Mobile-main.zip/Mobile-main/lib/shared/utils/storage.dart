import 'dart:convert';
import 'package:buzz_map/configs/app_configs.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/base.dart';

class LocalStorageUtils {
  final SharedPreferences sharedPreferences;

  LocalStorageUtils(this.sharedPreferences);
  write(String key, String value) async {
    sharedPreferences.setString(key, value);
  }

  String? read(String key) {
    return sharedPreferences.getString(key);
  }

  delete(String key) async {
    return sharedPreferences.remove(key);
  }

  saveList<T extends BaseModel>(String key, T value) async {
    var data = json.encode(value.toJson());
    var list = readList(key);

    sharedPreferences.setStringList(key, [...list, data]);
  }

  saveListString(String key, List<String> value) async {
    var list = readList(key);
    sharedPreferences.setStringList(key, [...list, ...value]);
  }

  List<String> readList(String key) {
    return (sharedPreferences.getStringList(key)) ?? [];
  }

  saveObject<T extends BaseModel>(String key, T value) async {
    var data = json.encode(value.toJson());
    sharedPreferences.setString(key, data);
  }

  dynamic readObject<T extends BaseModel>(String key) {
    var prefData = sharedPreferences.getString(key);
    if (prefData != null) {
      var data = json.decode(prefData);
      return data;
    }
    return null;
  }

  dynamic readListObject<T extends BaseModel>(String key) {
    var prefData = sharedPreferences.getStringList(key);
    if (prefData != null) {
      var data = prefData.map((e) => json.decode(e)).toList();
      return data;
    }
    return null;
  }

  Future<void> saveMap(String key, Map<String, dynamic> value) async {
    String data = json.encode(value);
    sharedPreferences.setString(key, data);
  }

  dynamic getMap(String key) {
    String? data = sharedPreferences.getString(key);
    if (data != null) {
      return json.decode(data);
    }
    return null;
  }

  //Set and get bool value
  Future<void> setBool(String key, bool value) async {
    sharedPreferences.setBool(key, value);
  }

  bool? getBool(String key) {
    return sharedPreferences.getBool(key);
  }
}

class UserTokenManager {
  static Future<String?> getAccessToken() async {
    var storage = const FlutterSecureStorage();
    var token = await storage.read(key: AppConstants.userToken);
    return token;
  }

  static Future<void> deleteAccessToken() async {
    var storage = const FlutterSecureStorage();
    await storage.delete(key: AppConstants.userToken);
  }

  static Future<String> insertAccessToken(String token) async {
    var storage = const FlutterSecureStorage();
    await storage.write(key: AppConstants.userToken, value: token);
    return token;
  }

  static Future<String?> getRefreshAccessToken() async {
    var storage = const FlutterSecureStorage();
    var token = await storage.read(key: AppConstants.refreshToken);
    return token;
  }

  static Future<void> deleteRefreshAccessToken() async {
    var storage = const FlutterSecureStorage();
    await storage.delete(key: AppConstants.refreshToken);
  }

  static Future<String> insertRefreshAccessToken(String token) async {
    var storage = const FlutterSecureStorage();
    await storage.write(key: AppConstants.refreshToken, value: token);
    return token;
  }
}
