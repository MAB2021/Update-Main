import 'package:buzz_map/configs/app_configs.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:cloudinary_public/cloudinary_public.dart';

class UploadImage {
  static Future<String?> uploadImage({required String imagePath}) async {
    final cloudinary = CloudinaryPublic(
        AppConstants.cloudinaryUrl, AppConstants.cloudinaryUploadPresetName,
        cache: false);
    try {
      CloudinaryResponse response = await cloudinary.uploadFile(
        CloudinaryFile.fromFile(
          imagePath,
          resourceType: CloudinaryResourceType.Image,
        ),
      );
      if (response.secureUrl.isNotEmpty) {
        return response.secureUrl;
      } else {
        return S.current.anErrorOccurred;
      }
    } on CloudinaryException catch (e) {
      return e.responseString;
    }
  }
}
