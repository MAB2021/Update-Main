import '../../generated/l10n.dart';

class Validator {
  static String? validateMobile(String? value) {
    String pattern = r'(^(?:[+0]9)?[0-9]{10,11}$)';
    RegExp regExp = RegExp(pattern);

    if (value == null || value.isEmpty) {
      return S.current.enterYourPhoneNumber;
    } else if (!regExp.hasMatch(value)) {
      return S.current.enterValidPhoneNumber;
    }

    return null;
  }

  // static String? isAdult(String? birthDateString) {
  //   if (birthDateString == null) return S.current.dobRequired;

  //   var birthDate = DateFormat('yyyy-MM-dd').parse(birthDateString);
  //   var today = DateTime.now();

  //   final difference = today.difference(birthDate).inDays;

  //   final year = difference / 365;

  //   if (birthDateString.isEmpty) {
  //     return S.current.dobRequired;
  //   } else if (year < 18) {
  //     return S.current.mustBeAbove;
  //   }
  //   return null;
  // }

  // bool validateStructure(String value) {
  //   String pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$';
  //   RegExp regExp = RegExp(pattern);
  //   return regExp.hasMatch(value);
  // }

  static String? validatePassword(value) {
    var pattern = r'^(?=.*?[a-z])(?=.*?[0-9]).{8,}$';
    RegExp regex = RegExp(pattern);
    if (value == null) {
      return S.current.passwordRequired;
    } else if (value.isEmpty) {
      return S.current.passwordRequired;
    } else if (!value.contains(RegExp(r'[a-z]'))) {
      return S.current.lowerCaseRequired;
    } else if (!value.contains(RegExp(r'[0-8]'))) {
      return S.current.numberRequired;
    } else if (!regex.hasMatch(value)) {
      return S.current.passwordRequirement;
    }

    return null;
  }

  static String? validateConfirmPassword(value, compareWith) {
    var pattern = r'^(?=.*?[a-z])(?=.*?[0-9]).{8,}$';
    RegExp regex = RegExp(pattern);
    if (value != null) {
      if (value.isEmpty) {
        return S.current.passwordRequired;
      } else if (!value.contains(RegExp(r'[a-z]'))) {
        return S.current.lowerCaseRequired;
      } else if (!value.contains(RegExp(r'[0-8]'))) {
        return S.current.numberRequired;
      } else if (!regex.hasMatch(value)) {
        return S.current.passwordRequirement;
      }

      if (value != compareWith) {
        return S.current.passwordDoesNotMatch;
      }
    }
    return null;
  }

  // static String? validateDate(fieldValue) {
  //   if (fieldValue == null || fieldValue.toString().isEmpty) {
  //     return S.current.startDateRequired;
  //   } else {
  //     String dateInWords = fieldValue;
  //     var dateInWordToDateTime =
  //         DateFormat('MMMM d, y', 'en_US').parse(dateInWords);
  //
  //     final currentDate = DateTime.now();
  //
  //     var difference = dateInWordToDateTime.difference(currentDate).inDays;
  //     if (difference < 0) {
  //       return S.current.invalidDateSelected;
  //     } else if (dateInWords.isEmpty) {
  //       return S.current.startDateRequired;
  //     }
  //   }
  //   return null;
  // }

  // static String? ConfirmPasswordValidator(String? password, String? value) {
  //   if (password == null) return '';
  //   if (value == null) return 'confirm password is required';

  //   value = value.trim();

  //   String? validate = validatePassword(value);
  //   if (validate != null) return validate;
  //   if (password == value) return null;
  //   return 'Passwords do not match';
  // }

  // static String? validateFirstName(fullName) {
  //   String pattern = r'^[a-z A-Z,.\-]+$';
  //   RegExp regExp = RegExp(pattern);
  //   if (fullName != null) {
  //     if (fullName!.length == 0) {
  //       return S.current.enterValidName;
  //     } else if (!regExp.hasMatch(fullName)) {
  //       return S.current.enterValidName;
  //     }
  //   }

  //   return null;
  // }

  static String? validateFullName(fullName) {
    String pattern = r'^[a-z A-Z,.\-]+$';
    RegExp regExp = RegExp(pattern);
    List<String> splitName = fullName.split(" ");
    if (fullName.length == 0) {
      return S.current.validFullName;
    }
    if (!regExp.hasMatch(fullName)) {
      return S.current.enterValidName;
    }

    if (splitName.length < 2) {
      return S.current.validFullName;
    }
    if (splitName.length > 1 && splitName[1].trim().isEmpty) {
      return S.current.validFullName;
    }

    return null;
  }

  // static String? validateLastName(fullName) {
  //   String pattern = r'^[a-z A-Z,.\-]+$';
  //   RegExp regExp = RegExp(pattern);
  //   if (fullName != null) {
  //     if (fullName!.length == 0) {
  //       return S.current.lastName;
  //     } else if (!regExp.hasMatch(fullName)) {
  //       return S.current.enterValidName;
  //     }
  //   }
  //
  //   return null;
  // }

  static String? validateEmail(value) {
    var pattern =
        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+";
    RegExp regex = RegExp(pattern);
    if (value != null) {
      if (value!.isEmpty) {
        return S.current.pleaseEnterEmail;
      } else if (!regex.hasMatch(value)) {
        return S.current.pleaseEnterAValidEmail;
      }
    }

    return null;
  }

  //Validate OTP
  static String? validateOTP(value) {
    if (value == null) {
      return S.current.otpIsRequired;
    } else if (value.isEmpty) {
      return S.current.otpIsRequired;
    } else if (value.length < 6) {
      return S.current.otpMustBe6Digits;
    } else if (value.length > 6) {
      return S.current.otpMustBe6Digits;
    }
    return null;
  }

  static String? requiredValidator<T>(T? value, String? message) {
    if (value == null || value.toString().isEmpty) {
      if (message != null) {
        return "$message is required";
      } else {
        return S.current.thisFieldIsRequired;
      }
    }

    return null;
  }
}
