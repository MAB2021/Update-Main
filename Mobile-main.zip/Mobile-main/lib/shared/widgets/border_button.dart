import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class BorderCustomButton extends StatelessWidget {
  final String imageUrl;
  final Function onPressed;
  const BorderCustomButton(
      {super.key, required this.imageUrl, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onPressed(),
      child: Container(
        alignment: Alignment.center,
        height: 50.h,
        width: 50.w,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.r),
            shape: BoxShape.rectangle,
            color: AppColors.inputFiledColor),
        child: BuzzMapAssetImage(
          url: imageUrl,
        ),
      ),
    );
  }
}
