import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class ReusableBottomSheet extends StatefulWidget {
  final Widget content;
  final double minHeight;
  final double initHeight;
  final double maxHeight;
  final Color? backgroundColor;

  const ReusableBottomSheet({
    super.key,
    required this.content,
    this.minHeight = 100.0,
    this.initHeight = 300.0,
    this.maxHeight = 600.0,
    this.backgroundColor,
  });

  @override
  State<ReusableBottomSheet> createState() => _ReusableBottomSheetState();
}

class _ReusableBottomSheetState extends State<ReusableBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.initHeight.h,
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
      decoration: BoxDecoration(
        // color: widget.backgroundColor ?? Colors.black,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0.r),
          topRight: Radius.circular(30.0.r),
        ),
      ),
      child: widget.content,
    );
  }
}
