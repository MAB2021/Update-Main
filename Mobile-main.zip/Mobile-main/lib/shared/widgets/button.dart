import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class BuzzMapButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final Widget? child;
  final String? text;
  final double? fontSize;
  final double? verticalPadding;
  final double? horizontalPadding;
  final Color? color, borderColor, textColor;
  final double? borderRadius;
  final double? width;
  final double? height;
  final double? borderWidth;
  const BuzzMapButton({
    super.key,
    this.onPressed,
    this.child,
    this.text,
    this.fontSize,
    this.color,
    this.borderColor,
    this.textColor,
    this.verticalPadding,
    this.horizontalPadding,
    this.borderRadius,
    this.width,
    this.height,
    this.borderWidth,
    // required this.width,
  })  : assert(text != null || child != null);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        elevation: WidgetStateProperty.resolveWith<double>((states) => 0),
        fixedSize: WidgetStateProperty.resolveWith<Size>(
          (states) =>
              Size(width ?? MediaQuery.of(context).size.width, height ?? 62.h),
        ),
        shape: WidgetStateProperty.resolveWith<OutlinedBorder>((states) {
          Color borderColor = Colors.transparent;
          // states.contains(MaterialState.disabled) || onPressed == null
          //     ? Colors.transparent
          //     : color ?? AppColors.primaryColor;
          return RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(borderRadius ?? 10.r),
            side: BorderSide(
                width: borderWidth ?? 2,
                color: this.borderColor ?? borderColor),
          );
        }),
        backgroundColor: WidgetStateProperty.resolveWith<Color>(
          (Set<WidgetState> states) {
            if (states.contains(WidgetState.disabled) || onPressed == null) {
              return (color ?? AppColors.secondaryColor.withOpacity(0.3));
            }
            return color ?? AppColors.secondaryColor;
          },
        ),
      ),
      onPressed: onPressed,
      child: text != null
          ? Text(
              text!,
              style: GoogleFonts.outfit(
                color: textColor ?? Colors.white,
                fontSize: fontSize ?? 16.sp,
                fontWeight: FontWeight.w700,
              ),
            )
          : child,
    );
  }
}
