import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'cached_image.dart';

class BuzzMapAssetImage extends StatelessWidget {
  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final String? package;
  const BuzzMapAssetImage(
      {super.key,
      required this.url,
      this.width,
      this.height,
      this.fit = BoxFit.none,
      this.package});

  @override
  Widget build(BuildContext context) {
    if (getImageType(url) == ImageType.svg) {
      return SvgPicture.asset(
        url,
        height: height,
        width: width,
        fit: fit,
        package: package,
      );
    } else {
      return Image.asset(
        url,
        height: height,
        width: width,
        fit: fit,
        package: package,
      );
    }
  }

  ImageType getImageType(String url) {
    var path = url.split(".");
    String ext = path[path.length - 1];
    if (ext == "svg") return ImageType.svg;
    return ImageType.png;
  }
}
