import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';

class BuzzMapDivider extends StatelessWidget {
  final double height;
  final double? thickness;
  final Color? dividerColor;
  final double? startIndent;
  final double? endIndent;
  final bool dotted;
  const BuzzMapDivider(
      {super.key,
      this.height = 0,
      this.thickness,
      this.dotted = false,
      this.dividerColor,
      this.startIndent,
      this.endIndent});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Divider(
      height: height,
      thickness: thickness ?? 1,
      indent: startIndent,
      endIndent: endIndent,
      color: dividerColor ??
          (isDarkMode
              ? AppColors.dividerColor
              : AppColors.buzzMapGrayLight[90]),
    );
  }
}
