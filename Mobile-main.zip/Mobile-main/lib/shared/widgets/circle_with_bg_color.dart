import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CircleCustomButton extends StatelessWidget {
  final String imageUrl;
  final Function onPressed;
  final double height;
  final double width;
  const CircleCustomButton(
      {super.key,
      required this.imageUrl,
      required this.onPressed,
      this.height = 40,
      this.width = 40});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return InkWell(
      onTap: () => onPressed(),
      child: Container(
        alignment: Alignment.center,
        height: height.h,
        width: width.w,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            color:
                isDarkMode ? AppColors.black : AppColors.lightInputFiledColor),
        child: BuzzMapAssetImage(
          url: imageUrl,
        ),
      ),
    );
  }
}
