import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomBackButton extends StatelessWidget {
  const CustomBackButton({super.key});

  @override
  Widget build(BuildContext context) {
    bool isDark = AdaptiveTheme.of(context).mode.isDark;
    return Padding(
      padding: EdgeInsets.only(right: 20.w),
      child: GestureDetector(
        onTap: () {
          getIt<NavigationService>().back();
        },
        child: BuzzMapAssetImage(
          url: isDark ? AssetResources.backArrow : AssetResources.darkBackArrow,
          height: 30.h,
          width: 30.w,
        ),
      ),
    );
  }
}
