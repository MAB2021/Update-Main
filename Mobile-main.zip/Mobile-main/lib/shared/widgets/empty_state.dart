import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EmptyStateWidget extends StatelessWidget {
  final String imageUrl;
  final String title;
  final String? subTitle;
  final double topPadding;
  const EmptyStateWidget(
      {super.key,
      required this.imageUrl,
      required this.title,
      this.subTitle,
      this.topPadding = 100});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Column(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        topPadding.h.verticalSpace,
        Container(
          height: 150.h,
          width: 150.w,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isDarkMode
                  ? AppColors.secondaryColor
                  : AppColors.primaryColor),
          child: BuzzMapAssetImage(
            url: imageUrl,
          ),
        ),
        30.h.verticalSpace,
        Text(
          title,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: isDarkMode ? Colors.white : AppColors.primaryColor,
              ),
        ),
        15.h.verticalSpace,
        Text(
          subTitle ?? "",
          style: Theme.of(context).textTheme.titleSmall!.copyWith(
                fontSize: 14.sp,
                fontWeight: FontWeight.w700,
                color: isDarkMode ? Colors.white : AppColors.primaryColor,
              ),
        ),
      ],
    );
  }
}
