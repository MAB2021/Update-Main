import 'dart:developer';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/configs/app_startup.dart';
import 'package:buzz_map/modules/bookmark/cubit/bookmark_cubit.dart';
import 'package:buzz_map/shared/models/event_model.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/utils/dialog.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:buzz_map/shared/widgets/events/added_to_bookmark.dart';
import 'package:buzz_map/shared/widgets/events/removed_from_bookmark.dart';
import 'package:buzz_map/shared/widgets/notification_message.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AddAndRemoveBookmarkWidget extends StatefulWidget {
  final EventModel eventModel;
  final int index;
  final String widgetIdentifier;
  final double? height, width;
  const AddAndRemoveBookmarkWidget(
      {super.key,
      required this.eventModel,
      required this.index,
      required this.widgetIdentifier,
      this.height,
      this.width});

  @override
  State<AddAndRemoveBookmarkWidget> createState() =>
      _AddAndRemoveBookmarkWidgetState();
}

class _AddAndRemoveBookmarkWidgetState
    extends State<AddAndRemoveBookmarkWidget> {
  late BookmarkCubit bookmarkCubit;

  @override
  void initState() {
    bookmarkCubit = getIt<BookmarkCubit>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    bool isDark = AdaptiveTheme.of(context).mode.isDark;
    return BlocConsumer(
      bloc: getIt<BookmarkCubit>(),
      listener: (context, state) {
        if (state is AddEventBookmarkLoading &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.showLoadingDialog(context);
          log('AddEventBookmarkLoading: ${widget.eventModel.toJson()} ${widget.index}');
        } else if (state is AddEventBookmarkSuccess &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.dismissLoadingDialog(context);
          widget.eventModel.isBookmarked = true;
          addedToBookmark(context);
        } else if (state is AddEventBookmarkFailed &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.dismissLoadingDialog(context);
          NotificationMessage.showMessage(context,
              message: state.errorMessage, isError: true);
        } else if (state is RemoveEventBookmarkLoading &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.showLoadingDialog(context);
          log('RemoveEventBookmarkLoading: ${widget.eventModel.toJson()} ${widget.index}');
        } else if (state is RemoveEventBookmarkSuccess &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.dismissLoadingDialog(context);
          widget.eventModel.isBookmarked = false;
          removedFromBookmark(context);
        } else if (state is RemoveEventBookmarkFailed &&
            widget.widgetIdentifier == state.widgetIdentifier &&
            widget.eventModel.eventId == state.id &&
            widget.index == state.index) {
          DialogUtil.dismissLoadingDialog(context);
          removedFromBookmark(context);
        }
      },
      builder: (context, state) {
        return GestureDetector(
          onTap: () {
            widget.eventModel.isBookmarked
                ? bookmarkCubit.removeEventBookmark(
                    eventModel: widget.eventModel,
                    id: widget.eventModel.id,
                    index: widget.index,
                    widgetIdentifier: widget.widgetIdentifier)
                : bookmarkCubit.addEventToBookmark(
                    eventModel: widget.eventModel,
                    index: widget.index,
                    widgetIdentifier: widget.widgetIdentifier);
          },
          child: BuzzMapAssetImage(
            url: isDark
                ? AssetResources.whiteBookmark
                : AssetResources.blackBookmark,
            // widget.eventModel.isBookmarked
            //     ? isDark
            //         ? AssetResources.whiteBookmark
            //         : AssetResources.blackBookmark
            //     : AssetResources.bookmark,
            height: widget.height ?? 18.h,
            width: widget.height ?? 18.w,
            // fit: BoxFit.scaleDown,
          ),
        );
      },
    );
  }

  addedToBookmark(context) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const AddedToBookmarkWidget();
        });
  }

  removedFromBookmark(context) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return const RemovedFromBookmarkWidget();
        });
  }
}
