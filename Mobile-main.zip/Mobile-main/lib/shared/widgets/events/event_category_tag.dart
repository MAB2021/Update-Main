import 'package:buzz_map/shared/utils/custom_extension.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EventCategoryTagWidget extends StatelessWidget {
  final String name;
  const EventCategoryTagWidget({super.key, required this.name});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      height: 20.h,
      constraints: BoxConstraints(maxWidth: 70.w),
      // width: 50.w,
      padding: EdgeInsets.symmetric(
        horizontal: 5.w,
      ),
      margin: EdgeInsets.symmetric(vertical: 8.h),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).primaryColorDark,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(81.r),
      ),
      child: Text(name.capitalize(),
          style: Theme.of(context).textTheme.displayMedium!.copyWith(
                fontSize: 10.sp,
              ),
          textAlign: TextAlign.center),
    );
  }
}
