import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class EventDateWidget extends StatelessWidget {
  final String date;
  const EventDateWidget({super.key, required this.date});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 24.h,
      width: 110.w,
      margin: EdgeInsets.only(right: 6.w, top: 10.h),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppColors.primaryColor,
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Text(
        date,
        style: GoogleFonts.outfit(
          color: Colors.white,
          fontSize: 14.sp,
          fontWeight: FontWeight.w600,
        ),
        textAlign: TextAlign.center,
        maxLines: 1,
      ),
    );
  }
}
