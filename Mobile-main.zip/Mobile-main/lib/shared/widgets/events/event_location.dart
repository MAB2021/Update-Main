import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class EventAddressWidget extends StatelessWidget {
  final String address;
  const EventAddressWidget({super.key, required this.address});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return Row(
      children: [
        BuzzMapAssetImage(
          url: isDarkMode
              ? AssetResources.location
              : AssetResources.darkLocation,
          height: 18.h,
          width: 18.w,
        ),
        9.w.horizontalSpace,
        SizedBox(
          width: 100.w,
          child: Text(
            address,
            style: Theme.of(context)
                .textTheme
                .titleSmall!
                .copyWith(fontSize: 10.sp),
            maxLines: 1,
          ),
        ),
        9.w.horizontalSpace,
      ],
    );
  }
}
