import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class EventRatingTagWidget extends StatelessWidget {
  final num ratings;
  const EventRatingTagWidget({super.key, required this.ratings});

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      // height: 20.h,
      constraints: BoxConstraints(maxWidth: 70.w),
      // width: 50.w,
      padding: EdgeInsets.symmetric(horizontal: 5.w),
      margin: EdgeInsets.symmetric(vertical: 8.h),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).primaryColorDark,
          width: 0.5,
        ),
        borderRadius: BorderRadius.circular(81.r),
      ),
      child: Text(ratings.toStringAsFixed(2),
          style: GoogleFonts.outfit(
            color: AppColors.red,
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
          ),
          textAlign: TextAlign.center),
    );
  }
}
