import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';

class NetworkSignalIndicator extends StatelessWidget {
  final num signalStrength; // Range from 0 to 100

  const NetworkSignalIndicator({super.key, required this.signalStrength});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(4, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 2.0),
          width: 10.0,
          height: (index + 1) * 10.0,
          decoration: BoxDecoration(
            color: getEventHitMapColor(signalStrength, index, context),
            borderRadius: BorderRadius.circular(2.0),
          ),
        );
      }),
    );
  }
}

Color getEventHitMapColor(num heatMap, int barIndex, BuildContext context) {
  final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
  final defaultColor =
      isDarkMode ? Colors.white : AppColors.buzzMapGrayLight[95]!;

  if (heatMap <= 39) {
    return Colors.green;
  } else if (heatMap > 39 && heatMap <= 59) {
    return barIndex < 3 ? Colors.amber : defaultColor;
  } else {
    return barIndex == 0 ? Colors.red : defaultColor;
  }
}
