import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class NumberAttendingEvent extends StatelessWidget {
  final int value;
  const NumberAttendingEvent({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    return Text(
      "$value + Going",
      style: GoogleFonts.outfit(
        color: AppColors.buzzMapWhite,
        fontSize: 10.sp,
        fontWeight: FontWeight.w400,
      ),
    );
  }
}
