import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/asset_images.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet.dart';
import 'package:buzz_map/shared/widgets/bottom_sheet_grey_container.dart';
import 'package:buzz_map/shared/widgets/buzz_map_asset_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class RateEventDialogWidget extends StatelessWidget {
  final String message;
  const RateEventDialogWidget({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = AdaptiveTheme.of(context).mode.isDark;
    return ReusableBottomSheet(
      minHeight: 88.41.h,
      initHeight: 88.41.h,
      maxHeight: 400,
      content: Column(
        children: [
          const BottomSheetGreyContainer(),
          26.39.h.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                message,
                style: Theme.of(context).textTheme.titleMedium!.copyWith(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w700,
                    ),
                textAlign: TextAlign.center,
              ),
              BuzzMapAssetImage(
                url: isDarkMode
                    ? AssetResources.plainWhiteBookmark
                    : AssetResources.plainBlackBookmark,
                height: 24.h,
                width: 24.w,
              )
            ],
          ),
        ],
      ),
    );
  }
}
