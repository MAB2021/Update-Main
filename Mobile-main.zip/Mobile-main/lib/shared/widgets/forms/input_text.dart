import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../utils/custom_style.dart';

// ignore: must_be_immutable
class InputText extends StatefulWidget {
  final String? labelText;
  final TextInputType keyboardType;
  final bool isPassword;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onEditingComplete;
  final FormFieldSetter<String>? onSaved;
  final FocusNode? focusNode;
  final VoidCallback? onTap;
  final TextInputAction? textInputAction;
  final String? textPlaceholder;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final Widget? prefixWidget;
  String? initialValue;
  final bool enabled;
  final TextEditingController? controller;
  final bool isOtp;
  final int maxOtpLength;
  final bool isFilled;
  // final Color? backgroundColor;
  final InputBorder? inputBorder;
  final bool isHomepageSearch;
  InputText({
    super.key,
    this.labelText,
    this.keyboardType = TextInputType.text,
    this.isPassword = false,
    this.validator,
    this.onChanged,
    this.onEditingComplete,
    this.onSaved,
    this.focusNode,
    this.onTap,
    this.textInputAction = TextInputAction.next,
    this.textPlaceholder,
    this.suffixIcon,
    this.prefixIcon,
    this.prefixWidget,
    this.initialValue,
    this.enabled = true,
    this.controller,
    this.isOtp = false,
    this.maxOtpLength = 6,
    this.isFilled = false,
    // this.backgroundColor,
    this.inputBorder,
    this.isHomepageSearch = false,
  });

  @override
  _InputTextState createState() => _InputTextState();
}

class _InputTextState extends State<InputText> {
  late FocusNode _focusNode;
  @override
  void initState() {
    _focusNode = widget.focusNode ?? FocusNode();
    _focusNode.addListener(() {
      if (!_focusNode.hasFocus) {
        setState(() {});
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedPadding(
        duration: const Duration(milliseconds: 600),
        // padding: formFieldPadding,
        padding: EdgeInsets.zero,
        child: TextFormField(
          // key: Key(DateTime.now().toString()),
          cursorColor: AdaptiveTheme.of(context).mode.isDark
              ? AppColors.lightInputFiledColor
              : AppColors.inputFiledColor,
          style: Theme.of(context).textTheme.headlineSmall,
          initialValue: widget.initialValue,
          controller: widget.controller,
          enabled: widget.enabled,
          autocorrect: false,
          onTapOutside: (event) => setState(() {
            _focusNode.unfocus();
          }),
          focusNode: _focusNode,
          inputFormatters: widget.isOtp
              ? [
                  LengthLimitingTextInputFormatter(widget.maxOtpLength),
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ]
              : null,
          decoration: InputDecoration(
            suffixIcon: widget.suffixIcon,
            prefixIcon: widget.prefixWidget,
            prefix: widget.prefixIcon,
            // prefixIconConstraints: BoxConstraints(maxHeight: 40.w),
            labelText: widget.labelText,
            labelStyle: labelStyle(context),
            hintText: widget.textPlaceholder,
            hintStyle: Theme.of(context).textTheme.displaySmall,
            isDense: true,
            filled: widget.isFilled,
            fillColor: !AdaptiveTheme.of(context).mode.isDark
                ? AppColors.lightInputFiledColor
                : AppColors.primaryColor,
            contentPadding: widget.isHomepageSearch
                ? null
                : EdgeInsets.symmetric(vertical: 22.h, horizontal: 23.w),
            focusedBorder: widget.inputBorder ?? AppStyles.focusedBorder,
            disabledBorder: widget.inputBorder ?? AppStyles.focusBorder,
            enabledBorder: widget.inputBorder ?? AppStyles.focusBorder,
            errorBorder: widget.inputBorder ?? AppStyles.focusErrorBorder,
            focusedErrorBorder: AppStyles.focusErrorBorder,
            errorStyle: errorTextStyle(context),
          ),
          textInputAction: widget.textInputAction,
          keyboardType: widget.keyboardType,
          obscureText: widget.isPassword,
          onSaved: widget.onSaved,
          onEditingComplete: () {
            setState(() {
              FocusScope.of(context).unfocus();
            });
            if (widget.onEditingComplete != null) widget.onEditingComplete!();
          },
          onChanged: widget.onChanged,
          validator: widget.validator,
          onTap: () {
            setState(() {
              FocusScope.of(context).requestFocus(_focusNode);
            });
            if (widget.onTap != null) widget.onTap!();
          },
        ));
  }

  TextStyle? labelStyle(context) {
    return _focusNode.hasFocus
        ? Theme.of(context).textTheme.labelSmall
        : Theme.of(context).textTheme.displaySmall;
  }

  errorTextStyle(context) => GoogleFonts.outfit(
        color: AppColors.errorRed,
        fontSize: 10.sp,
      );
}
