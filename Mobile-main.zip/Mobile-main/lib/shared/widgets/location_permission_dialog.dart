import 'package:buzz_map/shared/platform_widgets/platform_dialog.dart';
import 'package:flutter/material.dart';
import '../../generated/l10n.dart';

void showDialogMessage(BuildContext context,
    {required String title,
    required String content,
    VoidCallback? onTapButton}) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return PlatformAlertDialog(
        content: Text(content),
        title: Text(title),
        actions: [
          TextButton(onPressed: onTapButton, child: Text(S.current.ok))
        ],
      );
    },
  );
}
