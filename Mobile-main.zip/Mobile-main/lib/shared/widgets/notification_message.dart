import 'package:buzz_map/shared/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class NotificationMessage {
  static void showMessage(
    BuildContext context, {
    required String message,
    required bool isError,
  }) {
    SnackBar snackBar = SnackBar(
      backgroundColor: isError ? AppColors.errorRed : AppColors.green,
      behavior: SnackBarBehavior.floating,
      dismissDirection: DismissDirection.horizontal,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
      margin: EdgeInsets.only(bottom: 625.0.h, left: 20.w, right: 20.w),
      content: Text(
        message,
        style: GoogleFonts.outfit(
          color: Colors.white,
          fontSize: 12.sp,
          fontWeight: FontWeight.w300,
        ),
      ),
      showCloseIcon: false,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }
}

class _Messenger extends StatelessWidget {
  final String message;
  final bool isErrorMessage;
  final VoidCallback onCloseTap;

  const _Messenger({
    required this.message,
    required this.isErrorMessage,
    required this.onCloseTap,
  });

  @override
  Widget build(BuildContext context) {
    SnackBar snackBar = SnackBar(
      backgroundColor: isErrorMessage ? AppColors.errorRed : AppColors.green,
      behavior: SnackBarBehavior.floating,
      dismissDirection: DismissDirection.horizontal,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
      margin: EdgeInsets.only(bottom: 625.0.h, left: 20.w, right: 20.w),
      content: Text(
        message,
        style: GoogleFonts.outfit(
          color: Colors.white,
          fontSize: 12.sp,
          fontWeight: FontWeight.w300,
        ),
      ),
      showCloseIcon: false,
    );
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    return SnackBar(
      backgroundColor: isErrorMessage ? AppColors.errorRed : AppColors.green,
      behavior: SnackBarBehavior.floating,
      dismissDirection: DismissDirection.horizontal,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
      ),
      margin: EdgeInsets.only(bottom: 625.0.h, left: 20.w, right: 20.w),
      content: Text(
        message,
        style: GoogleFonts.outfit(
          color: Colors.white,
          fontSize: 12.sp,
          fontWeight: FontWeight.w300,
        ),
      ),
      showCloseIcon: false,
    );
    // ;
  }
}
