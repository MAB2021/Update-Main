import 'package:buzz_map/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class OtpTimerCountdownWidget extends StatelessWidget {
  final bool showResendButton;
  final int start;
  const OtpTimerCountdownWidget(
      {super.key, required this.showResendButton, required this.start});

  @override
  Widget build(BuildContext context) {
    final String minutes = (start ~/ 60).toString().padLeft(2, '0');
    final String seconds = (start % 60).toString().padLeft(2, '0');
    return !showResendButton
        ? RichText(
            text: TextSpan(
              children: <TextSpan>[
                TextSpan(
                  text: " $minutes:$seconds ",
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w700,
                      ),
                ),
                TextSpan(
                  text: S.of(context).seconds,
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w700,
                      ),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          )
        : const SizedBox.shrink();
  }
}
