import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:pinput/pinput.dart';

class BuzzMapPinWidget extends StatelessWidget {
  final int length;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onCompleted;
  final TextEditingController? controller;
  final String? Function(String?)? validator;

  const BuzzMapPinWidget({
    super.key,
    this.onChanged,
    this.validator,
    this.controller,
    this.onCompleted,
    required this.length,
  });

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 47.5.w,
      height: 60.w,
      textStyle: Theme.of(context).textTheme.headlineMedium,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5.r),
        border: Border.all(color: Theme.of(context).primaryColorDark),
      ),
    );
    return Pinput(
      length: length,
      onChanged: onChanged,
      controller: controller,
      // separator: 16.horizontalSpace,
      defaultPinTheme: defaultPinTheme,
      validator: validator,
      hapticFeedbackType: HapticFeedbackType.lightImpact,
      onCompleted: onCompleted,
      cursor: const SizedBox.shrink(),
      preFilledWidget: Text(
        '|',
        style: GoogleFonts.outfit(
          fontSize: 16.sp,
          color: const Color(0xFFD9D9D9),
        ),
      ),
      focusedPinTheme: defaultPinTheme.copyWith(
        decoration: defaultPinTheme.decoration!.copyWith(
          color: Colors.white,
          border: Border.all(color: Theme.of(context).primaryColorDark),
        ),
      ),
      submittedPinTheme: defaultPinTheme,
      textInputAction: TextInputAction.done,
      keyboardType: TextInputType.number,
    );
  }
}
