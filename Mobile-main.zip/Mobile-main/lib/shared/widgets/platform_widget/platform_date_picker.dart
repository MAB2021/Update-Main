import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:buzz_map/generated/l10n.dart';
import 'package:buzz_map/shared/navigation/navigation_service.dart';
import 'package:buzz_map/shared/themes/dark.dart';
import 'package:buzz_map/shared/themes/light.dart';
import 'package:buzz_map/shared/utils/colors.dart';
import 'package:buzz_map/shared/widgets/forms/input_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get_it/get_it.dart';
import 'package:intl/intl.dart';
import 'platform_specific_widget.dart';

class PlatformDatePicker extends PlatformWidget<IOSDatePicker, DatePicker> {
  final ValueChanged<String>? onChange;
  final FormFieldValidator<String>? validator;
  final FormFieldSetter<String>? onSaved;
  final TextEditingController controller;
  final Color? backgroundColor;
  final String? dateFormat;
  final String? hint;
  final DateTime? endDate;
  final DateTime? startDate;

  const PlatformDatePicker({
    super.key,
    this.onChange,
    this.endDate,
    this.startDate,
    this.validator,
    this.onSaved,
    this.backgroundColor,
    this.dateFormat,
    this.hint,
    required this.controller,
  });

  @override
  DatePicker createAndroidWidget(BuildContext context) {
    return DatePicker(
      controller: controller,
      onChange: onChange,
      validator: validator,
      onSaved: onSaved,
      hint: hint,
      backgroundColor: backgroundColor,
      dateFormat: dateFormat,
      endDate: endDate,
      startDate: startDate,
    );
  }

  @override
  IOSDatePicker createIosWidget(BuildContext context) {
    return IOSDatePicker(
      onChange: onChange,
      controller: controller,
      validator: validator,
      onSaved: onSaved,
      hint: hint,
      backgroundColor: backgroundColor,
      endDate: endDate,
      startDate: startDate,
      dateFormat: dateFormat,
    );
  }
}

class DatePicker extends StatefulWidget {
  final ValueChanged<String>? onChange;
  final TextEditingController controller;
  final FocusNode? focusNode;
  final FormFieldValidator<String>? validator;
  final FormFieldSetter<String>? onSaved;
  final Color? backgroundColor;
  final String? dateFormat;
  final String? hint;
  final DateTime? endDate;
  final DateTime? startDate;

  const DatePicker({
    super.key,
    required this.onChange,
    required this.controller,
    this.dateFormat,
    this.focusNode,
    this.validator,
    this.hint,
    this.onSaved,
    this.backgroundColor,
    required this.endDate,
    required this.startDate,
  });

  @override
  State<DatePicker> createState() => _DatePickerState();
}

class _DatePickerState extends State<DatePicker> {
  DateFormat formatter = DateFormat("yyyy-MM-dd HH:mm");
  DateTime? _date;

  @override
  void initState() {
    formatter = DateFormat(widget.dateFormat ?? "yyyy-MM-dd HH:mm");
    super.initState();
  }

  Future<DateTime?> getDate(context) async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: widget.endDate ?? DateTime(3000),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      builder: (BuildContext context, Widget? child) {
        return Theme(
            data: AdaptiveTheme.of(context).mode.isDark
                ? darkTheme.copyWith(
                    colorScheme: ColorScheme.light(
                      primary: AppColors.secondaryColor,
                      onSurface: AppColors.secondaryColor,
                      surface: AppColors.secondaryColor,
                    ),
                  )
                : lightTheme.copyWith(
                    colorScheme: ColorScheme.light(
                      primary: AppColors.primaryColor,
                      onSurface: AppColors.primaryColor,
                      surface: AppColors.primaryColor,
                    ),
                  ),
            child: child!);
      },
    );
    if (date == null) return null;

    final time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
        initialEntryMode: TimePickerEntryMode.dialOnly);
    if (time == null) return null;

    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        _date = await getDate(context);

        if (_date != null) {
          setState(() {
            var date = formatter.format(_date!);
            widget.controller.text = date;
            widget.onChange?.call(_date.toString());
          });
        }
      },
      child: InputText(
        controller: widget.controller,
        labelText: S.of(context).eventStartDate,
        isFilled: true,
        keyboardType: TextInputType.multiline,
        enabled: false,
        validator: widget.validator,
        onSaved: widget.onSaved,
      ),
    );
  }
}

class IOSDatePicker extends StatefulWidget {
  final ValueChanged<String>? onChange;
  final TextEditingController controller;
  final FocusNode? focusNode;
  final FormFieldValidator<String>? validator;
  final FormFieldSetter<String>? onSaved;
  final Color? backgroundColor;
  final String? dateFormat;
  final String? hint;
  final DateTime? endDate;
  final DateTime? startDate;

  const IOSDatePicker({
    super.key,
    required this.onChange,
    required this.controller,
    this.dateFormat,
    this.focusNode,
    this.validator,
    this.backgroundColor,
    this.hint,
    this.onSaved,
    required this.endDate,
    required this.startDate,
  });

  @override
  State<IOSDatePicker> createState() => _IOSDatePickerState();
}

class _IOSDatePickerState extends State<IOSDatePicker> {
  DateFormat formatter = DateFormat("yyyy-MM-dd HH:mm");

  @override
  void initState() {
    formatter = DateFormat(widget.dateFormat ?? "yyyy-MM-dd HH:mm");
    super.initState();
  }

  void _showDatePicker(ctx) {
    showCupertinoModalPopup(
      context: ctx,
      builder: (_) => Container(
        height: 550.h,
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.all(
            Radius.circular(25.r),
          ),
        ),
        child: Column(
          children: [
            SizedBox(
              height: 450.h,
              child: CupertinoDatePicker(
                  mode: CupertinoDatePickerMode.dateAndTime,
                  minimumYear: DateTime.now().year,
                  onDateTimeChanged: (val) {
                    setState(() {
                      widget.controller.text = formatter.format(val);
                      widget.onChange!(val.toString());
                    });
                  },
                  minimumDate: DateTime.now()),
            ),
            CupertinoButton(
              child: Text('OK', style: Theme.of(context).textTheme.titleMedium),
              onPressed: () => GetIt.I.get<NavigationService>().back(),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _showDatePicker(context);
      },
      child: InputText(
        controller: widget.controller,
        labelText: S.of(context).eventStartDate,
        isFilled: true,
        keyboardType: TextInputType.multiline,
        enabled: false,
        validator: widget.validator,
        onSaved: widget.onSaved,
      ),
    );
  }
}
