import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'platform_specific_widget.dart';

class PlatformDialog
    extends PlatformWidget<CupertinoAlertDialog, SimpleDialog> {
  final Widget? title;
  final Widget content;
  final List<Widget>? actions;
  const PlatformDialog({
    super.key,
    required this.content,
    this.title,
    this.actions,
  });

  @override
  SimpleDialog createAndroidWidget(BuildContext context) {
    return SimpleDialog(
      title: title,
      children: [content],
    );
  }

  @override
  CupertinoAlertDialog createIosWidget(BuildContext context) {
    return CupertinoAlertDialog(
      title: title,
      content: content,
      actions: actions ?? [],
    );
  }
}

class PlatformAlertDialog
    extends PlatformWidget<CupertinoAlertDialog, AlertDialog> {
  final Widget? title;
  final Widget content;
  final List<Widget>? actions;
  const PlatformAlertDialog({
    super.key,
    required this.content,
    this.title,
    this.actions,
  });

  @override
  AlertDialog createAndroidWidget(BuildContext context) {
    return AlertDialog(
      title: title,
      content: content,
      actions: actions ?? [],
      titlePadding: EdgeInsets.only(left: 16.w, right: 16.w, top: 20.h),
      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 20.h),
    );
  }

  @override
  CupertinoAlertDialog createIosWidget(BuildContext context) {
    return CupertinoAlertDialog(
      title: title,
      content: content,
      actions: actions ?? [],
    );
  }
}
